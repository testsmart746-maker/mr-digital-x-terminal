.class public final Lz0/g1;
.super Lz0/s0;
.source "SourceFile"


# instance fields
.field public a:Z

.field public final synthetic b:Lz0/c0;


# direct methods
.method public constructor <init>(Lz0/c0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lz0/g1;->b:Lz0/c0;

    const/4 p1, 0x0

    iput-boolean p1, p0, Lz0/g1;->a:Z

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 0

    .line 1
    if-nez p1, :cond_0

    iget-boolean p1, p0, Lz0/g1;->a:Z

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    iput-boolean p1, p0, Lz0/g1;->a:Z

    iget-object p1, p0, Lz0/g1;->b:Lz0/c0;

    invoke-virtual {p1}, Lz0/c0;->f()V

    :cond_0
    return-void
.end method

.method public final b(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    .line 1
    if-nez p2, :cond_0

    if-eqz p3, :cond_1

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Lz0/g1;->a:Z

    :cond_1
    return-void
.end method
