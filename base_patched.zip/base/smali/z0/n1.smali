.class public interface abstract Lz0/n1;
.super Ljava/lang/Object;
.source "SourceFile"
