.class public interface abstract Li/x1;
.super Ljava/lang/Object;
.source "SourceFile"
