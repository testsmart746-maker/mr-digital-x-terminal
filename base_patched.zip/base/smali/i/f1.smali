.class public final Li/f1;
.super Li/e1;
.source "SourceFile"


# instance fields
.field public final synthetic e:Li/g1;


# direct methods
.method public constructor <init>(Li/g1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Li/f1;->e:Li/g1;

    invoke-direct {p0, p1}, Li/e1;-><init>(Li/g1;)V

    return-void
.end method


# virtual methods
.method public final q(IF)V
    .locals 1

    .line 1
    iget-object v0, p0, Li/f1;->e:Li/g1;

    invoke-static {v0, p1, p2}, Li/g1;->f(Li/g1;IF)V

    return-void
.end method
