.class public abstract Li/n3;
.super Li/r2;
.source "SourceFile"


# static fields
.field public static final synthetic a:I
