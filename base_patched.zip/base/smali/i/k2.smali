.class public interface abstract Li/k2;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(Lh/o;Landroid/view/MenuItem;)V
.end method

.method public abstract k(Lh/o;Lh/q;)V
.end method
