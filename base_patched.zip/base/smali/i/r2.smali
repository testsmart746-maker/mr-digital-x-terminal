.class public abstract Li/r2;
.super Landroid/content/res/Resources;
.source "SourceFile"
