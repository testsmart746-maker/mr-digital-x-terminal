.class public interface abstract Li/n1;
.super Ljava/lang/Object;
.source "SourceFile"
