.class public final Li/z;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Li/a0;


# direct methods
.method public constructor <init>(Li/a0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li/z;->a:Li/a0;

    return-void
.end method
