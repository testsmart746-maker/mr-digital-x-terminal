.class public Lapp/gkc/terminal/Activity/ServiceMenuActivity;
.super Le/m;
.source "SourceFile"


# static fields
.field public static final synthetic F:I


# instance fields
.field public B:Landroid/widget/EditText;

.field public C:Landroid/widget/TextView;

.field public D:Lg1/l;

.field public final E:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->E:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0035

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f0903c3

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->B:Landroid/widget/EditText;

    const p1, 0x7f0903c2

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f0903bf

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v0, Lg1/l;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->E:Ljava/util/ArrayList;

    const/4 v2, 0x3

    invoke-direct {v0, p0, p0, v1, v2}, Lg1/l;-><init>(Le/m;Landroid/content/Context;Ljava/util/ArrayList;I)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->D:Lg1/l;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v0, Lg1/n1;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lg1/n1;-><init>(Le/m;I)V

    invoke-virtual {p1, v0}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->B:Landroid/widget/EditText;

    new-instance v0, Lg1/g0;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lg1/g0;-><init>(Le/m;I)V

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const-string p1, ""

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->p(Ljava/lang/String;)V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 7

    .line 1
    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->E:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E0:[Lg1/z2;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_1
    if-ge v3, v2, :cond_3

    aget-object v4, v1, v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, v4, Lg1/z2;->a:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v4, Lg1/z2;->b:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v5, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    invoke-virtual {v5, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_1
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_3
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->D:Lg1/l;

    invoke-virtual {p1}, Landroid/widget/ArrayAdapter;->notifyDataSetChanged()V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/ServiceMenuActivity;->C:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Service menu matches: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
