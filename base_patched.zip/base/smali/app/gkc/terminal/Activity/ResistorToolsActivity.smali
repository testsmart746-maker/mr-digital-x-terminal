.class public Lapp/gkc/terminal/Activity/ResistorToolsActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final E0:[Lg1/z2;


# instance fields
.field public A0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public final B:[Ljava/lang/String;

.field public B0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public final C:[Ljava/lang/String;

.field public C0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public final D:[I

.field public D0:Landroid/widget/TextView;

.field public final E:[Ljava/lang/String;

.field public final F:[D

.field public final G:[I

.field public final H:[Ljava/lang/String;

.field public final I:[Ljava/lang/String;

.field public final J:[I

.field public final K:[D

.field public L:Landroid/widget/LinearLayout;

.field public M:Landroid/widget/LinearLayout;

.field public N:Landroid/widget/LinearLayout;

.field public O:Landroid/widget/LinearLayout;

.field public P:Landroid/widget/LinearLayout;

.field public Q:Landroid/widget/LinearLayout;

.field public R:Landroid/widget/LinearLayout;

.field public S:Landroid/widget/LinearLayout;

.field public T:[Landroid/widget/Button;

.field public U:Landroid/widget/EditText;

.field public V:Landroid/widget/EditText;

.field public W:Landroid/widget/EditText;

.field public X:Landroid/widget/EditText;

.field public Y:Landroid/widget/EditText;

.field public Z:Landroid/widget/EditText;

.field public a0:Landroid/widget/EditText;

.field public b0:Landroid/widget/EditText;

.field public c0:Landroid/widget/EditText;

.field public d0:Landroid/widget/EditText;

.field public e0:Landroid/widget/EditText;

.field public f0:Landroid/widget/EditText;

.field public g0:Landroid/widget/EditText;

.field public h0:Landroid/widget/EditText;

.field public i0:Landroid/widget/EditText;

.field public j0:Landroid/widget/EditText;

.field public k0:Landroid/widget/EditText;

.field public l0:Landroid/widget/Spinner;

.field public m0:Landroid/widget/Spinner;

.field public n0:Landroid/widget/Spinner;

.field public o0:Landroid/widget/Spinner;

.field public p0:Landroid/widget/Spinner;

.field public q0:Landroid/widget/Spinner;

.field public r0:Landroid/widget/Spinner;

.field public s0:Landroid/widget/Spinner;

.field public t0:Landroid/widget/Spinner;

.field public u0:Landroid/widget/Spinner;

.field public v0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public x0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public y0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

.field public z0:Lapp/gkc/terminal/Activity/ComponentPreviewView;


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/16 v0, 0x1aa

    new-array v0, v0, [Lg1/z2;

    const-string v1, "2841AM5C1"

    const-string v2, "Source Left Right Left Left Right"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "35018123"

    const-string v2, "Menu 2008"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const-string v1, "3501877"

    const-string v3, "Input TV Air Menu 2008"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const-string v1, "35023895"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const-string v1, "35025453"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const-string v1, "40-5NT63B-MAA2HG"

    const-string v3, "Menu Picture Contrast 9735 / 1950 / 9705"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v4, 0x5

    aput-object v1, v0, v4

    const-string v1, "40-6488LA-MAD2HG"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v4, 0x6

    aput-object v1, v0, v4

    const-string v1, "40-6488LA-MAE2HG"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/4 v4, 0x7

    aput-object v1, v0, v4

    const-string v1, "40-MS08F6-MAA2HG"

    const-string v4, "Menu Picture Contrast 9735"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v5, 0x8

    aput-object v1, v0, v5

    const-string v1, "40-MS86H1-MAA2HG"

    const-string v5, "Menu 1147"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x9

    aput-object v1, v0, v6

    const-string v1, "40-MT10B1-MAD2XG"

    const-string v6, "Menu Picture Contrast 1950 / 9735 / 9705"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0xa

    aput-object v1, v0, v6

    const-string v1, "40-MT21XC-MPB2HG"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0xb

    aput-object v1, v0, v3

    const-string v1, "40-MT56EE-MAD2HG"

    const-string v3, "Menu 9735"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0xc

    aput-object v1, v0, v3

    const-string v1, "40-MT58PX-MAB4HG"

    const-string v3, "Picture Advanced Settings Contrast 9735 / 1950 / 9705"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0xd

    aput-object v1, v0, v3

    const-string v1, "40-NT63D1-MAB2HG"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0xe

    aput-object v1, v0, v3

    const-string v1, "40-TC80T6-MAA2HG"

    const-string v3, "Settings, select Brightness, highlight Contrast, enter 9735 / 1950 / 6425 / 6428"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0xf

    aput-object v1, v0, v3

    const-string v1, "40-MS306D-MAC2LG"

    const-string v3, "Menu Settings Picture Contrast 1950"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x10

    aput-object v1, v0, v3

    const-string v1, "4715-6683M2-A3233G11"

    const-string v3, "Menu 82022028 / Picture 82022028"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x11

    aput-object v1, v0, v4

    const-string v1, "5800-A8R30T-0P20"

    const-string v4, "Source 3195"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x12

    aput-object v1, v0, v4

    const-string v1, "5800-A9M43T-1P00"

    const-string v4, "Source 3195"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x13

    aput-object v1, v0, v4

    const-string v1, "6683M2C1"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x14

    aput-object v1, v0, v3

    const-string v1, "715G6335-P03-001-002S"

    const-string v3, "Menu 1199 Back"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x15

    aput-object v1, v0, v3

    const-string v1, "715G6689-M01-004N"

    const-string v3, "Menu 1999 Back"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x16

    aput-object v1, v0, v3

    const-string v1, "715G6689-M0B-004N"

    const-string v3, "Menu 1999 Back"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x17

    aput-object v1, v0, v3

    const-string v1, "715G9907-MOE-B02-005G"

    const-string v3, "Home 1999 Back"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x18

    aput-object v1, v0, v3

    const-string v1, "715GA098-M0F-B00-004G"

    const-string v3, "Info 1999 Back key"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x19

    aput-object v1, v0, v3

    const-string v1, "715GB190MOE-B00-004G"

    const-string v3, "Home 1999 Back key"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x1a

    aput-object v1, v0, v4

    const-string v1, "715GB190MOE-B00-004K"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x1b

    aput-object v1, v0, v4

    const-string v1, "715GC107-COC-004Y"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x1c

    aput-object v1, v0, v4

    const-string v1, "715GC107-COD-004Y"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x1d

    aput-object v1, v0, v3

    const-string v1, "715GD421-C0A-001-004L"

    const-string v3, "Home 1999 Back"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x1e

    aput-object v1, v0, v3

    const-string v1, "9216M5C1"

    const-string v3, "Source Left Right Left Left"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x1f

    aput-object v1, v0, v3

    const-string v1, "9216M6C1"

    const-string v3, "Source/Input Left Right Left Left"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x20

    aput-object v1, v0, v3

    const-string v1, "9603-M5F1"

    const-string v3, "Service Mode 1: Input Left Right Left Left. Service Mode 2: Input Left Left Right Right"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x21

    aput-object v1, v0, v3

    const-string v1, "9612M5F5"

    const-string v3, "Input Left Right Left Left"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v3, 0x22

    aput-object v1, v0, v3

    const-string v1, "CV181 L-Y"

    const-string v3, "Input 2580"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x23

    aput-object v1, v0, v4

    const-string v1, "CV182L_B"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v4, 0x24

    aput-object v1, v0, v4

    const-string v1, "CV309H-X"

    const-string v4, "Source 2580"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x25

    aput-object v1, v0, v6

    const-string v1, "CV338H-A32"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x26

    aput-object v1, v0, v6

    const-string v1, "CV338H-A42"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x27

    aput-object v1, v0, v6

    const-string v1, "CV338H-A50"

    const-string v6, "Menu 2580"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v7, 0x28

    aput-object v1, v0, v7

    const-string v1, "CV3393BH.P32"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v7, 0x29

    aput-object v1, v0, v7

    const-string v1, "CV351H-A42"

    const-string v7, "Menu 1147 / Source 2580"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2a

    aput-object v1, v0, v8

    const-string v1, "CV352-A42"

    const-string v8, "Menu 2580 / Source 2580"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2b

    aput-object v1, v0, v8

    const-string v1, "CV3663LH-A42"

    const-string v8, "Menu, Picture User, Contrast 9735, Menu"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2c

    aput-object v1, v0, v8

    const-string v1, "CV3663MH-A32"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2d

    aput-object v1, v0, v8

    const-string v1, "CV56BH-Q28"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2e

    aput-object v1, v0, v8

    const-string v1, "CV56BH-Q32"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x2f

    aput-object v1, v0, v8

    const-string v1, "CV56BH-Q42"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x30

    aput-object v1, v0, v8

    const-string v1, "CV56BL-L"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x31

    aput-object v1, v0, v8

    const-string v1, "CV56BL-Q24"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x32

    aput-object v1, v0, v8

    const-string v1, "CV56BL-Y24"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x33

    aput-object v1, v0, v8

    const-string v1, "CV56XH-U32"

    const-string v8, "Input 208"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x34

    aput-object v1, v0, v9

    const-string v1, "CV56XH-U42"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x35

    aput-object v1, v0, v9

    const-string v1, "CV56XH-U50"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x36

    aput-object v1, v0, v9

    const-string v1, "CV628H-B42"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x37

    aput-object v1, v0, v9

    const-string v1, "CV628H-T42"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x38

    aput-object v1, v0, v9

    const-string v1, "CV6683H-D42"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x39

    aput-object v1, v0, v9

    const-string v1, "CV950H-A42"

    const-string v9, "Source 2580 / Long press Factory Mode key on the remote"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x3a

    aput-object v1, v0, v9

    const-string v1, "CV960XH-A50"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0x3b

    aput-object v1, v0, v9

    const-string v1, "CV9632-B55"

    const-string v9, "Pending"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x3c

    aput-object v1, v0, v10

    const-string v1, "CVMV26L-A-20"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x3d

    aput-object v1, v0, v10

    const-string v1, "EL.MT6683-75"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x3e

    aput-object v1, v0, v10

    const-string v1, "EL.MT6683-FG48"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x3f

    aput-object v1, v0, v10

    const-string v1, "EL.MT9216-FG48"

    const-string v10, "In HDMI: Left Left, Right Right"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x40

    aput-object v1, v0, v10

    const-string v1, "EL.MT9602PRO-FG95"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x41

    aput-object v1, v0, v10

    const-string v1, "EL.MT9602V-E"

    const-string v10, "Menu, Settings, Sound, Speakers, highlight Balance, enter 4725"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x42

    aput-object v1, v0, v10

    const-string v1, "EL.MT9602V-FG48"

    const-string v10, "Menu, Settings, Sound, Speakers, Balance 1969 or 1147"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x43

    aput-object v1, v0, v10

    const-string v1, "EL.MT9602V-FG75"

    const-string v10, "Menu, Settings, Sound, Speakers, Balance 1969 or 1147"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x44

    aput-object v1, v0, v10

    const-string v1, "EL.MT9602V-FG95"

    const-string v10, "Menu, Settings, Sound, Speakers, highlight Balance, enter 4725"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x45

    aput-object v1, v0, v10

    const-string v1, "EL.RT2874-FG95"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x46

    aput-object v1, v0, v10

    const-string v1, "HK-T.RT2968P61"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x47

    aput-object v1, v0, v10

    const-string v1, "HK.RT.2842P638"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x48

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2831P588"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x49

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2831P638"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4a

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2842P638"

    const-string v10, "Source 2580 / Menu 1147"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4b

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2851P838"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4c

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2851V08"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4d

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2861V08"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4e

    aput-object v1, v0, v10

    const-string v1, "HK.T.RT2968P92"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x4f

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00217919"

    const-string v10, "Menu 31383138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x50

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00230341"

    const-string v10, "Menu, Picture, quickly enter 3138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x51

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00230628"

    const-string v10, "Menu Picture Contrast 31383138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x52

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00246386"

    const-string v10, "Settings / Settings 3138 3138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x53

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00254178"

    const-string v10, "Menu 31383138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x54

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00293937"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x55

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00293939"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x56

    aput-object v1, v0, v10

    const-string v1, "JUC7.820.00297270"

    const-string v10, "Source 3138 3138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x57

    aput-object v1, v0, v10

    const-string v1, "JUG7.820.00233202"

    const-string v10, "Settings 3138 3138"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x58

    aput-object v1, v0, v10

    const-string v1, "LAD.MV56U.A36"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x59

    aput-object v1, v0, v10

    const-string v1, "LAD.MV56U.A48"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x5a

    aput-object v1, v0, v10

    const-string v1, "LAD.MV56U.A75"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x5b

    aput-object v1, v0, v10

    const-string v1, "LAD.MV56U.B48"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v10, 0x5c

    aput-object v1, v0, v10

    const-string v1, "LAD.MV59S.G"

    const-string v10, "Menu 7710"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x5d

    aput-object v1, v0, v11

    const-string v1, "LAD.MV59S.I"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x5e

    aput-object v1, v0, v11

    const-string v1, "LAD.MV59S.Q"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x5f

    aput-object v1, v0, v11

    const-string v1, "LAD.MV9.P"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x60

    aput-object v1, v0, v11

    const-string v1, "LAD.MV9.R"

    const-string v11, "Menu 710"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x61

    aput-object v1, v0, v11

    const-string v1, "LAS.MV56U.C36"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x62

    aput-object v1, v0, v11

    const-string v1, "LDD.538.B138"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x63

    aput-object v1, v0, v11

    const-string v1, "LDD.H310.A75"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x64

    aput-object v1, v0, v11

    const-string v1, "LDD.H510.B138"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x65

    aput-object v1, v0, v11

    const-string v1, "MB-M9216-PW-AL-0294"

    const-string v11, "Source 3180 or select Inputs screen and quickly enter 3180"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x66

    aput-object v1, v0, v11

    const-string v1, "MB-M9216-PW-CL-0038"

    const-string v11, "Input 3138"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x67

    aput-object v1, v0, v11

    const-string v1, "MB-M9216-PW-CL-0295"

    const-string v11, "Source 3138"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x68

    aput-object v1, v0, v11

    const-string v1, "MS08GP"

    const-string v11, "Menu Contrast 9735"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x69

    aput-object v1, v0, v11

    const-string v1, "MSD338ST V5.0"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x6a

    aput-object v1, v0, v11

    const-string v1, "MSD6586-T8E"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v11, 0x6b

    aput-object v1, v0, v11

    const-string v1, "MST309-ISDB-T7B"

    const-string v11, "Menu 8202"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x6c

    aput-object v1, v0, v12

    const-string v1, "MST6M1182VG-T9B"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x6d

    aput-object v1, v0, v12

    const-string v1, "MST6M182VG-T7S"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x6e

    aput-object v1, v0, v12

    const-string v1, "P150-2874V6.0"

    const-string v12, "webOS service controls: SKY-7016 ADJ 0413, IN START 0413, Reset IN STOP 0413"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x6f

    aput-object v1, v0, v12

    const-string v1, "P150-638V6.0"

    const-string v12, "Menu 2008 / Source 2580"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x70

    aput-object v1, v0, v13

    const-string v1, "P50-2831TV 5.0"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x71

    aput-object v1, v0, v13

    const-string v1, "P50-2842V6.2"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x72

    aput-object v1, v0, v13

    const-string v1, "P50-2843TV8.0"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x73

    aput-object v1, v0, v13

    const-string v1, "P50-338TV 5.0"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x74

    aput-object v1, v0, v13

    const-string v1, "P50-352TV5.2"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x75

    aput-object v1, v0, v13

    const-string v1, "P50-352V5.0"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x76

    aput-object v1, v0, v13

    const-string v1, "P75-2831V6.0"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x77

    aput-object v1, v0, v13

    const-string v1, "P75-2842V6.2"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x78

    aput-object v1, v0, v13

    const-string v1, "P75-2843V6.2"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x79

    aput-object v1, v0, v13

    const-string v1, "P75-338V6.2"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7a

    aput-object v1, v0, v12

    const-string v1, "P75-352V6.2"

    const-string v12, "Menu 2008 / Input 2580"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7b

    aput-object v1, v0, v12

    const-string v1, "P75-628VX V6.0"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7c

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.10099"

    const-string v12, "In HDMI Advanced Options 1969 Menu"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7d

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.10291"

    const-string v12, "Menu, Settings, Sound, Advanced Settings, Balance 1969, Menu"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7e

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.10609"

    const-string v12, "Menu, Display and Sound, Sound, Advanced Settings, highlight Balance, enter 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x7f

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.12366"

    const-string v12, "Menu, Display and Sound, Sound, Advanced Settings, Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x80

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.12509"

    const-string v12, "Menu, Display and Sound, Sound, Advanced Settings, highlight Balance, enter 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x81

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.4833"

    const-string v12, "Menu Sound Balance 1969 Menu"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x82

    aput-object v1, v0, v13

    const-string v1, "RSAG7.820.4900"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x83

    aput-object v1, v0, v13

    const-string v1, "RSAG7.820.5236"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x84

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.5649"

    const-string v12, "Menu Audio Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x85

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.5725"

    const-string v12, "Menu Audio Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x86

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.6591"

    const-string v12, "Menu Audio Balance 1950"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x87

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.7343"

    const-string v12, "Menu Settings Sound Advanced Audio Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x88

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.7525"

    const-string v12, "Menu, All settings, Sound, Advanced audio settings, Balance 1969, Menu"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x89

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.7924"

    const-string v12, "Menu All Sound Advanced Audio Settings Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x8a

    aput-object v1, v0, v12

    const-string v1, "RSAG7.820.8430"

    const-string v12, "Menu Settings Sound Advanced Audio Settings Balance 1969"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x8b

    aput-object v1, v0, v13

    const-string v1, "RSAG7.820.8548"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v13, 0x8c

    aput-object v1, v0, v13

    const-string v1, "RSAG7.820.9489"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x8d

    aput-object v1, v0, v12

    const-string v1, "S-WEB74W-V09"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x8e

    aput-object v1, v0, v12

    const-string v1, "S.T.CS2352P668"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x8f

    aput-object v1, v0, v12

    const-string v1, "S.T.CS2560P838"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x90

    aput-object v1, v0, v12

    const-string v1, "S.TCS2352P638"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x91

    aput-object v1, v0, v12

    const-string v1, "SHS2404A-101S"

    const-string v12, "Menu Picture Contrast 9705"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x92

    aput-object v1, v0, v12

    const-string v1, "SKR.03"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x93

    aput-object v1, v0, v12

    const-string v1, "SKR.801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x94

    aput-object v1, v0, v12

    const-string v1, "SKR.816"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x95

    aput-object v1, v0, v12

    const-string v1, "SKR.819"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x96

    aput-object v1, v0, v12

    const-string v1, "ST6308RTU-AP1"

    const-string v12, "Menu 0000"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x97

    aput-object v1, v0, v12

    const-string v1, "T.MS18VG.71A"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x98

    aput-object v1, v0, v12

    const-string v1, "T.MS18VG.72"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x99

    aput-object v1, v0, v12

    const-string v1, "T.MS18VG.81B"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9a

    aput-object v1, v0, v12

    const-string v1, "T.MS608.61"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9b

    aput-object v1, v0, v12

    const-string v1, "T.MS608.81"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9c

    aput-object v1, v0, v12

    const-string v1, "T.MT5522.81"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9d

    aput-object v1, v0, v12

    const-string v1, "T.R83.031"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9e

    aput-object v1, v0, v12

    const-string v1, "T.R85.031"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x9f

    aput-object v1, v0, v12

    const-string v1, "T.RT2843P639"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa0

    aput-object v1, v0, v12

    const-string v1, "T.SK706S.82"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa1

    aput-object v1, v0, v12

    const-string v1, "T.V56.03"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa2

    aput-object v1, v0, v12

    const-string v1, "T.V56.PB816"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa3

    aput-object v1, v0, v12

    const-string v1, "T.VST.29.61C"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa4

    aput-object v1, v0, v12

    const-string v1, "T.VST29.03"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa5

    aput-object v1, v0, v12

    const-string v1, "T.VST29.61C"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa6

    aput-object v1, v0, v12

    const-string v1, "T.VST59.031"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa7

    aput-object v1, v0, v12

    const-string v1, "T.VST59.031.A81 A8"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa8

    aput-object v1, v0, v12

    const-string v1, "T.VST59.62"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xa9

    aput-object v1, v0, v12

    const-string v1, "T.VST59.A5"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xaa

    aput-object v1, v0, v12

    const-string v1, "T.VST59S.73"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xab

    aput-object v1, v0, v12

    const-string v1, "T56J.11.2"

    const-string v12, "Menu 1147 / Input 2580 / Input 0000 / Menu 8892 / AV 208 / AV 308"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xac

    aput-object v1, v0, v12

    const-string v1, "T5964.81"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xad

    aput-object v1, v0, v12

    const-string v1, "TP.HV310.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xae

    aput-object v1, v0, v12

    const-string v1, "TP.HV320.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xaf

    aput-object v1, v0, v12

    const-string v1, "TP.HV320.PB813"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xb0

    aput-object v1, v0, v12

    const-string v1, "TP.HV352T.PB753 (N)"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xb1

    aput-object v1, v0, v12

    const-string v1, "TP.HV510.PC821"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xb2

    aput-object v1, v0, v12

    const-string v1, "TP.HV510.PC822"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb3

    aput-object v1, v0, v9

    const-string v1, "TP.HV530.PC821"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb4

    aput-object v1, v0, v9

    const-string v1, "TP.MS338.P818"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb5

    aput-object v1, v0, v9

    const-string v1, "TP.MS338.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb6

    aput-object v1, v0, v9

    const-string v1, "TP.MS338.PB802"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb7

    aput-object v1, v0, v9

    const-string v1, "TP.MS338.PB805"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb8

    aput-object v1, v0, v9

    const-string v1, "TP.MS338.PB818"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xb9

    aput-object v1, v0, v9

    const-string v1, "TP.MS3393.PB851"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xba

    aput-object v1, v0, v9

    const-string v1, "TP.MS3393.PB855"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xbb

    aput-object v1, v0, v9

    const-string v1, "TP.MS3663.PB782"

    const-string v9, "Source 2580 and Menu 1147"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xbc

    aput-object v1, v0, v9

    const-string v1, "TP.MS6308.PB775"

    const-string v9, "Menu, Picture, highlight Contrast, 1950 / 9735 / 9705"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xbd

    aput-object v1, v0, v9

    const-string v1, "TP.MS6683.PB752"

    const-string v9, "In HDMI Advanced Options 1969 Menu"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xbe

    aput-object v1, v0, v9

    const-string v1, "TP.MS6683.PB766 (T)"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xbf

    aput-object v1, v0, v9

    const-string v1, "TP.MT9216.PB705"

    const-string v9, "Menu Advanced Options 1969 Menu"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v9, 0xc0

    aput-object v1, v0, v9

    const-string v1, "TP.RT2982.PC821"

    const-string v9, "Menu 1147 / Menu 2580"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc1

    aput-object v1, v0, v12

    const-string v1, "TP.RT2984T.PC821"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc2

    aput-object v1, v0, v12

    const-string v1, "TP.SK706S.PC822"

    const-string v12, "Menu 1147 / Menu 1201"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc3

    aput-object v1, v0, v12

    const-string v1, "TP.V56.PB801"

    const-string v12, "Menu 1147 and Source 2580"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc4

    aput-object v1, v0, v12

    const-string v1, "TP.VST59.PB819"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc5

    aput-object v1, v0, v12

    const-string v1, "TPD.MT9216.PB766 (T)"

    const-string v12, "In HDMI: Left Left, Right Right"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc6

    aput-object v1, v0, v12

    const-string v1, "TPD.MT9602.PB767 (T)"

    const-string v12, "Menu, Settings, Sound, Speakers, Balance 1969, Menu"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc7

    aput-object v1, v0, v12

    const-string v1, "TPD.NT72563.PB783"

    const-string v12, "Menu Install 4725"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc8

    aput-object v1, v0, v12

    const-string v1, "TPD.RT2841.PB771"

    const-string v12, "Menu, Picture, Advanced brightness settings, highlight Contrast, 1950 / 9735 / 9705"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xc9

    aput-object v1, v0, v12

    const-string v1, "TR.85.03"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xca

    aput-object v1, v0, v12

    const-string v1, "VS.SP33811.2"

    const-string v12, "Input / Source 208"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xcb

    aput-object v1, v0, v12

    const-string v1, "VS.TP53U61.2"

    const-string v12, "Input 208 / TV"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xcc

    aput-object v1, v0, v12

    const-string v1, "VS.TP53U71.2"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xcd

    aput-object v1, v0, v8

    const-string v1, "VS.TP56L62.2"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xce

    aput-object v1, v0, v8

    const-string v1, "VS.TP53L62.2"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xcf

    aput-object v1, v0, v8

    const-string v1, "ZP.255E.818R01"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd0

    aput-object v1, v0, v8

    const-string v1, "ZP.VST6A338.PB818"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd1

    aput-object v1, v0, v8

    const-string v1, "ZP.Z632H.815R00"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd2

    aput-object v1, v0, v8

    const-string v1, "TP.HV320/PB813"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd3

    aput-object v1, v0, v8

    const-string v1, "TP.HV320/PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd4

    aput-object v1, v0, v8

    const-string v1, "TP.MS.338.PC821"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd5

    aput-object v1, v0, v8

    const-string v1, "T.MS.18VG.71A"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd6

    aput-object v1, v0, v8

    const-string v1, "TMS.18VG.81B"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd7

    aput-object v1, v0, v8

    const-string v1, "T.MT8223.33"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd8

    aput-object v1, v0, v8

    const-string v1, "TVST 59.A5"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xd9

    aput-object v1, v0, v8

    const-string v1, "T.VST29.61.C"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xda

    aput-object v1, v0, v8

    const-string v1, "5800-A8M260-0020"

    const-string v8, "Input 3195"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xdb

    aput-object v1, v0, v8

    const-string v1, "350016386"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xdc

    aput-object v1, v0, v8

    const-string v1, "SP208ESA HK-7050A-V208"

    const-string v8, "Menu 7050"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xdd

    aput-object v1, v0, v8

    const-string v1, "35017414REV-01"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xde

    aput-object v1, v0, v8

    const-string v1, "35016445REV-01"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xdf

    aput-object v1, v0, v2

    const-string v1, "JUG7.820.531-3"

    const-string v2, "Input 3133"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe0

    aput-object v1, v0, v2

    const-string v1, "40.TBI.TO7-MABE HG"

    const-string v2, "Menu / Contrast 1950 or 9735"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe1

    aput-object v1, v0, v2

    const-string v1, "TP.MS1306.PB772"

    const-string v2, "Menu / Contrast 1950 or 9735"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe2

    aput-object v1, v0, v2

    const-string v1, "CV309H-V"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe3

    aput-object v1, v0, v2

    const-string v1, "CV56BH.242"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe4

    aput-object v1, v0, v2

    const-string v1, "TP.MS.608.P82"

    const-string v2, "Source/Input 1147"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe5

    aput-object v1, v0, v2

    const-string v1, "CHANGHONG"

    const-string v2, "Input 3138 / Input 1125 / Input 42580 / Menu 1125 / Menu 1149 / Menu 2580 / Menu 0816"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe6

    aput-object v1, v0, v2

    const-string v1, "ECOSTAR"

    const-string v2, "Menu 2008 / Menu 2508 / Menu 8002 / Menu 8202"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe7

    aput-object v1, v0, v2

    const-string v1, "ORIENT"

    const-string v2, "Input 2580 or 2588 / Source 2588 or 2580"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe8

    aput-object v1, v0, v2

    const-string v1, "HAIER"

    const-string v2, "Menu 1147 / Menu 8202 / 8823 / Menu 4578 / highlight Audio + 8893 / Menu or Exit + 1999 + OK"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xe9

    aput-object v1, v0, v2

    const-string v1, "TCL"

    const-string v2, "Menu + Contrast + 9735 or 1950"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xea

    aput-object v1, v0, v2

    const-string v1, "SAMSUNG"

    const-string v2, "Standby: Mute + 182 + Power / Turn off, Info, Menu, Mute, Power"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xeb

    aput-object v1, v0, v2

    const-string v1, "LG"

    const-string v2, "Hold Menu until 4-digit password opens / 8741 / 0413 / 0000 / 8878 / 7777 / 8743"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xec

    aput-object v1, v0, v2

    const-string v1, "VIDEOCON"

    const-string v2, "Menu 123 / Menu 0323 / Menu 1147 / Menu 1947 / Menu 6483 / Menu + Sound + 8532"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xed

    aput-object v1, v0, v2

    const-string v1, "ONIDA"

    const-string v2, "Source 2580 / Menu + Vol+ + 8532 / Menu, Picture, Contrast 9735 / Menu, Picture, Contrast 1950"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xee

    aput-object v1, v0, v2

    const-string v1, "INTEX LED 1601"

    const-string v2, "Menu 13"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0xef

    aput-object v1, v0, v2

    const-string v1, "INTEX LED 1602"

    const-string v2, "Menu 8896"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf0

    aput-object v1, v0, v8

    const-string v1, "INTEX LED 1602N"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf1

    aput-object v1, v0, v8

    const-string v1, "INTEX LED 1600"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf2

    aput-object v1, v0, v8

    const-string v1, "INTEX LED 1611-VT13"

    const-string v8, "Source + 6964"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf3

    aput-object v1, v0, v8

    const-string v1, "INTEX LES/9HD08-B013"

    const-string v8, "Input + 2580"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf4

    aput-object v1, v0, v8

    const-string v1, "INTEX LED TV2110"

    const-string v8, "Menu + 8896"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf5

    aput-object v1, v0, v8

    const-string v1, "INTEX LED 2200 FHD"

    const-string v8, "Menu + 1147"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xf6

    aput-object v1, v0, v12

    const-string v1, "INTEX LED 2202 FHD"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xf7

    aput-object v1, v0, v12

    const-string v1, "INTEX LED 2410 FHD"

    const-string v12, "Menu + 8202"

    invoke-static {v1, v12}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0xf8

    aput-object v1, v0, v12

    const-string v1, "INTEX LED 2800 FHD"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xf9

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL LED TV BOARD"

    const-string v8, "Menu 208 / 0101 / 710 / 1234 / 4711 / 4725 / 5880 / 6181 / 7050 / 7168 / 7343 / 7710 / 8093 / 8500 / 8202 / 8593 / 8896 / 8893 / 9301 / 9380 / 9385 / 9527 / 9735 / 9883"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xfa

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL INPUT CODES"

    const-string v8, "Input 1147 / 2580 / 0000 / 208 / 308"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xfb

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL SOURCE CODES"

    const-string v8, "Source 0000 / 2283 / 2285 / 2580 / 2585 / 2587 / 3137 / 3138 / 3195 / 6483 / 7343"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xfc

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL MENU CODES"

    const-string v8, "Menu 0000 / 1147 / 1150 / 1167 / 1185 / 1187 / 1189 / 1199 / 1173 / 1999 / 2008 / 2383 / 2387 / 2508 / 2580 / 2588 / 2611 / 2880 / 2888"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xfd

    aput-object v1, v0, v8

    const-string v1, "HAIER SMART TV"

    const-string v8, "Open Menu, go to Advanced Settings, press Left 2 times, Up 1 time, Right 1 time to open Service Settings"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xfe

    aput-object v1, v0, v8

    const-string v1, "KK.RV22.801"

    const-string v8, "Menu 1147 / Input 1147 / Source 1150 / Input 336 / Input 208"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0xff

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL BOARD EXTRA"

    const-string v8, "Input 336 / Input 1147 / Menu 1147 / Input 2580 / Menu 2580 / Menu 308 / Input 308 / Menu 8896 / Input 8896 / Menu 8893 / Input 8893 / Input 208 / Menu 208"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x100

    aput-object v1, v0, v8

    const-string v1, "V56U11.2"

    const-string v8, "Input 336 / Input 1147 / Menu 1147 / Input 2580 / Menu 2580 / Menu 308 / Input 308 / Menu 8896 / Input 8896 / Menu 8893 / Input 8893 / Input 208 / Menu 208"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x101

    aput-object v1, v0, v8

    const-string v1, "JSWY32GSHD (NTM9216.3G040)"

    const-string v8, "Menu + Advanced + 3195"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x102

    aput-object v1, v0, v8

    const-string v1, "TP.MT9216.PB731 HAIER H43K6FG"

    const-string v8, "Menu + Advanced + Left Left + Up + Right"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x103

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P637"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x104

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P588"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x105

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P533"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x106

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P538"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x107

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P586"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x108

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P689"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x109

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352P687"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10a

    aput-object v1, v0, v8

    const-string v1, "S.T.CS2352PXXX"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10b

    aput-object v1, v0, v8

    const-string v1, "TCL TV"

    const-string v8, "Settings > Picture > Advanced > Brightness > Contrast > enter 1950"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10c

    aput-object v1, v0, v8

    const-string v1, "BPL"

    const-string v8, "Menu > Advanced Settings > 3138"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10d

    aput-object v1, v0, v8

    const-string v1, "ONEPLUS TV"

    const-string v8, "Settings > OK > Network & Internet > Vol+ > Vol- > Left > Right > Up > Down > OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10e

    aput-object v1, v0, v8

    const-string v1, "32P2400ZE"

    const-string v8, "Press Mute, press Mute again and hold it, then press AV on the TV to open service mode"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x10f

    aput-object v1, v0, v8

    const-string v1, "LLOYD"

    const-string v8, "Advanced Sound Settings > Adj Balance 0 > 1969"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x110

    aput-object v1, v0, v8

    const-string v1, "INFINIX"

    const-string v8, "E-Manual > Left > Right > Up > Down > OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x111

    aput-object v1, v0, v8

    const-string v1, "VU"

    const-string v8, "Settings > Audio Settings > Advanced Audio Settings > Balance 0 > enter 1950 or 2580"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x112

    aput-object v1, v0, v8

    const-string v1, "VU SMART"

    const-string v8, "Menu > All Settings > Audio Settings > Sound > Balance > 1969, then press Menu for 3 seconds"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x113

    aput-object v1, v0, v8

    const-string v1, "HAIER SERVICE MODE EXTRA"

    const-string v8, "Input > Menu > Advanced > OK > 8893 / Input > Left > Right > Left > Right / Input > Left > Left > Up > Right / Menu 8893 / Input 2580 / Hold Settings key and type 3195"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x114

    aput-object v1, v0, v8

    const-string v1, "HAIER LE32A6500GA"

    const-string v8, "Menu > Advanced Settings > Left > Left > Up > Right"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x115

    aput-object v1, v0, v12

    const-string v1, "HAIER LE32K6600GA"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x116

    aput-object v1, v0, v12

    const-string v1, "HAIER LE40K6600GA"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x117

    aput-object v1, v0, v12

    const-string v1, "HAIER LE43K6600GA"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v12, 0x118

    aput-object v1, v0, v12

    const-string v1, "CV6683H.C42 HAIER"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x119

    aput-object v1, v0, v8

    const-string v1, "KODAK"

    const-string v8, "Input/Menu 2850 / 1950 / 2650 / Freeze button"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11a

    aput-object v1, v0, v8

    const-string v1, "SAMSUNG SERVICE REMOTE"

    const-string v8, "Use service remote: Info > Factory"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11b

    aput-object v1, v0, v8

    const-string v1, "PANASONIC MS550DX"

    const-string v8, "Source > Up 4 times > Left > Right > Right > Left > Right"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11c

    aput-object v1, v0, v8

    const-string v1, "MARQ ANDROID NORMAL TV"

    const-string v8, "Source 3195 / Input 6964 / Menu 1147, then select Others > Out Factory Reset"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11d

    aput-object v1, v0, v8

    const-string v1, "MARQ"

    const-string v8, "Source > Left > Right > Left > Right > Back key / Menu > Advanced Option > press 0 key 4 times"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11e

    aput-object v1, v0, v8

    const-string v1, "INFINIX COOLITA NTT821D 3P31A"

    const-string v8, "Input > Left > Right > Left > Right > Back / Manual > Left > Right > Up > Down > OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x11f

    aput-object v1, v0, v8

    const-string v1, "ACER"

    const-string v8, "Settings > Picture Mode > Custom > Contrast > OK 7 times"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x120

    aput-object v1, v0, v8

    const-string v1, "TOSHIBA ORIGINAL REMOTE"

    const-string v8, "Use original remote only: Menu 8893 / Menu 6483"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x121

    aput-object v1, v0, v8

    const-string v1, "SHARP LC-40LE185M"

    const-string v8, "Press the two indicated TV buttons together for 5 seconds, give AC power, press Up, Down, Up, OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x122

    aput-object v1, v0, v8

    const-string v1, "SHARP LC-40LE265M"

    const-string v8, "Press and hold Red + Green keys until red/green LED blinks, move green key Up > Down > Up, press Green once to display service menu"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x123

    aput-object v1, v0, v8

    const-string v1, "MS-R41AP638"

    const-string v8, "Menu > Picture OK > Picture Mode OK > Personal OK > select Contrast > press OK 6 times"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x124

    aput-object v1, v0, v8

    const-string v1, "CHINA UNIVERSAL-1"

    const-string v8, "Menu 1147 / 1183 / 1185 / 1187 / 2008 / 7050 / 2580 / 8202 / 7343 / 1999 / 0000 / 1167 / 1199 / 2383 / 2387 / 8893 / 1234 / 4725 / Source 3138 / 2580 / 2583 / 2585 / 2283 / 2285 / 7342 / 0000 / 3137 / 3195"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x125

    aput-object v1, v0, v8

    const-string v1, "REALME TV"

    const-string v8, "Select HDMI mode > Menu > Advanced Setting > OK > Left > Right > Left > Right"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x126

    aput-object v1, v0, v8

    const-string v1, "T.VST29.61.C ALT"

    const-string v8, "Input 1147"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x127

    aput-object v1, v0, v8

    const-string v1, "T.VS.TP53L62.2"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x128

    aput-object v1, v0, v8

    const-string v1, "TP.HV320/PB813 ALT"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x129

    aput-object v1, v0, v8

    const-string v1, "JUG7.820.531-3 ALT"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x12a

    aput-object v1, v0, v8

    const-string v1, "35016445 REV-01 ALT"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x12b

    aput-object v1, v0, v8

    const-string v1, "TP.MS.338.PC821 ALT"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x12c

    aput-object v1, v0, v6

    const-string v1, "LAD.MV9.R ALT"

    invoke-static {v1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x12d

    aput-object v1, v0, v6

    const-string v1, "SHARP GENERAL"

    const-string v6, "Menu 1999 / Menu 3481 / Menu 1147 / Hold VOL- + INPUT on TV while plugging power, when K appears press VOL- + CHANNEL-"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x12e

    aput-object v1, v0, v6

    const-string v1, "SHARP LOCAL KEYBOARD"

    const-string v6, "Press and hold VOL- and PR+ buttons on the local keyboard"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x12f

    aput-object v1, v0, v6

    const-string v1, "SONY"

    const-string v6, "Hold Up Arrow on the remote and press Power on the TV while TV is on"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v6, 0x130

    aput-object v1, v0, v6

    const-string v1, "SYMPHONY"

    const-string v6, "Source/Input 2580"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x131

    aput-object v1, v0, v8

    const-string v1, "TOSHIBA FACTORY RESET"

    const-string v8, "Menu > Installation > System Information > press Right arrow key until Factory Reset appears"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x132

    aput-object v1, v0, v8

    const-string v1, "VESTEL"

    const-string v8, "Menu 4725, then select RESET"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x133

    aput-object v1, v0, v8

    const-string v1, "SEARCH VISION"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x134

    aput-object v1, v0, v8

    const-string v1, "VIZIO"

    const-string v8, "Help tab > Factory Default > enter 0000"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x135

    aput-object v1, v0, v8

    const-string v1, "HAIER LCD"

    const-string v8, "Press Menu/Exit, press 1999, then OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x136

    aput-object v1, v0, v8

    const-string v1, "PANASONIC GENERAL"

    const-string v8, "Hold VOL- on the TV and press INFO on the remote 3 times within 2 seconds / Hold VOL- on the TV and hold Menu on the remote"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x137

    aput-object v1, v0, v8

    const-string v1, "AOC"

    const-string v8, "Set TV volume to zero, press Mute, then press 9876"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x138

    aput-object v1, v0, v8

    const-string v1, "BEKO LCD"

    const-string v8, "Menu 9301 / Sleep > Pic > DSP > Menu / Menu > Q.View > Mute / Preset CH then 2483"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x139

    aput-object v1, v0, v8

    const-string v1, "HAIER LCD HL40XP1"

    const-string v8, "Press Menu, enter 8893, then OK"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13a

    aput-object v1, v0, v8

    const-string v1, "HAIER HTR20 CRT"

    const-string v8, "Press Menu on TV panel and button on remote control at the same time"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13b

    aput-object v1, v0, v8

    const-string v1, "PHILIPS"

    const-string v8, "Menu then 062596 / remote sequence 062596 then press Menu"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13c

    aput-object v1, v0, v8

    const-string v1, "SANYO LCD"

    const-string v8, "Menu > Input > 2580 / Hold VOL Down on TV and hold button 1 on remote"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13d

    aput-object v1, v0, v8

    const-string v1, "SINGER"

    const-string v8, "Remote sequence: 1, Mute, Recall, Mute, 1, Mute, Display, Mute"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13e

    aput-object v1, v0, v8

    const-string v1, "LG/ZENITH"

    const-string v8, "Hold Menu on TV and Menu on remote for 5 to 10 seconds"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x13f

    aput-object v1, v0, v8

    const-string v1, "MITSUBISHI"

    const-string v8, "Menu 123 or Menu 2470 while TV is active"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x140

    aput-object v1, v0, v8

    const-string v1, "NEC"

    const-string v8, "When TV is on, hold Menu or Input on the TV"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x141

    aput-object v1, v0, v8

    const-string v1, "POLAROID"

    const-string v8, "Hold VOL- and CHANNEL- or hold VOL+ and CHANNEL+ in Live TV"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x142

    aput-object v1, v0, v8

    const-string v1, "PROSCAN"

    const-string v8, "Setup > Parental Control > enter 0000 > Clear Channel List"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x143

    aput-object v1, v0, v8

    const-string v1, "RCA"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x144

    aput-object v1, v0, v8

    const-string v1, "SEIKI"

    const-string v8, "Menu 0000"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x145

    aput-object v1, v0, v8

    const-string v1, "MICROMAX DESIGN MENU"

    const-string v8, "Picture submenu > select Contrast > press 1950"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x146

    aput-object v1, v0, v8

    const-string v1, "MICROMAX FACTORY MENU"

    const-string v8, "Picture submenu > select Contrast > press 9735"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x147

    aput-object v1, v0, v8

    const-string v1, "MICROMAX SERVICE MENU"

    const-string v8, "Picture submenu > select Contrast > press 9705"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x148

    aput-object v1, v0, v8

    const-string v1, "COBY"

    const-string v8, "Highlight Audio, enter 8893 / Mode or Source 2580"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x149

    aput-object v1, v0, v8

    const-string v1, "DYNEX"

    const-string v8, "Source/Input 2580 / Hold VOL on TV and hold button 1 on remote"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x14a

    aput-object v1, v0, v8

    const-string v1, "ELEMENT"

    const-string v8, "Menu 0000, then Menu 1147"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x14b

    aput-object v1, v0, v8

    const-string v1, "HISENSE"

    const-string v8, "Parental > enter 0000 > Clean all"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x14c

    aput-object v1, v0, v8

    const-string v1, "BADGE"

    const-string v8, "Input 2580 in Live TV"

    invoke-static {v1, v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v8, 0x14d

    aput-object v1, v0, v8

    const-string v1, "INTEX LED TV-1902"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x14e

    aput-object v1, v0, v2

    const-string v1, "INTEX LED 2110 ALT"

    const-string v2, "Source 6964"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x14f

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-2400 HD"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x150

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-LE31HD08/3108"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x151

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3107"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x152

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3207"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x153

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3199 GOLD"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x154

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3210"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x155

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-3110"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x156

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3111"

    const-string v2, "Inside Menu > S/W update"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x157

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-3900 FHD"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x158

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-4000FHD"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x159

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-40FHD10-VM"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15a

    aput-object v1, v0, v2

    const-string v1, "INTEX LED TV-4200FHD"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15b

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-2011 19.5"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15c

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-2412"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15d

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-4010FHD"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15e

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-2111 20.7"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x15f

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-5000FHD"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x160

    aput-object v1, v0, v2

    const-string v1, "INTEX LED 23.6"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x161

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-4001 39 HD"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x162

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-2203FHD 21.5"

    const-string v2, "Source 6964"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x163

    aput-object v1, v0, v2

    const-string v1, "INTEX SPLASH-800 32"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x164

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-2810 28"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x165

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-4300FHD 43"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x166

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-5010FHD 49"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x167

    aput-object v1, v0, v2

    const-string v1, "INTEX LED-3105T"

    invoke-static {v1, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x168

    aput-object v1, v0, v2

    const-string v1, "CHINA LCD SERVICE MENU"

    const-string v2, "Menu > Picture Contrast > press 9705"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x169

    aput-object v1, v0, v2

    const-string v1, "VIDEOCON LCD"

    const-string v2, "LCD 19/20 Menu 123 / LCD 26/32 Menu + Sound Pop Up + 8532"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16a

    aput-object v1, v0, v2

    const-string v1, "VIDEOCON TV ALT"

    const-string v2, "Design mode Menu 0203 / Service mode Menu 0323 / Design mode Menu 1982 / Service mode Menu 1947 / Menu 1147 / Menu 6483"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16b

    aput-object v1, v0, v2

    const-string v1, "LG LCD SERVICE REMOTE"

    const-string v2, "Service remote keys: Power Only / In.Stop / In.Start / EZ.Adj / codes 0000 / 7777 / 0431 / 8741 / 8743 / 8878 / AV308 / AV309"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16c

    aput-object v1, v0, v2

    const-string v1, "T56J.11.2 ALT"

    const-string v2, "AV308 / AV309 / Menu 8896"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16d

    aput-object v1, v0, v2

    const-string v1, "T.V56.031 A8"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16e

    aput-object v1, v0, v2

    const-string v1, "V56U V56J.11.2"

    const-string v2, "Menu 1147 / Input 2580 / Input 0000"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x16f

    aput-object v1, v0, v2

    const-string v1, "CHINA UNIVERSAL EXTRA CODES"

    const-string v2, "Menu 1197 / 1973 / Source/Input 308 / Input 3195 / Source 2583 / Mute 6483"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x170

    aput-object v1, v0, v2

    const-string v1, "TP.VST59S.PB813"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x171

    aput-object v1, v0, v2

    const-string v1, "DP.V53RL.8136"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x172

    aput-object v1, v0, v2

    const-string v1, "DP.V53RU.8136"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x173

    aput-object v1, v0, v2

    const-string v1, "TP.MS338.PB822"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x174

    aput-object v1, v0, v2

    const-string v1, "TP.MS358.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x175

    aput-object v1, v0, v2

    const-string v1, "TP.MS608.PB831"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x176

    aput-object v1, v0, v2

    const-string v1, "TP.MS608.P83"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x177

    aput-object v1, v0, v2

    const-string v1, "TP.MS628.PC821"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x178

    aput-object v1, v0, v2

    const-string v1, "TP.MS628.PB803"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x179

    aput-object v1, v0, v2

    const-string v1, "TP.MS628.PB831"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17a

    aput-object v1, v0, v2

    const-string v1, "TP.MS628.PD65"

    invoke-static {v1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17b

    aput-object v1, v0, v2

    const-string v1, "TP.MT5505.PC801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17c

    aput-object v1, v0, v2

    const-string v1, "TP.MT5507.PC821"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17d

    aput-object v1, v0, v2

    const-string v1, "TP.MT5507.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17e

    aput-object v1, v0, v2

    const-string v1, "TP.VST59.P75"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x17f

    aput-object v1, v0, v2

    const-string v1, "TP.RD8501.568"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x180

    aput-object v1, v0, v2

    const-string v1, "TP.RD8503.PB824"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x181

    aput-object v1, v0, v2

    const-string v1, "TP.RD8503.PB819"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x182

    aput-object v1, v0, v2

    const-string v1, "TP.RD8503.PA671"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x183

    aput-object v1, v0, v2

    const-string v1, "TP.V56C.PB818"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x184

    aput-object v1, v0, v2

    const-string v1, "TP.VST59S.PC1"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x185

    aput-object v1, v0, v2

    const-string v1, "TP.VST59S.PB802"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x186

    aput-object v1, v0, v2

    const-string v1, "TP.VST59S.PB716"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x187

    aput-object v1, v0, v2

    const-string v1, "TP.RT2982.PB801"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x188

    aput-object v1, v0, v2

    const-string v1, "TP.R69.PD64"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x189

    aput-object v1, v0, v2

    const-string v1, "TP.V56.PB826"

    invoke-static {v1, v7}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18a

    aput-object v1, v0, v2

    const-string v1, "VS.T53U21.2"

    invoke-static {v1, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18b

    aput-object v1, v0, v2

    const-string v1, "T.R83.816"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18c

    aput-object v1, v0, v2

    const-string v1, "TP.VST59.P63"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18d

    aput-object v1, v0, v2

    const-string v1, "TP.VST59.P86"

    const-string v2, "Menu 1147 / Menu 8893"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18e

    aput-object v1, v0, v2

    const-string v1, "TP.V56C.PA673"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x18f

    aput-object v1, v0, v2

    const-string v1, "T.VST59S.81"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x190

    aput-object v1, v0, v2

    const-string v1, "TCL GOOGLE TV"

    const-string v2, "Settings > System > About, then Up > Right > Down > Right > Up > Fast Forward x3 > Rewind x2 > Back"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x191

    aput-object v1, v0, v2

    const-string v1, "TCL FACTORY MENU"

    const-string v2, "Picture Contrast 9735 / 6428 / 6425 / Design 1950 / Service 9705 / Smart TV Menu 1999 / Non-smart 061596"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x192

    aput-object v1, v0, v2

    const-string v1, "HISENSE VIDDA"

    const-string v2, "Settings > Sound > Audio Output Settings > Balance > 1969 / Menu 2580 / Menu 1147"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x193

    aput-object v1, v0, v2

    const-string v1, "SONY BRAVIA ANDROID"

    const-string v2, "Home > Settings > Setup > Factory Settings > Yes twice"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x194

    aput-object v1, v0, v2

    const-string v1, "SONY SMART SERVICE"

    const-string v2, "Power off, then Display/Info > 5 > Vol- > Power; power off to exit"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x195

    aput-object v1, v0, v2

    const-string v1, "MAGNAVOX"

    const-string v2, "062596 + Home/Menu/Status/Info/OSD / 062597 + Home / 061597 + Home / Menu 1147"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x196

    aput-object v1, v0, v2

    const-string v1, "FUNAI"

    const-string v2, "Standby then 217 + Mute / CH- + VOL- then Menu / CH+ + CH- + VOL+ then Menu"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x197

    aput-object v1, v0, v2

    const-string v1, "TOSHIBA SERVICE MENU"

    const-string v2, "Menu > Picture > 9301 / Mute then 1234 / Toshiba 32W2333D Menu 4725"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x198

    aput-object v1, v0, v2

    const-string v1, "PHILIPS UNIVERSAL"

    const-string v2, "062596 + Menu/Info/Status / 062597 + Menu/Info/Status / 061596 + Menu"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x199

    aput-object v1, v0, v2

    const-string v1, "PHILIPS MODEL GROUP"

    const-string v2, "Menu 2580 / Menu 1950 / Menu 1147 / Menu Picture Contrast 9735 / Menu Sound 8532 / Menu 1999 Back"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19a

    aput-object v1, v0, v2

    const-string v1, "DAZZLE"

    const-string v2, "Menu 2483 / Menu 6483"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19b

    aput-object v1, v0, v2

    const-string v1, "SKYWORTH IRIS"

    const-string v2, "Source 3195 / Menu Sound Setup Volume 9527 / Volume 0, Menu Brightness 2648"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19c

    aput-object v1, v0, v2

    const-string v1, "NOBEL TCL"

    const-string v2, "Menu > Contrast > 1950 / 9735"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19d

    aput-object v1, v0, v2

    const-string v1, "SALORA"

    const-string v2, "Menu > Picture > 2003"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19e

    aput-object v1, v0, v2

    const-string v1, "SHANNON"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x19f

    aput-object v1, v0, v2

    const-string v1, "ALONSO"

    invoke-static {v1, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a0

    aput-object v1, v0, v2

    const-string v1, "SHAWNAK"

    invoke-static {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a1

    aput-object v1, v0, v2

    const-string v1, "GENERAL TV"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a2

    aput-object v1, v0, v2

    const-string v1, "ROYAL"

    invoke-static {v1, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a3

    aput-object v1, v0, v2

    const-string v1, "KRAFT"

    const-string v2, "Menu 8802 / Menu 8202"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a4

    aput-object v1, v0, v2

    const-string v1, "LLOYED"

    const-string v2, "Menu 1147 / Menu > Sound > Balance > 1969"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a5

    aput-object v1, v0, v2

    const-string v1, "DEVANT"

    const-string v2, "Menu > Sound > Balance > 0532"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a6

    aput-object v1, v0, v2

    const-string v1, "SYMPHONE"

    const-string v2, "Input/Source 2580"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a7

    aput-object v1, v0, v2

    const-string v1, "MITASHI SERVICE MENU"

    const-string v2, "Source/Input 2580 / Menu 7168 / Menu 8222 / Menu 0000 / Menu 1147 / Input 6964"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a8

    aput-object v1, v0, v2

    const-string v1, "TELEFUNKEN"

    const-string v2, "All LCD service menu codes"

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;

    move-result-object v1

    const/16 v2, 0x1a9

    aput-object v1, v0, v2

    sput-object v0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E0:[Lg1/z2;

    return-void
.end method

.method public constructor <init>()V
    .locals 13

    invoke-direct {p0}, Le/m;-><init>()V

    const-string v0, "Black 0"

    const-string v1, "Brown 1"

    const-string v2, "Red 2"

    const-string v3, "Orange 3"

    const-string v4, "Yellow 4"

    const-string v5, "Green 5"

    const-string v6, "Blue 6"

    const-string v7, "Violet 7"

    const-string v8, "Gray 8"

    const-string v9, "White 9"

    filled-new-array/range {v0 .. v9}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B:[Ljava/lang/String;

    const-string v0, "4 Band Resistor"

    const-string v1, "5 Band Resistor"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C:[Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D:[I

    const-string v1, "Black x1"

    const-string v2, "Brown x10"

    const-string v3, "Red x100"

    const-string v4, "Orange x1k"

    const-string v5, "Yellow x10k"

    const-string v6, "Green x100k"

    const-string v7, "Blue x1M"

    const-string v8, "Violet x10M"

    const-string v9, "Gray x100M"

    const-string v10, "White x1G"

    const-string v11, "Gold x0.1"

    const-string v12, "Silver x0.01"

    filled-new-array/range {v1 .. v12}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E:[Ljava/lang/String;

    const/16 v0, 0xc

    new-array v1, v0, [D

    fill-array-data v1, :array_1

    iput-object v1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->F:[D

    new-array v0, v0, [I

    fill-array-data v0, :array_2

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->G:[I

    const-string v1, "Brown +/-1%"

    const-string v2, "Red +/-2%"

    const-string v3, "Green +/-0.5%"

    const-string v4, "Blue +/-0.25%"

    const-string v5, "Violet +/-0.1%"

    const-string v6, "Gray +/-0.05%"

    const-string v7, "Gold +/-5%"

    const-string v8, "Silver +/-10%"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->H:[Ljava/lang/String;

    const-string v1, "+/-1%"

    const-string v2, "+/-2%"

    const-string v3, "+/-0.5%"

    const-string v4, "+/-0.25%"

    const-string v5, "+/-0.1%"

    const-string v6, "+/-0.05%"

    const-string v7, "+/-5%"

    const-string v8, "+/-10%"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->I:[Ljava/lang/String;

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_3

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->J:[I

    const/16 v0, 0x60

    new-array v0, v0, [D

    fill-array-data v0, :array_4

    iput-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->K:[D

    return-void

    nop

    :array_0
    .array-data 4
        -0x1000000
        -0x94c0e3
        -0x10000
        -0x9600
        -0x100
        -0xff6000
        -0xffff01
        -0x81dd32
        -0x777778
        -0x1
    .end array-data

    :array_1
    .array-data 8
        0x3ff0000000000000L    # 1.0
        0x4024000000000000L    # 10.0
        0x4059000000000000L    # 100.0
        0x408f400000000000L    # 1000.0
        0x40c3880000000000L    # 10000.0
        0x40f86a0000000000L    # 100000.0
        0x412e848000000000L    # 1000000.0
        0x416312d000000000L    # 1.0E7
        0x4197d78400000000L    # 1.0E8
        0x41cdcd6500000000L    # 1.0E9
        0x3fb999999999999aL    # 0.1
        0x3f847ae147ae147bL    # 0.01
    .end array-data

    :array_2
    .array-data 4
        -0x1000000
        -0x94c0e3
        -0x10000
        -0x9600
        -0x100
        -0xff6000
        -0xffff01
        -0x81dd32
        -0x777778
        -0x1
        -0x2b50c9
        -0x3f3f40
    .end array-data

    :array_3
    .array-data 4
        -0x94c0e3
        -0x10000
        -0xff6000
        -0xffff01
        -0x81dd32
        -0x777778
        -0x2b50c9
        -0x3f3f40
    .end array-data

    :array_4
    .array-data 8
        0x4059000000000000L    # 100.0
        0x4059800000000000L    # 102.0
        0x405a400000000000L    # 105.0
        0x405ac00000000000L    # 107.0
        0x405b800000000000L    # 110.0
        0x405c400000000000L    # 113.0
        0x405cc00000000000L    # 115.0
        0x405d800000000000L    # 118.0
        0x405e400000000000L    # 121.0
        0x405f000000000000L    # 124.0
        0x405fc00000000000L    # 127.0
        0x4060400000000000L    # 130.0
        0x4060a00000000000L    # 133.0
        0x4061200000000000L    # 137.0
        0x4061800000000000L    # 140.0
        0x4061e00000000000L    # 143.0
        0x4062600000000000L    # 147.0
        0x4062c00000000000L    # 150.0
        0x4063400000000000L    # 154.0
        0x4063c00000000000L    # 158.0
        0x4064400000000000L    # 162.0
        0x4064a00000000000L    # 165.0
        0x4065200000000000L    # 169.0
        0x4065c00000000000L    # 174.0
        0x4066400000000000L    # 178.0
        0x4066c00000000000L    # 182.0
        0x4067600000000000L    # 187.0
        0x4067e00000000000L    # 191.0
        0x4068800000000000L    # 196.0
        0x4069000000000000L    # 200.0
        0x4069a00000000000L    # 205.0
        0x406a400000000000L    # 210.0
        0x406ae00000000000L    # 215.0
        0x406ba00000000000L    # 221.0
        0x406c400000000000L    # 226.0
        0x406d000000000000L    # 232.0
        0x406da00000000000L    # 237.0
        0x406e600000000000L    # 243.0
        0x406f200000000000L    # 249.0
        0x406fe00000000000L    # 255.0
        0x4070500000000000L    # 261.0
        0x4070b00000000000L    # 267.0
        0x4071200000000000L    # 274.0
        0x4071800000000000L    # 280.0
        0x4071f00000000000L    # 287.0
        0x4072600000000000L    # 294.0
        0x4072d00000000000L    # 301.0
        0x4073500000000000L    # 309.0
        0x4073c00000000000L    # 316.0
        0x4074400000000000L    # 324.0
        0x4074c00000000000L    # 332.0
        0x4075400000000000L    # 340.0
        0x4075c00000000000L    # 348.0
        0x4076500000000000L    # 357.0
        0x4076d00000000000L    # 365.0
        0x4077600000000000L    # 374.0
        0x4077f00000000000L    # 383.0
        0x4078800000000000L    # 392.0
        0x4079200000000000L    # 402.0
        0x4079c00000000000L    # 412.0
        0x407a600000000000L    # 422.0
        0x407b000000000000L    # 432.0
        0x407ba00000000000L    # 442.0
        0x407c500000000000L    # 453.0
        0x407d000000000000L    # 464.0
        0x407db00000000000L    # 475.0
        0x407e700000000000L    # 487.0
        0x407f300000000000L    # 499.0
        0x407ff00000000000L    # 511.0
        0x4080580000000000L    # 523.0
        0x4080c00000000000L    # 536.0
        0x4081280000000000L    # 549.0
        0x4081900000000000L    # 562.0
        0x4082000000000000L    # 576.0
        0x4082700000000000L    # 590.0
        0x4082e00000000000L    # 604.0
        0x4083580000000000L    # 619.0
        0x4083d00000000000L    # 634.0
        0x4084480000000000L    # 649.0
        0x4084c80000000000L    # 665.0
        0x4085480000000000L    # 681.0
        0x4085d00000000000L    # 698.0
        0x4086580000000000L    # 715.0
        0x4086e00000000000L    # 732.0
        0x4087700000000000L    # 750.0
        0x4088000000000000L    # 768.0
        0x4088980000000000L    # 787.0
        0x4089300000000000L    # 806.0
        0x4089c80000000000L    # 825.0
        0x408a680000000000L    # 845.0
        0x408b100000000000L    # 866.0
        0x408bb80000000000L    # 887.0
        0x408c680000000000L    # 909.0
        0x408d180000000000L    # 931.0
        0x408dc80000000000L    # 953.0
        0x408e800000000000L    # 976.0
    .end array-data
.end method

.method public static D(Ljava/lang/String;Ljava/lang/String;)Lg1/z2;
    .locals 1

    .line 1
    new-instance v0, Lg1/z2;

    invoke-direct {v0, p0, p1}, Lg1/z2;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static E(D)Ljava/lang/String;
    .locals 4

    .line 1
    invoke-static {p0, p1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-static {p0, p1}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.0f"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    cmpl-double v0, v0, v2

    const-string v1, "\\.$"

    const-string v2, "0+$"

    const-string v3, ""

    if-ltz v0, :cond_2

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.2f"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.3f"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    :goto_0
    const-string p0, "--"

    return-object p0
.end method

.method public static p(Lapp/gkc/terminal/Activity/ResistorToolsActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x20

    .line 5
    .line 6
    invoke-virtual {p1, p0}, Ljava/lang/String;->indexOf(I)I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    if-lez p0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :cond_0
    return-object p1
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static r(D)Ljava/lang/String;
    .locals 6

    .line 1
    const-wide/high16 v0, 0x4024000000000000L    # 10.0

    cmpg-double v0, p0, v0

    const-string v1, "custom"

    if-ltz v0, :cond_2

    invoke-static {p0, p1}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    long-to-double v2, v2

    sub-double v2, p0, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    const-wide v4, 0x3f1a36e2eb1c432dL    # 1.0E-4

    cmpl-double v0, v2, v4

    if-lez v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-static {p0, p1}, Ljava/lang/Math;->round(D)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    move v0, p1

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x2

    if-le v2, v3, :cond_1

    const-string v2, "0"

    invoke-virtual {p0, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {p0, p1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    if-ne p1, v3, :cond_2

    const/16 p1, 0x9

    if-gt v0, p1, :cond_2

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    :goto_1
    return-object v1
.end method

.method public static s(D)Ljava/lang/String;
    .locals 4

    .line 1
    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    cmpl-double v2, v0, v2

    if-ltz v2, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " A"

    :goto_0
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-wide v2, 0x3f50624dd2f1a9fcL    # 0.001

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v1, 0x408f400000000000L    # 1000.0

    mul-double/2addr p0, v1

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " mA"

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v1, 0x412e848000000000L    # 1000000.0

    mul-double/2addr p0, v1

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " uA"

    goto :goto_0
.end method

.method public static t(D)Ljava/lang/String;
    .locals 5

    .line 1
    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v0

    const-wide v2, 0x412e848000000000L    # 1000000.0

    cmpl-double v4, v0, v2

    if-ltz v4, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    div-double/2addr p0, v2

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " Mohm"

    :goto_0
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-wide v2, 0x408f400000000000L    # 1000.0

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    div-double/2addr p0, v2

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " kohm"

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " ohm"

    goto :goto_0
.end method

.method public static u(D)Ljava/lang/String;
    .locals 4

    .line 1
    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    cmpl-double v2, v0, v2

    if-ltz v2, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " W"

    :goto_0
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-wide v2, 0x3f50624dd2f1a9fcL    # 0.001

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v1, 0x408f400000000000L    # 1000.0

    mul-double/2addr p0, v1

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " mW"

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v1, 0x412e848000000000L    # 1000000.0

    mul-double/2addr p0, v1

    invoke-static {p0, p1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " uW"

    goto :goto_0
.end method

.method public static varargs v([Landroid/widget/EditText;)[D
    .locals 9

    .line 1
    array-length v0, p0

    new-array v0, v0, [D

    array-length v1, p0

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v5, p0, v3

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    if-eqz v6, :cond_0

    add-int/lit8 v6, v4, 0x1

    invoke-static {v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z(Ljava/lang/String;)D

    move-result-wide v7

    aput-wide v7, v0, v4

    move v4, v6

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    new-array p0, v4, [D

    invoke-static {v0, v2, p0, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object p0
.end method

.method public static w(Ljava/lang/String;)D
    .locals 6

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " "

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\u00b5"

    const-string v1, "U"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\\d{3}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x3

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    int-to-double v0, v0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    int-to-double v4, p0

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    mul-double/2addr v2, v0

    return-wide v2

    :cond_0
    const-string v0, "PF"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    return-wide v0

    :cond_1
    const-string v0, "NF"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const-wide v2, 0x408f400000000000L    # 1000.0

    mul-double/2addr v0, v2

    return-wide v0

    :cond_2
    const-string v0, "UF"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const-wide v2, 0x412e848000000000L    # 1000000.0

    mul-double/2addr v0, v2

    return-wide v0

    :cond_3
    const-string v0, "MF"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const-wide v2, 0x41cdcd6500000000L    # 1.0E9

    mul-double/2addr v0, v2

    return-wide v0

    :cond_4
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    return-wide v0
.end method

.method public static x(Ljava/lang/String;)Ljava/lang/Double;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " "

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "MA"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const-wide v0, 0x3f50624dd2f1a9fcL    # 0.001

    goto :goto_0

    :cond_1
    const-string v0, "UA"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x2

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const-wide v0, 0x3eb0c6f7a0b5ed8dL    # 1.0E-6

    goto :goto_0

    :cond_2
    const-string v0, "A"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_3
    move-wide v0, v2

    :goto_0
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    mul-double/2addr v2, v0

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0
.end method

.method public static y(Ljava/lang/String;)Ljava/lang/Double;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "OHMS"

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "OHM"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\u03a9"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " "

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const/16 v0, 0x52

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    if-ltz v1, :cond_1

    const/16 v1, 0x2e

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_1
    const-string v0, "K"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const-wide v2, 0x408f400000000000L    # 1000.0

    goto :goto_0

    :cond_2
    const-string v0, "M"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const-wide v2, 0x412e848000000000L    # 1000000.0

    :cond_3
    :goto_0
    const-string v0, "."

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "0"

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_4
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    mul-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0
.end method

.method public static z(Ljava/lang/String;)D
    .locals 2

    .line 1
    invoke-static {p0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->y(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    return-wide v0

    :cond_0
    new-instance p0, Ljava/lang/NumberFormatException;

    const-string v0, "Invalid resistor value"

    invoke-direct {p0, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final A(I)V
    .locals 6

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->L:Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    const/4 v2, 0x0

    if-nez p1, :cond_0

    move v3, v2

    goto :goto_0

    :cond_0
    move v3, v1

    :goto_0
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->M:Landroid/widget/LinearLayout;

    const/4 v3, 0x1

    if-ne p1, v3, :cond_1

    move v4, v2

    goto :goto_1

    :cond_1
    move v4, v1

    :goto_1
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->N:Landroid/widget/LinearLayout;

    const/4 v4, 0x2

    if-ne p1, v4, :cond_2

    move v5, v2

    goto :goto_2

    :cond_2
    move v5, v1

    :goto_2
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->O:Landroid/widget/LinearLayout;

    const/4 v5, 0x3

    if-ne p1, v5, :cond_3

    move v5, v2

    goto :goto_3

    :cond_3
    move v5, v1

    :goto_3
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->P:Landroid/widget/LinearLayout;

    const/4 v5, 0x4

    if-ne p1, v5, :cond_4

    move v5, v2

    goto :goto_4

    :cond_4
    move v5, v1

    :goto_4
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Q:Landroid/widget/LinearLayout;

    const/4 v5, 0x5

    if-ne p1, v5, :cond_5

    move v5, v2

    goto :goto_5

    :cond_5
    move v5, v1

    :goto_5
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->R:Landroid/widget/LinearLayout;

    const/4 v5, 0x6

    if-ne p1, v5, :cond_6

    move v5, v2

    goto :goto_6

    :cond_6
    move v5, v1

    :goto_6
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->S:Landroid/widget/LinearLayout;

    const/4 v5, 0x7

    if-ne p1, v5, :cond_7

    move v1, v2

    :cond_7
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_7
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->T:[Landroid/widget/Button;

    array-length v1, v0

    if-ge v2, v1, :cond_9

    aget-object v0, v0, v2

    if-ne v2, p1, :cond_8

    const v1, 0x7f0800a7

    goto :goto_8

    :cond_8
    const v1, 0x7f0800a6

    :goto_8
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_9
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    const-string v1, "Enter value and calculate."

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-nez p1, :cond_c

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    if-eqz v0, :cond_c

    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->U:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " "

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_a

    const-string v2, "102"

    goto :goto_9

    :cond_a
    move-object v2, v0

    :goto_9
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_b

    const-string v0, "1 kOhm"

    goto :goto_a

    :cond_b
    const-string v0, "Tap FIND VALUE"

    :goto_a
    invoke-virtual {v1, v2, v0}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_c
    if-eq p1, v3, :cond_d

    if-ne p1, v4, :cond_e

    :cond_d
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q()V

    :cond_e
    return-void
.end method

.method public final B(Landroid/widget/Spinner;[Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Lg1/l;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p0, p2, v1}, Lg1/l;-><init>(Le/m;Landroid/content/Context;[Ljava/lang/String;I)V

    const p2, 0x1090009

    invoke-virtual {v0, p2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method public final C(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 23

    move-object/from16 v7, p0

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x7f0903d2

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    invoke-virtual {v7, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    :goto_0
    move-object v1, v7

    goto/16 :goto_1a

    :cond_0
    const v1, 0x7f09014a

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    invoke-virtual {v7, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    goto :goto_0

    :cond_1
    const v1, 0x7f090257

    const/4 v4, 0x2

    if-ne v0, v1, :cond_2

    invoke-virtual {v7, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    goto :goto_0

    :cond_2
    const v1, 0x7f0902ea

    const/4 v5, 0x3

    if-ne v0, v1, :cond_3

    invoke-virtual {v7, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    goto :goto_0

    :cond_3
    const v1, 0x7f09012d

    const/4 v6, 0x4

    if-ne v0, v1, :cond_4

    invoke-virtual {v7, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    goto :goto_0

    :cond_4
    const v1, 0x7f090183

    if-ne v0, v1, :cond_5

    const/4 v0, 0x5

    :goto_1
    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    goto :goto_0

    :cond_5
    const v1, 0x7f0903b8

    if-ne v0, v1, :cond_6

    const/4 v0, 0x6

    goto :goto_1

    :cond_6
    const v1, 0x7f09031c

    if-ne v0, v1, :cond_7

    const/4 v0, 0x7

    goto :goto_1

    :cond_7
    const v1, 0x7f0903d0

    const-string v8, "\nValue: "

    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    const-wide v11, 0x408f400000000000L    # 1000.0

    const-wide/high16 v13, 0x4024000000000000L    # 10.0

    const-wide/16 v16, 0x0

    if-ne v0, v1, :cond_16

    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->U:Landroid/widget/EditText;

    .line 1
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " "

    const-string v15, ""

    invoke-virtual {v0, v1, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_8

    const-string v0, "Enter SMD code."

    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto :goto_0

    :cond_8
    const/16 v1, 0x52

    .line 2
    :try_start_0
    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v15

    if-ltz v15, :cond_9

    invoke-static {v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->y(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v15

    goto/16 :goto_6

    :cond_9
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v15

    if-ne v15, v5, :cond_10

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v15

    invoke-static {v15}, Ljava/lang/Character;->isDigit(C)Z

    move-result v15

    if-eqz v15, :cond_10

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v15

    invoke-static {v15}, Ljava/lang/Character;->isDigit(C)Z

    move-result v15

    if-eqz v15, :cond_10

    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v15

    invoke-static {v15}, Ljava/lang/Character;->isLetter(C)Z

    move-result v15

    if-eqz v15, :cond_10

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    if-lt v2, v3, :cond_f

    const/16 v5, 0x60

    if-le v2, v5, :cond_a

    goto/16 :goto_3

    :cond_a
    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v5, 0x48

    if-eq v4, v5, :cond_d

    if-eq v4, v1, :cond_c

    const/16 v1, 0x53

    if-eq v4, v1, :cond_b

    packed-switch v4, :pswitch_data_0

    packed-switch v4, :pswitch_data_1

    const/4 v1, 0x0

    goto :goto_2

    :pswitch_0
    const-wide v4, 0x3f50624dd2f1a9fcL    # 0.001

    .line 3
    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :pswitch_1
    const-wide v4, 0x40f86a0000000000L    # 100000.0

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :pswitch_2
    const-wide v4, 0x40c3880000000000L    # 10000.0

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :pswitch_3
    invoke-static {v11, v12}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :pswitch_4
    const-wide/high16 v4, 0x4059000000000000L    # 100.0

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :pswitch_5
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :cond_b
    :pswitch_6
    const-wide v4, 0x3fb999999999999aL    # 0.1

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :cond_c
    :pswitch_7
    const-wide v4, 0x3f847ae147ae147bL    # 0.01

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    goto :goto_2

    :cond_d
    :pswitch_8
    invoke-static {v13, v14}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    :goto_2
    if-nez v1, :cond_e

    goto :goto_3

    :cond_e
    iget-object v4, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->K:[D

    sub-int/2addr v2, v3

    .line 4
    aget-wide v2, v4, v2

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    mul-double/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    goto :goto_6

    :catch_0
    :cond_f
    :goto_3
    const/4 v15, 0x0

    goto :goto_6

    :cond_10
    const-string v1, "\\d{3}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    const-string v1, "000"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_11

    :goto_4
    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    goto :goto_6

    :cond_11
    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {v0, v4, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    :goto_5
    int-to-double v3, v3

    invoke-static {v13, v14, v3, v4}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v3

    mul-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    goto :goto_6

    :cond_12
    const-string v1, "\\d{4}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_14

    const-string v1, "0000"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13

    goto :goto_4

    :cond_13
    invoke-virtual {v0, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {v0, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    goto :goto_5

    :cond_14
    invoke-static {v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->y(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v15
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_6
    if-nez v15, :cond_15

    const-string v1, "Unknown SMD code. Use 102, 472, 1001, 4R7, R22, or EIA-96 like 01C."

    .line 5
    invoke-virtual {v7, v1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    iget-object v1, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    const-string v2, "Not recognized"

    invoke-virtual {v1, v0, v2}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_15
    invoke-virtual {v15}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    invoke-virtual {v2, v0, v1}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "SMD "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_0

    :cond_16
    const v1, 0x7f090369

    if-ne v0, v1, :cond_27

    :try_start_1
    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->V:Landroid/widget/EditText;

    .line 6
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z(Ljava/lang/String;)D

    move-result-wide v9

    cmpg-double v0, v9, v16

    if-gtz v0, :cond_17

    const-string v0, "Enter resistor value greater than zero."

    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_17
    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->o0:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v0

    if-ne v0, v3, :cond_18

    move v11, v3

    goto :goto_7

    :cond_18
    move v11, v2

    :goto_7
    if-eqz v11, :cond_19

    move v12, v5

    goto :goto_8

    :cond_19
    move v12, v4

    :goto_8
    if-eqz v11, :cond_1a

    const/16 v0, 0x64

    move v5, v0

    goto :goto_9

    :cond_1a
    const/16 v5, 0xa

    :goto_9
    if-eqz v11, :cond_1b

    const/16 v0, 0x3e7

    :goto_a
    move v6, v0

    goto :goto_b

    :cond_1b
    const/16 v0, 0x63

    goto :goto_a

    :goto_b
    const-wide v0, 0x7fefffffffffffffL    # Double.MAX_VALUE

    const/4 v2, 0x0

    const/4 v3, -0x2

    :goto_c
    const/16 v15, 0x9

    if-gt v3, v15, :cond_23

    move/from16 v17, v5

    int-to-double v4, v3

    .line 7
    invoke-static {v13, v14, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v4

    div-double v19, v9, v4

    invoke-static/range {v19 .. v20}, Ljava/lang/Math;->round(D)J

    move-result-wide v13

    long-to-int v13, v13

    move/from16 v14, v17

    if-lt v13, v14, :cond_1c

    if-le v13, v6, :cond_1d

    :cond_1c
    move v13, v3

    move/from16 v18, v6

    move/from16 v17, v14

    const/16 v19, -0x2

    goto :goto_e

    :cond_1d
    if-ltz v3, :cond_1e

    if-gt v3, v15, :cond_1e

    move/from16 v17, v3

    const/4 v15, -0x2

    goto :goto_d

    :cond_1e
    const/4 v15, -0x1

    if-ne v3, v15, :cond_1f

    const/4 v15, -0x2

    const/16 v17, 0xa

    goto :goto_d

    :cond_1f
    const/4 v15, -0x2

    if-ne v3, v15, :cond_20

    const/16 v17, 0xb

    goto :goto_d

    :cond_20
    const/16 v17, -0x1

    :goto_d
    if-gez v17, :cond_21

    move v13, v3

    move/from16 v18, v6

    move/from16 v17, v14

    move/from16 v19, v15

    goto :goto_e

    :cond_21
    move/from16 v18, v14

    int-to-double v14, v13

    mul-double/2addr v14, v4

    sub-double v4, v14, v9

    .line 8
    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v21

    cmpg-double v4, v21, v0

    if-gez v4, :cond_22

    new-instance v20, Lg1/y2;

    move-object/from16 v0, v20

    move-object/from16 v1, p0

    move v2, v13

    move v13, v3

    move v3, v12

    const/16 v19, -0x2

    move/from16 v4, v17

    move/from16 v17, v18

    move/from16 v18, v6

    move-wide v5, v14

    invoke-direct/range {v0 .. v6}, Lg1/y2;-><init>(Lapp/gkc/terminal/Activity/ResistorToolsActivity;IIID)V

    move-object/from16 v2, v20

    move-wide/from16 v0, v21

    goto :goto_e

    :cond_22
    move v13, v3

    move/from16 v17, v18

    const/16 v19, -0x2

    move/from16 v18, v6

    :goto_e
    add-int/lit8 v3, v13, 0x1

    move/from16 v5, v17

    move/from16 v6, v18

    const-wide/high16 v13, 0x4024000000000000L    # 10.0

    goto :goto_c

    :cond_23
    if-nez v2, :cond_24

    const-string v0, "Value outside color band range."

    .line 9
    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_24
    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    iget v1, v2, Lg1/y2;->a:I

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    iget v1, v2, Lg1/y2;->b:I

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    if-eqz v11, :cond_25

    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    iget v1, v2, Lg1/y2;->c:I

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    :cond_25
    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    iget v1, v2, Lg1/y2;->d:I

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q()V

    iget-object v0, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz v11, :cond_26

    const-string v3, "5 Band Resistor"

    goto :goto_f

    :cond_26
    const-string v3, "4 Band Resistor"

    :goto_f
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, v2, Lg1/y2;->e:D

    invoke-static {v3, v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\nBands: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v2, Lg1/y2;->f:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\nTolerance: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->I:[Ljava/lang/String;

    iget-object v3, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v3

    aget-object v2, v2, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    goto/16 :goto_0

    :catch_1
    const-string v0, "Use values like 220, 4.7k, 1M, 0.22."

    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_27
    const-string v1, " V"

    const v8, 0x7f0902e9

    const-string v13, "\nPower: "

    const-string v14, "\nCurrent: "

    if-ne v0, v8, :cond_31

    const-string v0, "Voltage: "

    :try_start_2
    iget-object v5, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->W:Landroid/widget/EditText;

    .line 10
    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 11
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_28

    const/4 v5, 0x0

    goto :goto_10

    :cond_28
    invoke-static {v5}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    :goto_10
    iget-object v6, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->X:Landroid/widget/EditText;

    .line 12
    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->x(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v6

    iget-object v8, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Y:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    .line 13
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    if-nez v9, :cond_29

    const/4 v15, 0x0

    goto :goto_11

    :cond_29
    invoke-static {v8}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z(Ljava/lang/String;)D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    :goto_11
    if-eqz v5, :cond_2a

    move v8, v3

    goto :goto_12

    :cond_2a
    move v8, v2

    :goto_12
    if-eqz v6, :cond_2b

    move v9, v3

    goto :goto_13

    :cond_2b
    move v9, v2

    :goto_13
    add-int/2addr v8, v9

    if-eqz v15, :cond_2c

    move v2, v3

    :cond_2c
    add-int/2addr v8, v2

    if-ge v8, v4, :cond_2d

    const-string v0, "Enter any two values: V, I or R."

    .line 14
    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_2d
    if-nez v5, :cond_2e

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-virtual {v15}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    mul-double/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    goto :goto_14

    :cond_2e
    if-nez v6, :cond_2f

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-virtual {v15}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v8

    div-double/2addr v2, v8

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    goto :goto_14

    :cond_2f
    if-nez v15, :cond_30

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v8

    div-double/2addr v2, v8

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    :cond_30
    :goto_14
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v8

    mul-double/2addr v2, v8

    iget-object v4, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v9

    .line 15
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v9, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 16
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\nResistance: "

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2, v3}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_2

    goto/16 :goto_0

    :catch_2
    const-string v0, "Use values like 5, 0.02, 20mA, 4.7k."

    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_31
    const v8, 0x7f09012b

    if-ne v0, v8, :cond_34

    const-string v0, "Capacitor value\npF: "

    :try_start_3
    iget-object v1, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Z:Landroid/widget/EditText;

    .line 17
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_32

    const-string v0, "Enter capacitor code or value."

    :goto_15
    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_32
    invoke-static {v1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w(Ljava/lang/String;)D

    move-result-wide v1

    cmpg-double v3, v1, v16

    if-gtz v3, :cond_33

    const-string v0, "Capacitor value must be greater than zero."

    goto :goto_15

    :cond_33
    iget-object v3, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " pF\nnF: "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-double v5, v1, v11

    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " nF\nuF: "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide v5, 0x412e848000000000L    # 1000000.0

    div-double v5, v1, v5

    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " uF\nCode: "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_3
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3} :catch_3

    goto/16 :goto_0

    :catch_3
    const-string v0, "Use values like 104, 473, 220pF, 100nF, 4.7uF."

    invoke-virtual {v7, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_34
    const v8, 0x7f090182

    if-ne v0, v8, :cond_37

    const-string v0, "Vout: "

    :try_start_4
    iget-object v2, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->a0:Landroid/widget/EditText;

    .line 18
    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    iget-object v4, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->b0:Landroid/widget/EditText;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z(Ljava/lang/String;)D

    move-result-wide v4

    iget-object v6, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->c0:Landroid/widget/EditText;

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z(Ljava/lang/String;)D

    move-result-wide v8
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_4 .. :try_end_4} :catch_5

    cmpg-double v6, v4, v16

    if-ltz v6, :cond_36

    cmpg-double v6, v8, v16

    if-ltz v6, :cond_36

    add-double v10, v4, v8

    cmpl-double v6, v10, v16

    if-nez v6, :cond_35

    goto :goto_16

    :cond_35
    mul-double v15, v2, v8

    div-double/2addr v15, v10

    div-double v10, v2, v10

    mul-double v17, v2, v10

    :try_start_5
    iget-object v6, v7, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {v15 .. v16}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 20
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\nRatio: "

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-double/2addr v15, v2

    invoke-static/range {v15 .. v16}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v10, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {v17 .. v18}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\nR1: "

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4, v5}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\nR2: "

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v8, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    move-object/from16 v1, p0

    goto/16 :goto_1a

    :catch_4
    move-object/from16 v1, p0

    goto :goto_17

    :cond_36
    :goto_16
    const-string v0, "R1 and R2 must be valid positive values."
    :try_end_5
    .catch Ljava/lang/NumberFormatException; {:try_start_5 .. :try_end_5} :catch_4

    move-object/from16 v1, p0

    :try_start_6
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/NumberFormatException; {:try_start_6 .. :try_end_6} :catch_6

    goto/16 :goto_1a

    :catch_5
    move-object v1, v7

    :catch_6
    :goto_17
    const-string v0, "Enter Vin, R1 and R2 correctly."

    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_1a

    :cond_37
    move-object v1, v7

    const v7, 0x7f0903b7

    const-string v8, "\nParts: "

    const-string v11, "Enter resistor values."

    if-ne v0, v7, :cond_3a

    :try_start_7
    new-array v0, v6, [Landroid/widget/EditText;

    iget-object v6, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->d0:Landroid/widget/EditText;

    aput-object v6, v0, v2

    iget-object v6, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->e0:Landroid/widget/EditText;

    aput-object v6, v0, v3

    iget-object v3, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->f0:Landroid/widget/EditText;

    aput-object v3, v0, v4

    iget-object v3, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->g0:Landroid/widget/EditText;

    aput-object v3, v0, v5

    .line 21
    invoke-static {v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v([Landroid/widget/EditText;)[D

    move-result-object v0

    array-length v3, v0

    if-nez v3, :cond_38

    invoke-virtual {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto/16 :goto_1a

    :cond_38
    array-length v3, v0

    :goto_18
    if-ge v2, v3, :cond_39

    aget-wide v4, v0, v2

    add-double v16, v16, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_18

    :cond_39
    iget-object v2, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Series total: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {v16 .. v17}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v0, v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_7
    .catch Ljava/lang/NumberFormatException; {:try_start_7 .. :try_end_7} :catch_7

    goto :goto_1a

    :catch_7
    const-string v0, "Use values like 100, 220, 4.7k, 1M."

    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto :goto_1a

    :cond_3a
    const v7, 0x7f09031b

    if-ne v0, v7, :cond_3e

    :try_start_8
    new-array v0, v6, [Landroid/widget/EditText;

    iget-object v6, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->h0:Landroid/widget/EditText;

    aput-object v6, v0, v2

    iget-object v6, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->i0:Landroid/widget/EditText;

    aput-object v6, v0, v3

    iget-object v3, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->j0:Landroid/widget/EditText;

    aput-object v3, v0, v4

    iget-object v3, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->k0:Landroid/widget/EditText;

    aput-object v3, v0, v5

    .line 22
    invoke-static {v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v([Landroid/widget/EditText;)[D

    move-result-object v0

    array-length v3, v0

    if-nez v3, :cond_3b

    invoke-virtual {v1, v11}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto :goto_1a

    :cond_3b
    array-length v3, v0

    move-wide/from16 v4, v16

    :goto_19
    if-ge v2, v3, :cond_3d

    aget-wide v6, v0, v2

    cmpg-double v11, v6, v16

    if-gtz v11, :cond_3c

    const-string v0, "Parallel values must be greater than zero."

    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    goto :goto_1a

    :cond_3c
    div-double v6, v9, v6

    add-double/2addr v4, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_19

    :cond_3d
    iget-object v2, v1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Parallel total: "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-double/2addr v9, v4

    invoke-static {v9, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v0, v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_8
    .catch Ljava/lang/NumberFormatException; {:try_start_8 .. :try_end_8} :catch_8

    goto :goto_1a

    :catch_8
    const-string v0, "Use values like 10k, 10k, 4.7k."

    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C(Ljava/lang/String;)V

    :cond_3e
    :goto_1a
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x41
        :pswitch_5
        :pswitch_8
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x58
        :pswitch_6
        :pswitch_7
        :pswitch_0
    .end packed-switch
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 11

    .line 1
    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    const p1, 0x7f0c0032

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    .line 8
    .line 9
    .line 10
    const p1, 0x7f0903d3

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    check-cast p1, Landroid/widget/LinearLayout;

    .line 18
    .line 19
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->L:Landroid/widget/LinearLayout;

    .line 20
    .line 21
    const p1, 0x7f09014b

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Landroid/widget/LinearLayout;

    .line 29
    .line 30
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->M:Landroid/widget/LinearLayout;

    .line 31
    .line 32
    const p1, 0x7f090258

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    check-cast p1, Landroid/widget/LinearLayout;

    .line 40
    .line 41
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->N:Landroid/widget/LinearLayout;

    .line 42
    .line 43
    const p1, 0x7f0902eb

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, Landroid/widget/LinearLayout;

    .line 51
    .line 52
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->O:Landroid/widget/LinearLayout;

    .line 53
    .line 54
    const p1, 0x7f09012e

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    check-cast p1, Landroid/widget/LinearLayout;

    .line 62
    .line 63
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->P:Landroid/widget/LinearLayout;

    .line 64
    .line 65
    const p1, 0x7f090184

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    check-cast p1, Landroid/widget/LinearLayout;

    .line 73
    .line 74
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Q:Landroid/widget/LinearLayout;

    .line 75
    .line 76
    const p1, 0x7f0903b9

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    check-cast p1, Landroid/widget/LinearLayout;

    .line 84
    .line 85
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->R:Landroid/widget/LinearLayout;

    .line 86
    .line 87
    const p1, 0x7f09031d

    .line 88
    .line 89
    .line 90
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    check-cast p1, Landroid/widget/LinearLayout;

    .line 95
    .line 96
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->S:Landroid/widget/LinearLayout;

    .line 97
    .line 98
    const/16 p1, 0x8

    .line 99
    .line 100
    new-array p1, p1, [Landroid/widget/Button;

    .line 101
    .line 102
    const v0, 0x7f0903d2

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Landroid/widget/Button;

    .line 110
    .line 111
    const/4 v1, 0x0

    .line 112
    aput-object v0, p1, v1

    .line 113
    .line 114
    const v0, 0x7f09014a

    .line 115
    .line 116
    .line 117
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    check-cast v0, Landroid/widget/Button;

    .line 122
    .line 123
    const/4 v2, 0x1

    .line 124
    aput-object v0, p1, v2

    .line 125
    .line 126
    const v0, 0x7f090257

    .line 127
    .line 128
    .line 129
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    check-cast v0, Landroid/widget/Button;

    .line 134
    .line 135
    const/4 v3, 0x2

    .line 136
    aput-object v0, p1, v3

    .line 137
    .line 138
    const v0, 0x7f0902ea

    .line 139
    .line 140
    .line 141
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    check-cast v0, Landroid/widget/Button;

    .line 146
    .line 147
    const/4 v4, 0x3

    .line 148
    aput-object v0, p1, v4

    .line 149
    .line 150
    const v0, 0x7f09012d

    .line 151
    .line 152
    .line 153
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    check-cast v0, Landroid/widget/Button;

    .line 158
    .line 159
    const/4 v5, 0x4

    .line 160
    aput-object v0, p1, v5

    .line 161
    .line 162
    const v0, 0x7f090183

    .line 163
    .line 164
    .line 165
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Landroid/widget/Button;

    .line 170
    .line 171
    const/4 v6, 0x5

    .line 172
    aput-object v0, p1, v6

    .line 173
    .line 174
    const v0, 0x7f0903b8

    .line 175
    .line 176
    .line 177
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    check-cast v0, Landroid/widget/Button;

    .line 182
    .line 183
    const/4 v7, 0x6

    .line 184
    aput-object v0, p1, v7

    .line 185
    .line 186
    const v0, 0x7f09031c

    .line 187
    .line 188
    .line 189
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    check-cast v0, Landroid/widget/Button;

    .line 194
    .line 195
    const/4 v8, 0x7

    .line 196
    aput-object v0, p1, v8

    .line 197
    .line 198
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->T:[Landroid/widget/Button;

    .line 199
    .line 200
    const p1, 0x7f0903d1

    .line 201
    .line 202
    .line 203
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    check-cast p1, Landroid/widget/EditText;

    .line 208
    .line 209
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->U:Landroid/widget/EditText;

    .line 210
    .line 211
    const p1, 0x7f090368

    .line 212
    .line 213
    .line 214
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    check-cast p1, Landroid/widget/EditText;

    .line 219
    .line 220
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->V:Landroid/widget/EditText;

    .line 221
    .line 222
    const p1, 0x7f090455

    .line 223
    .line 224
    .line 225
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 226
    .line 227
    .line 228
    move-result-object p1

    .line 229
    check-cast p1, Landroid/widget/EditText;

    .line 230
    .line 231
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->W:Landroid/widget/EditText;

    .line 232
    .line 233
    const p1, 0x7f090163

    .line 234
    .line 235
    .line 236
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    check-cast p1, Landroid/widget/EditText;

    .line 241
    .line 242
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->X:Landroid/widget/EditText;

    .line 243
    .line 244
    const p1, 0x7f09036a

    .line 245
    .line 246
    .line 247
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    check-cast p1, Landroid/widget/EditText;

    .line 252
    .line 253
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Y:Landroid/widget/EditText;

    .line 254
    .line 255
    const p1, 0x7f09012c

    .line 256
    .line 257
    .line 258
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 259
    .line 260
    .line 261
    move-result-object p1

    .line 262
    check-cast p1, Landroid/widget/EditText;

    .line 263
    .line 264
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->Z:Landroid/widget/EditText;

    .line 265
    .line 266
    const p1, 0x7f090452

    .line 267
    .line 268
    .line 269
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 270
    .line 271
    .line 272
    move-result-object p1

    .line 273
    check-cast p1, Landroid/widget/EditText;

    .line 274
    .line 275
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->a0:Landroid/widget/EditText;

    .line 276
    .line 277
    const p1, 0x7f090348

    .line 278
    .line 279
    .line 280
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 281
    .line 282
    .line 283
    move-result-object p1

    .line 284
    check-cast p1, Landroid/widget/EditText;

    .line 285
    .line 286
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->b0:Landroid/widget/EditText;

    .line 287
    .line 288
    const p1, 0x7f090349

    .line 289
    .line 290
    .line 291
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    check-cast p1, Landroid/widget/EditText;

    .line 296
    .line 297
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->c0:Landroid/widget/EditText;

    .line 298
    .line 299
    const p1, 0x7f0903bb

    .line 300
    .line 301
    .line 302
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    check-cast p1, Landroid/widget/EditText;

    .line 307
    .line 308
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->d0:Landroid/widget/EditText;

    .line 309
    .line 310
    const p1, 0x7f0903bc

    .line 311
    .line 312
    .line 313
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 314
    .line 315
    .line 316
    move-result-object p1

    .line 317
    check-cast p1, Landroid/widget/EditText;

    .line 318
    .line 319
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->e0:Landroid/widget/EditText;

    .line 320
    .line 321
    const p1, 0x7f0903bd

    .line 322
    .line 323
    .line 324
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 325
    .line 326
    .line 327
    move-result-object p1

    .line 328
    check-cast p1, Landroid/widget/EditText;

    .line 329
    .line 330
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->f0:Landroid/widget/EditText;

    .line 331
    .line 332
    const p1, 0x7f0903be

    .line 333
    .line 334
    .line 335
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    check-cast p1, Landroid/widget/EditText;

    .line 340
    .line 341
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->g0:Landroid/widget/EditText;

    .line 342
    .line 343
    const p1, 0x7f09031f

    .line 344
    .line 345
    .line 346
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 347
    .line 348
    .line 349
    move-result-object p1

    .line 350
    check-cast p1, Landroid/widget/EditText;

    .line 351
    .line 352
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->h0:Landroid/widget/EditText;

    .line 353
    .line 354
    const p1, 0x7f090320

    .line 355
    .line 356
    .line 357
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    check-cast p1, Landroid/widget/EditText;

    .line 362
    .line 363
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->i0:Landroid/widget/EditText;

    .line 364
    .line 365
    const p1, 0x7f090321

    .line 366
    .line 367
    .line 368
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 369
    .line 370
    .line 371
    move-result-object p1

    .line 372
    check-cast p1, Landroid/widget/EditText;

    .line 373
    .line 374
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->j0:Landroid/widget/EditText;

    .line 375
    .line 376
    const p1, 0x7f090322

    .line 377
    .line 378
    .line 379
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 380
    .line 381
    .line 382
    move-result-object p1

    .line 383
    check-cast p1, Landroid/widget/EditText;

    .line 384
    .line 385
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->k0:Landroid/widget/EditText;

    .line 386
    .line 387
    const p1, 0x7f090362

    .line 388
    .line 389
    .line 390
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 391
    .line 392
    .line 393
    move-result-object p1

    .line 394
    check-cast p1, Landroid/widget/Spinner;

    .line 395
    .line 396
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 397
    .line 398
    const p1, 0x7f090363

    .line 399
    .line 400
    .line 401
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 402
    .line 403
    .line 404
    move-result-object p1

    .line 405
    check-cast p1, Landroid/widget/Spinner;

    .line 406
    .line 407
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 408
    .line 409
    const p1, 0x7f090364

    .line 410
    .line 411
    .line 412
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 413
    .line 414
    .line 415
    move-result-object p1

    .line 416
    check-cast p1, Landroid/widget/Spinner;

    .line 417
    .line 418
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 419
    .line 420
    const p1, 0x7f090365

    .line 421
    .line 422
    .line 423
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 424
    .line 425
    .line 426
    move-result-object p1

    .line 427
    check-cast p1, Landroid/widget/Spinner;

    .line 428
    .line 429
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->o0:Landroid/widget/Spinner;

    .line 430
    .line 431
    const p1, 0x7f090366

    .line 432
    .line 433
    .line 434
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 435
    .line 436
    .line 437
    move-result-object p1

    .line 438
    check-cast p1, Landroid/widget/Spinner;

    .line 439
    .line 440
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 441
    .line 442
    const p1, 0x7f090367

    .line 443
    .line 444
    .line 445
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    check-cast p1, Landroid/widget/Spinner;

    .line 450
    .line 451
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 452
    .line 453
    const p1, 0x7f090252

    .line 454
    .line 455
    .line 456
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 457
    .line 458
    .line 459
    move-result-object p1

    .line 460
    check-cast p1, Landroid/widget/Spinner;

    .line 461
    .line 462
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 463
    .line 464
    const p1, 0x7f090253

    .line 465
    .line 466
    .line 467
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 468
    .line 469
    .line 470
    move-result-object p1

    .line 471
    check-cast p1, Landroid/widget/Spinner;

    .line 472
    .line 473
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 474
    .line 475
    const p1, 0x7f090254

    .line 476
    .line 477
    .line 478
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 479
    .line 480
    .line 481
    move-result-object p1

    .line 482
    check-cast p1, Landroid/widget/Spinner;

    .line 483
    .line 484
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 485
    .line 486
    const p1, 0x7f090255

    .line 487
    .line 488
    .line 489
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 490
    .line 491
    .line 492
    move-result-object p1

    .line 493
    check-cast p1, Landroid/widget/Spinner;

    .line 494
    .line 495
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 496
    .line 497
    const p1, 0x7f0903d4

    .line 498
    .line 499
    .line 500
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 501
    .line 502
    .line 503
    move-result-object p1

    .line 504
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 505
    .line 506
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 507
    .line 508
    const p1, 0x7f09036b

    .line 509
    .line 510
    .line 511
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 512
    .line 513
    .line 514
    move-result-object p1

    .line 515
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 516
    .line 517
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 518
    .line 519
    const p1, 0x7f090259

    .line 520
    .line 521
    .line 522
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 523
    .line 524
    .line 525
    move-result-object p1

    .line 526
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 527
    .line 528
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->x0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 529
    .line 530
    const p1, 0x7f090185

    .line 531
    .line 532
    .line 533
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 538
    .line 539
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->y0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 540
    .line 541
    const p1, 0x7f0902ec

    .line 542
    .line 543
    .line 544
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 545
    .line 546
    .line 547
    move-result-object p1

    .line 548
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 549
    .line 550
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 551
    .line 552
    const p1, 0x7f09012f

    .line 553
    .line 554
    .line 555
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 556
    .line 557
    .line 558
    move-result-object p1

    .line 559
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 560
    .line 561
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 562
    .line 563
    const p1, 0x7f0903ba

    .line 564
    .line 565
    .line 566
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 567
    .line 568
    .line 569
    move-result-object p1

    .line 570
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 571
    .line 572
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 573
    .line 574
    const p1, 0x7f09031e

    .line 575
    .line 576
    .line 577
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 578
    .line 579
    .line 580
    move-result-object p1

    .line 581
    check-cast p1, Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 582
    .line 583
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 584
    .line 585
    const p1, 0x7f09036e

    .line 586
    .line 587
    .line 588
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 589
    .line 590
    .line 591
    move-result-object p1

    .line 592
    check-cast p1, Landroid/widget/TextView;

    .line 593
    .line 594
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    .line 595
    .line 596
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->o0:Landroid/widget/Spinner;

    .line 597
    .line 598
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C:[Ljava/lang/String;

    .line 599
    .line 600
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 601
    .line 602
    .line 603
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 604
    .line 605
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B:[Ljava/lang/String;

    .line 606
    .line 607
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 608
    .line 609
    .line 610
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 611
    .line 612
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 613
    .line 614
    .line 615
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 616
    .line 617
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 618
    .line 619
    .line 620
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 621
    .line 622
    iget-object v9, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E:[Ljava/lang/String;

    .line 623
    .line 624
    invoke-virtual {p0, p1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 625
    .line 626
    .line 627
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 628
    .line 629
    iget-object v10, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->H:[Ljava/lang/String;

    .line 630
    .line 631
    invoke-virtual {p0, p1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 632
    .line 633
    .line 634
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 635
    .line 636
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 637
    .line 638
    .line 639
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 640
    .line 641
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 642
    .line 643
    .line 644
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 645
    .line 646
    invoke-virtual {p0, p1, v9}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 647
    .line 648
    .line 649
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 650
    .line 651
    invoke-virtual {p0, p1, v10}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B(Landroid/widget/Spinner;[Ljava/lang/String;)V

    .line 652
    .line 653
    .line 654
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 655
    .line 656
    invoke-virtual {p1, v6}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 657
    .line 658
    .line 659
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 660
    .line 661
    invoke-virtual {p1, v7}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 662
    .line 663
    .line 664
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 665
    .line 666
    invoke-virtual {p1, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 667
    .line 668
    .line 669
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 670
    .line 671
    invoke-virtual {p1, v3}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 672
    .line 673
    .line 674
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 675
    .line 676
    invoke-virtual {p1, v7}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 677
    .line 678
    .line 679
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 680
    .line 681
    invoke-virtual {p1, v2}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 682
    .line 683
    .line 684
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 685
    .line 686
    invoke-virtual {p1, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 687
    .line 688
    .line 689
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 690
    .line 691
    const/16 v0, 0xa

    .line 692
    .line 693
    invoke-virtual {p1, v0}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 694
    .line 695
    .line 696
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 697
    .line 698
    invoke-virtual {p1, v8}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 699
    .line 700
    .line 701
    new-instance p1, Li/d2;

    .line 702
    .line 703
    invoke-direct {p1, v3, p0}, Li/d2;-><init>(ILjava/lang/Object;)V

    .line 704
    .line 705
    .line 706
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 707
    .line 708
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 709
    .line 710
    .line 711
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 712
    .line 713
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 714
    .line 715
    .line 716
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 717
    .line 718
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 719
    .line 720
    .line 721
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->o0:Landroid/widget/Spinner;

    .line 722
    .line 723
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 724
    .line 725
    .line 726
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 727
    .line 728
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 729
    .line 730
    .line 731
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 732
    .line 733
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 734
    .line 735
    .line 736
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 737
    .line 738
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 739
    .line 740
    .line 741
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 742
    .line 743
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 744
    .line 745
    .line 746
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 747
    .line 748
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 749
    .line 750
    .line 751
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 752
    .line 753
    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 754
    .line 755
    .line 756
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 757
    .line 758
    invoke-virtual {p1, v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 759
    .line 760
    .line 761
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->w0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 762
    .line 763
    const-string v0, "102"

    .line 764
    .line 765
    const-string v5, "1 kOhm"

    .line 766
    .line 767
    invoke-virtual {p1, v0, v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 768
    .line 769
    .line 770
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 771
    .line 772
    invoke-virtual {p1, v1}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 773
    .line 774
    .line 775
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->x0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 776
    .line 777
    invoke-virtual {p1, v2}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 778
    .line 779
    .line 780
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->y0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 781
    .line 782
    invoke-virtual {p1, v3}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 783
    .line 784
    .line 785
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->z0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 786
    .line 787
    invoke-virtual {p1, v4}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 788
    .line 789
    .line 790
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 791
    .line 792
    invoke-virtual {p1, v8}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 793
    .line 794
    .line 795
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->B0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 796
    .line 797
    invoke-virtual {p1, v6}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 798
    .line 799
    .line 800
    iget-object p1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->C0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 801
    .line 802
    invoke-virtual {p1, v7}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setType(I)V

    .line 803
    .line 804
    .line 805
    const/16 p1, 0xf

    .line 806
    .line 807
    new-array v0, p1, [I

    .line 808
    .line 809
    fill-array-data v0, :array_0

    .line 810
    .line 811
    .line 812
    move v2, v1

    .line 813
    :goto_0
    if-ge v2, p1, :cond_0

    .line 814
    .line 815
    aget v3, v0, v2

    .line 816
    .line 817
    invoke-virtual {p0, v3}, Le/m;->findViewById(I)Landroid/view/View;

    .line 818
    .line 819
    .line 820
    move-result-object v3

    .line 821
    invoke-virtual {v3, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 822
    .line 823
    .line 824
    add-int/lit8 v2, v2, 0x1

    .line 825
    .line 826
    goto :goto_0

    .line 827
    :cond_0
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->A(I)V

    .line 828
    .line 829
    .line 830
    return-void

    .line 831
    :array_0
    .array-data 4
        0x7f0903d2
        0x7f09014a
        0x7f090257
        0x7f0902ea
        0x7f09012d
        0x7f090183
        0x7f0903b8
        0x7f09031c
        0x7f0903d0
        0x7f090369
        0x7f0902e9
        0x7f090182
        0x7f0903b7
        0x7f09031b
        0x7f09012b
    .end array-data
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final q()V
    .locals 11

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->x0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    goto/16 :goto_7

    .line 10
    .line 11
    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->o0:Landroid/widget/Spinner;

    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0

    .line 18
    const/4 v2, 0x1

    .line 19
    if-ne v0, v2, :cond_1

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_1
    move v2, v1

    .line 23
    :goto_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 24
    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_2
    const/16 v1, 0x8

    .line 29
    .line 30
    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->J:[I

    .line 34
    .line 35
    iget-object v1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->G:[I

    .line 36
    .line 37
    iget-object v3, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D:[I

    .line 38
    .line 39
    iget-object v4, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->v0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 40
    .line 41
    iget-object v5, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 42
    .line 43
    invoke-virtual {v5}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    if-eqz v2, :cond_3

    .line 48
    .line 49
    aget v5, v3, v5

    .line 50
    .line 51
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 52
    .line 53
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 54
    .line 55
    .line 56
    move-result v6

    .line 57
    aget v6, v3, v6

    .line 58
    .line 59
    iget-object v7, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 60
    .line 61
    invoke-virtual {v7}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 62
    .line 63
    .line 64
    move-result v7

    .line 65
    aget v7, v3, v7

    .line 66
    .line 67
    iget-object v8, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 68
    .line 69
    invoke-virtual {v8}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 70
    .line 71
    .line 72
    move-result v8

    .line 73
    aget v8, v1, v8

    .line 74
    .line 75
    iget-object v9, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 76
    .line 77
    invoke-virtual {v9}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 78
    .line 79
    .line 80
    move-result v9

    .line 81
    aget v9, v0, v9

    .line 82
    .line 83
    filled-new-array {v5, v6, v7, v8, v9}, [I

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    invoke-virtual {v4, v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setBands([I)V

    .line 88
    .line 89
    .line 90
    goto :goto_2

    .line 91
    :cond_3
    aget v5, v3, v5

    .line 92
    .line 93
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 94
    .line 95
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 96
    .line 97
    .line 98
    move-result v6

    .line 99
    aget v6, v3, v6

    .line 100
    .line 101
    iget-object v7, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 102
    .line 103
    invoke-virtual {v7}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 104
    .line 105
    .line 106
    move-result v7

    .line 107
    aget v7, v1, v7

    .line 108
    .line 109
    iget-object v8, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 110
    .line 111
    invoke-virtual {v8}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 112
    .line 113
    .line 114
    move-result v8

    .line 115
    aget v8, v0, v8

    .line 116
    .line 117
    filled-new-array {v5, v6, v7, v8}, [I

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    invoke-virtual {v4, v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setBands([I)V

    .line 122
    .line 123
    .line 124
    :goto_2
    iget-object v4, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->x0:Lapp/gkc/terminal/Activity/ComponentPreviewView;

    .line 125
    .line 126
    iget-object v5, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 127
    .line 128
    invoke-virtual {v5}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 129
    .line 130
    .line 131
    move-result v5

    .line 132
    aget v5, v3, v5

    .line 133
    .line 134
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 135
    .line 136
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 137
    .line 138
    .line 139
    move-result v6

    .line 140
    aget v3, v3, v6

    .line 141
    .line 142
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 143
    .line 144
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    aget v1, v1, v6

    .line 149
    .line 150
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 151
    .line 152
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 153
    .line 154
    .line 155
    move-result v6

    .line 156
    aget v0, v0, v6

    .line 157
    .line 158
    filled-new-array {v5, v3, v1, v0}, [I

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    invoke-virtual {v4, v0}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->setBands([I)V

    .line 163
    .line 164
    .line 165
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->M:Landroid/widget/LinearLayout;

    .line 166
    .line 167
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    iget-object v1, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->I:[Ljava/lang/String;

    .line 172
    .line 173
    const-string v3, " "

    .line 174
    .line 175
    iget-object v4, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->F:[D

    .line 176
    .line 177
    if-nez v0, :cond_6

    .line 178
    .line 179
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->l0:Landroid/widget/Spinner;

    .line 180
    .line 181
    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    iget-object v5, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->m0:Landroid/widget/Spinner;

    .line 186
    .line 187
    invoke-virtual {v5}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 188
    .line 189
    .line 190
    move-result v5

    .line 191
    iget-object v6, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->n0:Landroid/widget/Spinner;

    .line 192
    .line 193
    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 194
    .line 195
    .line 196
    move-result v6

    .line 197
    if-eqz v2, :cond_4

    .line 198
    .line 199
    mul-int/lit8 v0, v0, 0x64

    .line 200
    .line 201
    mul-int/lit8 v5, v5, 0xa

    .line 202
    .line 203
    add-int/2addr v5, v0

    .line 204
    add-int/2addr v5, v6

    .line 205
    goto :goto_3

    .line 206
    :cond_4
    mul-int/lit8 v0, v0, 0xa

    .line 207
    .line 208
    add-int/2addr v5, v0

    .line 209
    :goto_3
    int-to-double v5, v5

    .line 210
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->p0:Landroid/widget/Spinner;

    .line 211
    .line 212
    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    aget-wide v7, v4, v0

    .line 217
    .line 218
    mul-double/2addr v5, v7

    .line 219
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    .line 220
    .line 221
    new-instance v4, Ljava/lang/StringBuilder;

    .line 222
    .line 223
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 224
    .line 225
    .line 226
    if-eqz v2, :cond_5

    .line 227
    .line 228
    const-string v2, "5 Band Resistor: "

    .line 229
    .line 230
    goto :goto_4

    .line 231
    :cond_5
    const-string v2, "4 Band Resistor: "

    .line 232
    .line 233
    :goto_4
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t(D)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v2

    .line 240
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 244
    .line 245
    .line 246
    iget-object v2, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->q0:Landroid/widget/Spinner;

    .line 247
    .line 248
    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 249
    .line 250
    .line 251
    move-result v2

    .line 252
    aget-object v1, v1, v2

    .line 253
    .line 254
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 255
    .line 256
    .line 257
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 262
    .line 263
    .line 264
    goto/16 :goto_7

    .line 265
    .line 266
    :cond_6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->N:Landroid/widget/LinearLayout;

    .line 267
    .line 268
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 269
    .line 270
    .line 271
    move-result v0

    .line 272
    if-nez v0, :cond_9

    .line 273
    .line 274
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->r0:Landroid/widget/Spinner;

    .line 275
    .line 276
    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 277
    .line 278
    .line 279
    move-result v0

    .line 280
    iget-object v2, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->s0:Landroid/widget/Spinner;

    .line 281
    .line 282
    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 283
    .line 284
    .line 285
    move-result v2

    .line 286
    mul-int/lit8 v0, v0, 0xa

    .line 287
    .line 288
    add-int/2addr v0, v2

    .line 289
    int-to-double v5, v0

    .line 290
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->t0:Landroid/widget/Spinner;

    .line 291
    .line 292
    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 293
    .line 294
    .line 295
    move-result v0

    .line 296
    aget-wide v7, v4, v0

    .line 297
    .line 298
    mul-double/2addr v5, v7

    .line 299
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->D0:Landroid/widget/TextView;

    .line 300
    .line 301
    new-instance v2, Ljava/lang/StringBuilder;

    .line 302
    .line 303
    const-string v4, "Inductor: "

    .line 304
    .line 305
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    .line 309
    .line 310
    .line 311
    move-result-wide v7

    .line 312
    const-wide v9, 0x412e848000000000L    # 1000000.0

    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    cmpl-double v4, v7, v9

    .line 318
    .line 319
    if-ltz v4, :cond_7

    .line 320
    .line 321
    new-instance v4, Ljava/lang/StringBuilder;

    .line 322
    .line 323
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 324
    .line 325
    .line 326
    div-double/2addr v5, v9

    .line 327
    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    .line 328
    .line 329
    .line 330
    move-result-object v5

    .line 331
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 332
    .line 333
    .line 334
    const-string v5, " H"

    .line 335
    .line 336
    :goto_5
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 337
    .line 338
    .line 339
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v4

    .line 343
    goto :goto_6

    .line 344
    :cond_7
    const-wide v9, 0x408f400000000000L    # 1000.0

    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    cmpl-double v4, v7, v9

    .line 350
    .line 351
    if-ltz v4, :cond_8

    .line 352
    .line 353
    new-instance v4, Ljava/lang/StringBuilder;

    .line 354
    .line 355
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 356
    .line 357
    .line 358
    div-double/2addr v5, v9

    .line 359
    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v5

    .line 363
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 364
    .line 365
    .line 366
    const-string v5, " mH"

    .line 367
    .line 368
    goto :goto_5

    .line 369
    :cond_8
    new-instance v4, Ljava/lang/StringBuilder;

    .line 370
    .line 371
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 372
    .line 373
    .line 374
    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->E(D)Ljava/lang/String;

    .line 375
    .line 376
    .line 377
    move-result-object v5

    .line 378
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 379
    .line 380
    .line 381
    const-string v5, " uH"

    .line 382
    .line 383
    goto :goto_5

    .line 384
    :goto_6
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 385
    .line 386
    .line 387
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    iget-object v3, p0, Lapp/gkc/terminal/Activity/ResistorToolsActivity;->u0:Landroid/widget/Spinner;

    .line 391
    .line 392
    invoke-virtual {v3}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 393
    .line 394
    .line 395
    move-result v3

    .line 396
    aget-object v1, v1, v3

    .line 397
    .line 398
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v1

    .line 405
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 406
    .line 407
    .line 408
    :cond_9
    :goto_7
    return-void
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
.end method
