.class public Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final synthetic X:I


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/ScrollView;

.field public G:Landroid/widget/Button;

.field public H:Landroid/hardware/usb/UsbManager;

.field public final I:Lg1/n;

.field public final J:Lg1/n;

.field public K:Z

.field public L:Landroid/hardware/usb/UsbDevice;

.field public M:Ljava/lang/String;

.field public N:Ljava/lang/String;

.field public O:Ljava/lang/String;

.field public P:Ljava/lang/String;

.field public Q:[B

.field public R:Ljava/lang/String;

.field public final S:[Ljava/lang/String;

.field public final T:[Ljava/lang/String;

.field public final U:[Ljava/lang/String;

.field public final V:Lb/h;

.field public final W:Le/d0;


# direct methods
.method public constructor <init>()V
    .locals 11

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Lg1/n;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lg1/n;-><init>(I)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->I:Lg1/n;

    new-instance v0, Lg1/n;

    const/4 v2, 0x1

    invoke-direct {v0, v2}, Lg1/n;-><init>(I)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->J:Lg1/n;

    iput-boolean v1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    const-string v0, "25XX_SPI"

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->N:Ljava/lang/String;

    const-string v2, "24C02 (256 B)"

    iput-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->O:Ljava/lang/String;

    const-string v2, "93C46 x16 (128 B)"

    iput-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->P:Ljava/lang/String;

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    const-string v3, "25x40 (512 KB)"

    const-string v4, "25x80 (1 MB)"

    const-string v5, "25x16 (2 MB)"

    const-string v6, "25x32 (4 MB)"

    const-string v7, "25x64 (8 MB)"

    const-string v8, "25x128 (16 MB)"

    filled-new-array/range {v3 .. v8}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->S:[Ljava/lang/String;

    const-string v2, "24C02 (256 B)"

    const-string v3, "24C04 (512 B)"

    const-string v4, "24C08 (1 KB)"

    const-string v5, "24C16 (2 KB)"

    const-string v6, "24C32 (4 KB)"

    const-string v7, "24C64 (8 KB)"

    const-string v8, "24C128 (16 KB)"

    const-string v9, "24C256 (32 KB)"

    const-string v10, "24C512 (64 KB)"

    filled-new-array/range {v2 .. v10}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->T:[Ljava/lang/String;

    const-string v2, "93C46 x8 (128 B)"

    const-string v3, "93C46 x16 (128 B)"

    const-string v4, "93C56 x8 (256 B)"

    const-string v5, "93C56 x16 (256 B)"

    const-string v6, "93C66 x8 (512 B)"

    const-string v7, "93C66 x16 (512 B)"

    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->U:[Ljava/lang/String;

    new-instance v0, Lc/c;

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/x3;

    invoke-direct {v2, p0, v1}, Lg1/x3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->V:Lb/h;

    new-instance v0, Le/d0;

    const/16 v1, 0x9

    invoke-direct {v0, v1, p0}, Le/d0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->W:Le/d0;

    return-void
.end method


# virtual methods
.method public final A(Z)V
    .locals 2

    .line 1
    new-instance v0, Lg1/p1;

    const/4 v1, 0x3

    invoke-direct {v0, p0, p1, v1}, Lg1/p1;-><init>(Landroid/view/KeyEvent$Callback;ZI)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getId()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const v2, 0x7f090150

    .line 8
    .line 9
    .line 10
    const-string v3, " "

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    const/4 v5, 0x1

    .line 14
    if-ne v0, v2, :cond_3

    .line 15
    .line 16
    iget-boolean v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->q()V

    .line 21
    .line 22
    .line 23
    const-string v0, "CH341A disconnected."

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    goto/16 :goto_10

    .line 29
    .line 30
    :cond_0
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->u()Landroid/hardware/usb/UsbDevice;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    const-string v0, "CH341A not found. Connect OTG + CH341A and press CONNECT."

    .line 37
    .line 38
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    const-string v0, "CH341A not found"

    .line 42
    .line 43
    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 48
    .line 49
    .line 50
    goto/16 :goto_10

    .line 51
    .line 52
    :catch_0
    move-exception v0

    .line 53
    goto :goto_0

    .line 54
    :cond_1
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 55
    .line 56
    invoke-virtual {v2, v0}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    if-nez v2, :cond_2

    .line 61
    .line 62
    const-string v2, "Requesting USB permission for CH341A..."

    .line 63
    .line 64
    invoke-virtual {v1, v2}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    new-instance v2, Landroid/content/Intent;

    .line 68
    .line 69
    const-string v6, "app.gkc.terminal.pro.CH341_USB_PERMISSION"

    .line 70
    .line 71
    invoke-direct {v2, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    invoke-virtual {v2, v6}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 79
    .line 80
    .line 81
    const/high16 v6, 0xa000000

    .line 82
    .line 83
    invoke-static {v1, v4, v2, v6}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    iget-object v4, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 88
    .line 89
    invoke-virtual {v4, v0, v2}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 90
    .line 91
    .line 92
    goto/16 :goto_10

    .line 93
    .line 94
    :cond_2
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->v(Landroid/hardware/usb/UsbDevice;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 95
    .line 96
    .line 97
    goto/16 :goto_10

    .line 98
    .line 99
    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 100
    .line 101
    const-string v4, "Connect failed: "

    .line 102
    .line 103
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    const-string v0, "Connect failed. See log."

    .line 135
    .line 136
    invoke-static {v1, v0, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 141
    .line 142
    .line 143
    goto/16 :goto_10

    .line 144
    .line 145
    :cond_3
    const v2, 0x7f0903de

    .line 146
    .line 147
    .line 148
    iget-object v6, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->S:[Ljava/lang/String;

    .line 149
    .line 150
    const/4 v7, 0x3

    .line 151
    const-string v8, "Select SPI Chip"

    .line 152
    .line 153
    if-ne v0, v2, :cond_4

    .line 154
    .line 155
    const-string v0, "25XX_SPI"

    .line 156
    .line 157
    iput-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 158
    .line 159
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 160
    .line 161
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    new-instance v2, Lg1/t3;

    .line 169
    .line 170
    invoke-direct {v2, v1, v7}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 171
    .line 172
    .line 173
    :goto_1
    invoke-virtual {v0, v6, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 178
    .line 179
    .line 180
    goto/16 :goto_10

    .line 181
    .line 182
    :cond_4
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->T:[Ljava/lang/String;

    .line 183
    .line 184
    const-string v9, "Select 24XX I2C EEPROM"

    .line 185
    .line 186
    const v10, 0x7f090249

    .line 187
    .line 188
    .line 189
    const-string v11, "24XX_I2C"

    .line 190
    .line 191
    if-ne v0, v10, :cond_5

    .line 192
    .line 193
    iput-object v11, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 194
    .line 195
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 196
    .line 197
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v0, v9}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    new-instance v3, Lg1/t3;

    .line 205
    .line 206
    invoke-direct {v3, v1, v4}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 207
    .line 208
    .line 209
    :goto_2
    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 214
    .line 215
    .line 216
    goto/16 :goto_10

    .line 217
    .line 218
    :cond_5
    iget-object v10, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->U:[Ljava/lang/String;

    .line 219
    .line 220
    const/4 v12, 0x4

    .line 221
    const-string v13, "Select 93XX Microwire EEPROM"

    .line 222
    .line 223
    const v14, 0x7f0902b0

    .line 224
    .line 225
    .line 226
    const-string v15, "93XX_MICROWIRE"

    .line 227
    .line 228
    if-ne v0, v14, :cond_6

    .line 229
    .line 230
    iput-object v15, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 231
    .line 232
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 233
    .line 234
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v0, v13}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    new-instance v2, Lg1/t3;

    .line 242
    .line 243
    invoke-direct {v2, v1, v12}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 244
    .line 245
    .line 246
    :goto_3
    invoke-virtual {v0, v10, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 251
    .line 252
    .line 253
    goto/16 :goto_10

    .line 254
    .line 255
    :cond_6
    const v14, 0x7f090175

    .line 256
    .line 257
    .line 258
    if-ne v0, v14, :cond_a

    .line 259
    .line 260
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->u()Landroid/hardware/usb/UsbDevice;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    if-nez v0, :cond_7

    .line 265
    .line 266
    const-string v0, "Detect: no CH341A USB device."

    .line 267
    .line 268
    :goto_4
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    goto/16 :goto_10

    .line 272
    .line 273
    :cond_7
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getProductId()I

    .line 274
    .line 275
    .line 276
    move-result v0

    .line 277
    const/16 v2, 0x5512

    .line 278
    .line 279
    if-ne v0, v2, :cond_8

    .line 280
    .line 281
    const-string v0, "CH341A adapter ready."

    .line 282
    .line 283
    goto :goto_5

    .line 284
    :cond_8
    const-string v0, "Compatible USB adapter ready."

    .line 285
    .line 286
    :goto_5
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    iget-boolean v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 290
    .line 291
    if-eqz v0, :cond_9

    .line 292
    .line 293
    const-string v0, "Detect: CH341A open OK."

    .line 294
    .line 295
    goto :goto_4

    .line 296
    :cond_9
    const-string v0, "Detect: CH341A found, press CONNECT to open."

    .line 297
    .line 298
    goto :goto_4

    .line 299
    :cond_a
    const v14, 0x7f090275

    .line 300
    .line 301
    .line 302
    if-ne v0, v14, :cond_d

    .line 303
    .line 304
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 305
    .line 306
    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    if-eqz v0, :cond_b

    .line 311
    .line 312
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 313
    .line 314
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v0, v9}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    new-instance v3, Lg1/t3;

    .line 322
    .line 323
    invoke-direct {v3, v1, v4}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 324
    .line 325
    .line 326
    goto :goto_2

    .line 327
    :cond_b
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 328
    .line 329
    invoke-virtual {v0, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 330
    .line 331
    .line 332
    move-result v0

    .line 333
    if-eqz v0, :cond_c

    .line 334
    .line 335
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 336
    .line 337
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v0, v13}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    new-instance v2, Lg1/t3;

    .line 345
    .line 346
    invoke-direct {v2, v1, v12}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 347
    .line 348
    .line 349
    goto :goto_3

    .line 350
    :cond_c
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 351
    .line 352
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 356
    .line 357
    .line 358
    move-result-object v0

    .line 359
    new-instance v2, Lg1/t3;

    .line 360
    .line 361
    invoke-direct {v2, v1, v7}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 362
    .line 363
    .line 364
    goto/16 :goto_1

    .line 365
    .line 366
    :cond_d
    const v2, 0x7f090344

    .line 367
    .line 368
    .line 369
    const/4 v6, 0x0

    .line 370
    if-ne v0, v2, :cond_e

    .line 371
    .line 372
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 373
    .line 374
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 375
    .line 376
    .line 377
    const-string v2, "CH341 Programmer SOP"

    .line 378
    .line 379
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 380
    .line 381
    .line 382
    move-result-object v0

    .line 383
    const-string v2, "1. Connect CH341A with stable OTG power.\n\n2. Select the correct chip family and chip size.\n\n3. Read the chip first and keep a backup.\n\n4. Load only a trusted file made for the same chip size.\n\n5. Write only after the chip selection is confirmed.\n\n6. Verify after write before fitting the IC back.\n\n93C46/93C56/93C66 are Microwire EEPROMs. They do not use an I2C address. Use CS, CLK, DI, DO wiring and confirm ORG x8/x16 before read/write."

    .line 384
    .line 385
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    const-string v2, "OK"

    .line 390
    .line 391
    invoke-virtual {v0, v2, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 392
    .line 393
    .line 394
    move-result-object v0

    .line 395
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 396
    .line 397
    .line 398
    goto/16 :goto_10

    .line 399
    .line 400
    :cond_e
    const v2, 0x7f090272

    .line 401
    .line 402
    .line 403
    if-ne v0, v2, :cond_f

    .line 404
    .line 405
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->V:Lb/h;

    .line 406
    .line 407
    const-string v2, "*/*"

    .line 408
    .line 409
    invoke-virtual {v0, v2}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 410
    .line 411
    .line 412
    goto/16 :goto_10

    .line 413
    .line 414
    :cond_f
    const v2, 0x7f090388

    .line 415
    .line 416
    .line 417
    const-string v7, ""

    .line 418
    .line 419
    if-ne v0, v2, :cond_18

    .line 420
    .line 421
    const-string v2, "yyyyMMdd_HHmmss"

    .line 422
    .line 423
    const-string v8, "gkc_ch341_read_"

    .line 424
    .line 425
    const-string v0, "Saved BIN: Download/GKC_CH341A/"

    .line 426
    .line 427
    const-string v9, ".bin"

    .line 428
    .line 429
    :try_start_1
    iget-object v10, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 430
    .line 431
    if-nez v10, :cond_10

    .line 432
    .line 433
    const-string v0, "Save failed: no read/load buffer."

    .line 434
    .line 435
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    const-string v0, "Read or load file first"

    .line 439
    .line 440
    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    :goto_6
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 445
    .line 446
    .line 447
    goto/16 :goto_10

    .line 448
    .line 449
    :catch_1
    move-exception v0

    .line 450
    goto/16 :goto_a

    .line 451
    .line 452
    :cond_10
    new-instance v11, Ljava/text/SimpleDateFormat;

    .line 453
    .line 454
    sget-object v12, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 455
    .line 456
    invoke-direct {v11, v2, v12}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 457
    .line 458
    .line 459
    new-instance v13, Ljava/util/Date;

    .line 460
    .line 461
    invoke-direct {v13}, Ljava/util/Date;-><init>()V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v11, v13}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 465
    .line 466
    .line 467
    move-result-object v11

    .line 468
    iget-object v13, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    .line 469
    .line 470
    if-eqz v13, :cond_12

    .line 471
    .line 472
    invoke-virtual {v13}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 473
    .line 474
    .line 475
    move-result-object v13

    .line 476
    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    .line 477
    .line 478
    .line 479
    move-result v13

    .line 480
    if-eqz v13, :cond_11

    .line 481
    .line 482
    goto :goto_7

    .line 483
    :cond_11
    iget-object v13, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    .line 484
    .line 485
    goto :goto_8

    .line 486
    :cond_12
    :goto_7
    const-string v13, "gkc_ch341_read.bin"

    .line 487
    .line 488
    :goto_8
    invoke-virtual {v13, v12}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object v12

    .line 492
    invoke-virtual {v12, v9}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 493
    .line 494
    .line 495
    move-result v12

    .line 496
    if-nez v12, :cond_13

    .line 497
    .line 498
    invoke-virtual {v13, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 499
    .line 500
    .line 501
    move-result-object v13

    .line 502
    :cond_13
    new-instance v12, Ljava/lang/StringBuilder;

    .line 503
    .line 504
    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 505
    .line 506
    .line 507
    invoke-virtual {v13, v9, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v7

    .line 511
    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 512
    .line 513
    .line 514
    const-string v7, "_saved_"

    .line 515
    .line 516
    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 517
    .line 518
    .line 519
    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 520
    .line 521
    .line 522
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 523
    .line 524
    .line 525
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 526
    .line 527
    .line 528
    move-result-object v7

    .line 529
    new-instance v11, Landroid/content/ContentValues;

    .line 530
    .line 531
    invoke-direct {v11}, Landroid/content/ContentValues;-><init>()V

    .line 532
    .line 533
    .line 534
    const-string v12, "_display_name"

    .line 535
    .line 536
    invoke-virtual {v11, v12, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    const-string v12, "mime_type"

    .line 540
    .line 541
    const-string v13, "application/octet-stream"

    .line 542
    .line 543
    invoke-virtual {v11, v12, v13}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 547
    .line 548
    const-string v13, "is_pending"

    .line 549
    .line 550
    const/16 v14, 0x1d

    .line 551
    .line 552
    if-lt v12, v14, :cond_14

    .line 553
    .line 554
    :try_start_2
    const-string v15, "relative_path"

    .line 555
    .line 556
    const-string v6, "Download/GKC_CH341A"

    .line 557
    .line 558
    invoke-virtual {v11, v15, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 559
    .line 560
    .line 561
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 562
    .line 563
    .line 564
    move-result-object v5

    .line 565
    invoke-virtual {v11, v13, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 566
    .line 567
    .line 568
    :cond_14
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 569
    .line 570
    .line 571
    move-result-object v5

    .line 572
    invoke-static {}, La0/b;->f()Landroid/net/Uri;

    .line 573
    .line 574
    .line 575
    move-result-object v6

    .line 576
    invoke-virtual {v5, v6, v11}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    .line 577
    .line 578
    .line 579
    move-result-object v5

    .line 580
    if-nez v5, :cond_15

    .line 581
    .line 582
    :goto_9
    invoke-virtual {v1, v7, v10}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->z(Ljava/lang/String;[B)V

    .line 583
    .line 584
    .line 585
    goto/16 :goto_10

    .line 586
    .line 587
    :cond_15
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 588
    .line 589
    .line 590
    move-result-object v6

    .line 591
    invoke-virtual {v6, v5}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    .line 592
    .line 593
    .line 594
    move-result-object v6

    .line 595
    if-nez v6, :cond_16

    .line 596
    .line 597
    goto :goto_9

    .line 598
    :cond_16
    invoke-virtual {v6, v10}, Ljava/io/OutputStream;->write([B)V

    .line 599
    .line 600
    .line 601
    invoke-virtual {v6}, Ljava/io/OutputStream;->close()V

    .line 602
    .line 603
    .line 604
    if-lt v12, v14, :cond_17

    .line 605
    .line 606
    new-instance v6, Landroid/content/ContentValues;

    .line 607
    .line 608
    invoke-direct {v6}, Landroid/content/ContentValues;-><init>()V

    .line 609
    .line 610
    .line 611
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 612
    .line 613
    .line 614
    move-result-object v10

    .line 615
    invoke-virtual {v6, v13, v10}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 616
    .line 617
    .line 618
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 619
    .line 620
    .line 621
    move-result-object v10

    .line 622
    const/4 v11, 0x0

    .line 623
    invoke-virtual {v10, v5, v6, v11, v11}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 624
    .line 625
    .line 626
    :cond_17
    new-instance v5, Ljava/lang/StringBuilder;

    .line 627
    .line 628
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 629
    .line 630
    .line 631
    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 632
    .line 633
    .line 634
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object v0

    .line 638
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 639
    .line 640
    .line 641
    const-string v0, "BIN saved to Downloads"

    .line 642
    .line 643
    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 644
    .line 645
    .line 646
    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 647
    goto/16 :goto_6

    .line 648
    .line 649
    :goto_a
    :try_start_3
    new-instance v4, Ljava/lang/StringBuilder;

    .line 650
    .line 651
    invoke-direct {v4, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 652
    .line 653
    .line 654
    new-instance v5, Ljava/text/SimpleDateFormat;

    .line 655
    .line 656
    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 657
    .line 658
    invoke-direct {v5, v2, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 659
    .line 660
    .line 661
    new-instance v2, Ljava/util/Date;

    .line 662
    .line 663
    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    .line 664
    .line 665
    .line 666
    invoke-virtual {v5, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 667
    .line 668
    .line 669
    move-result-object v2

    .line 670
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 671
    .line 672
    .line 673
    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 674
    .line 675
    .line 676
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 677
    .line 678
    .line 679
    move-result-object v2

    .line 680
    iget-object v4, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 681
    .line 682
    invoke-virtual {v1, v2, v4}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->z(Ljava/lang/String;[B)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 683
    .line 684
    .line 685
    goto/16 :goto_10

    .line 686
    .line 687
    :catch_2
    new-instance v2, Ljava/lang/StringBuilder;

    .line 688
    .line 689
    const-string v4, "Save failed: "

    .line 690
    .line 691
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 692
    .line 693
    .line 694
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 695
    .line 696
    .line 697
    move-result-object v4

    .line 698
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 699
    .line 700
    .line 701
    move-result-object v4

    .line 702
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 703
    .line 704
    .line 705
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 706
    .line 707
    .line 708
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 709
    .line 710
    .line 711
    move-result-object v0

    .line 712
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 713
    .line 714
    .line 715
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 716
    .line 717
    .line 718
    move-result-object v0

    .line 719
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 720
    .line 721
    .line 722
    goto/16 :goto_10

    .line 723
    .line 724
    :cond_18
    const v2, 0x7f09016d

    .line 725
    .line 726
    .line 727
    if-ne v0, v2, :cond_19

    .line 728
    .line 729
    const/4 v2, 0x0

    .line 730
    iput-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 731
    .line 732
    iput-object v7, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    .line 733
    .line 734
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->C:Landroid/widget/TextView;

    .line 735
    .line 736
    const-string v2, "No file selected"

    .line 737
    .line 738
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 739
    .line 740
    .line 741
    const-string v0, "Selected file cleared."

    .line 742
    .line 743
    :goto_b
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 744
    .line 745
    .line 746
    goto/16 :goto_10

    .line 747
    .line 748
    :cond_19
    const v2, 0x7f0902f0

    .line 749
    .line 750
    .line 751
    if-ne v0, v2, :cond_1e

    .line 752
    .line 753
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 754
    .line 755
    if-eqz v0, :cond_1d

    .line 756
    .line 757
    array-length v2, v0

    .line 758
    if-nez v2, :cond_1a

    .line 759
    .line 760
    goto :goto_e

    .line 761
    :cond_1a
    sput-object v0, Lg1/b3;->f:[B

    .line 762
    .line 763
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    .line 764
    .line 765
    if-eqz v0, :cond_1c

    .line 766
    .line 767
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 768
    .line 769
    .line 770
    move-result v0

    .line 771
    if-eqz v0, :cond_1b

    .line 772
    .line 773
    goto :goto_c

    .line 774
    :cond_1b
    new-instance v0, Ljava/lang/StringBuilder;

    .line 775
    .line 776
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 777
    .line 778
    .line 779
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->R:Ljava/lang/String;

    .line 780
    .line 781
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 782
    .line 783
    .line 784
    const-string v2, " ("

    .line 785
    .line 786
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 787
    .line 788
    .line 789
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 790
    .line 791
    array-length v2, v2

    .line 792
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 793
    .line 794
    .line 795
    const-string v2, " bytes)"

    .line 796
    .line 797
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 798
    .line 799
    .line 800
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 801
    .line 802
    .line 803
    move-result-object v0

    .line 804
    goto :goto_d

    .line 805
    :cond_1c
    :goto_c
    const-string v0, "Read Buffer"

    .line 806
    .line 807
    :goto_d
    sput-object v0, Lg1/b3;->g:Ljava/lang/String;

    .line 808
    .line 809
    new-instance v0, Landroid/content/Intent;

    .line 810
    .line 811
    const-class v2, Lapp/gkc/terminal/Activity/HexBufferActivity;

    .line 812
    .line 813
    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 814
    .line 815
    .line 816
    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 817
    .line 818
    .line 819
    goto/16 :goto_10

    .line 820
    .line 821
    :cond_1d
    :goto_e
    const-string v0, "Open buffer failed: read or load BIN first."

    .line 822
    .line 823
    const-string v2, "Read or load BIN first"

    .line 824
    .line 825
    invoke-static {v1, v0, v1, v2, v4}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 826
    .line 827
    .line 828
    goto/16 :goto_10

    .line 829
    .line 830
    :cond_1e
    const v2, 0x7f09034d

    .line 831
    .line 832
    .line 833
    const-string v3, "..."

    .line 834
    .line 835
    if-ne v0, v2, :cond_23

    .line 836
    .line 837
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 838
    .line 839
    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 840
    .line 841
    .line 842
    move-result v0

    .line 843
    const-string v2, "Reading "

    .line 844
    .line 845
    if-eqz v0, :cond_20

    .line 846
    .line 847
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->r()Z

    .line 848
    .line 849
    .line 850
    move-result v0

    .line 851
    if-nez v0, :cond_1f

    .line 852
    .line 853
    goto/16 :goto_10

    .line 854
    .line 855
    :cond_1f
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->O:Ljava/lang/String;

    .line 856
    .line 857
    invoke-static {v0}, Lg1/n;->a(Ljava/lang/String;)I

    .line 858
    .line 859
    .line 860
    move-result v0

    .line 861
    new-instance v6, Ljava/lang/StringBuilder;

    .line 862
    .line 863
    invoke-direct {v6, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 864
    .line 865
    .line 866
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->O:Ljava/lang/String;

    .line 867
    .line 868
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 869
    .line 870
    .line 871
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 872
    .line 873
    .line 874
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 875
    .line 876
    .line 877
    move-result-object v2

    .line 878
    invoke-virtual {v1, v2}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 879
    .line 880
    .line 881
    invoke-virtual {v1, v5}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 882
    .line 883
    .line 884
    new-instance v2, Ljava/lang/Thread;

    .line 885
    .line 886
    new-instance v3, Lg1/s3;

    .line 887
    .line 888
    invoke-direct {v3, v1, v0, v4}, Lg1/s3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;II)V

    .line 889
    .line 890
    .line 891
    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 892
    .line 893
    .line 894
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 895
    .line 896
    .line 897
    goto/16 :goto_10

    .line 898
    .line 899
    :cond_20
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 900
    .line 901
    invoke-virtual {v0, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 902
    .line 903
    .line 904
    move-result v0

    .line 905
    if-eqz v0, :cond_22

    .line 906
    .line 907
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->s()Z

    .line 908
    .line 909
    .line 910
    move-result v0

    .line 911
    if-nez v0, :cond_21

    .line 912
    .line 913
    goto/16 :goto_10

    .line 914
    .line 915
    :cond_21
    new-instance v0, Ljava/lang/StringBuilder;

    .line 916
    .line 917
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 918
    .line 919
    .line 920
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->P:Ljava/lang/String;

    .line 921
    .line 922
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 923
    .line 924
    .line 925
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 926
    .line 927
    .line 928
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 929
    .line 930
    .line 931
    move-result-object v0

    .line 932
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 933
    .line 934
    .line 935
    const-string v0, "Check adaptor wiring: CS, CLK/SK, DI, DO, VCC, GND. ORG jumper must match selected x8/x16."

    .line 936
    .line 937
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 938
    .line 939
    .line 940
    invoke-virtual {v1, v5}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 941
    .line 942
    .line 943
    new-instance v0, Ljava/lang/Thread;

    .line 944
    .line 945
    new-instance v2, Lg1/u3;

    .line 946
    .line 947
    invoke-direct {v2, v1, v5}, Lg1/u3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 948
    .line 949
    .line 950
    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 951
    .line 952
    .line 953
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 954
    .line 955
    .line 956
    goto/16 :goto_10

    .line 957
    .line 958
    :cond_22
    new-instance v0, Ljava/lang/StringBuilder;

    .line 959
    .line 960
    const-string v2, "read "

    .line 961
    .line 962
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 963
    .line 964
    .line 965
    :goto_f
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 966
    .line 967
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 968
    .line 969
    .line 970
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 971
    .line 972
    .line 973
    move-result-object v0

    .line 974
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->y(Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    goto/16 :goto_10

    .line 978
    .line 979
    :cond_23
    const v2, 0x7f090464

    .line 980
    .line 981
    .line 982
    const/4 v6, 0x2

    .line 983
    const-string v8, " bytes."

    .line 984
    .line 985
    const-string v9, "File size mismatch. 93XX selected chip needs "

    .line 986
    .line 987
    const-string v10, "File size mismatch"

    .line 988
    .line 989
    if-ne v0, v2, :cond_2c

    .line 990
    .line 991
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 992
    .line 993
    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 994
    .line 995
    .line 996
    move-result v0

    .line 997
    const-string v2, "CANCEL"

    .line 998
    .line 999
    const-string v3, "WRITE"

    .line 1000
    .line 1001
    const-string v7, "Load file first"

    .line 1002
    .line 1003
    const-string v11, "Load file first before WRITE."

    .line 1004
    .line 1005
    if-eqz v0, :cond_27

    .line 1006
    .line 1007
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1008
    .line 1009
    if-nez v0, :cond_24

    .line 1010
    .line 1011
    invoke-static {v1, v11, v1, v7, v4}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1012
    .line 1013
    .line 1014
    goto/16 :goto_10

    .line 1015
    .line 1016
    :cond_24
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->r()Z

    .line 1017
    .line 1018
    .line 1019
    move-result v0

    .line 1020
    if-nez v0, :cond_25

    .line 1021
    .line 1022
    goto/16 :goto_10

    .line 1023
    .line 1024
    :cond_25
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->O:Ljava/lang/String;

    .line 1025
    .line 1026
    invoke-static {v0}, Lg1/n;->a(Ljava/lang/String;)I

    .line 1027
    .line 1028
    .line 1029
    move-result v0

    .line 1030
    iget-object v4, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1031
    .line 1032
    array-length v4, v4

    .line 1033
    if-eq v4, v0, :cond_26

    .line 1034
    .line 1035
    const-string v0, "File size mismatch. Select the correct chip or load the matching file."

    .line 1036
    .line 1037
    invoke-static {v1, v0, v1, v10, v5}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1038
    .line 1039
    .line 1040
    goto/16 :goto_10

    .line 1041
    .line 1042
    :cond_26
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 1043
    .line 1044
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1045
    .line 1046
    .line 1047
    const-string v4, "Write 24XX EEPROM?"

    .line 1048
    .line 1049
    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v0

    .line 1053
    const-string v4, "This writes the loaded file to the selected EEPROM, then verifies."

    .line 1054
    .line 1055
    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1056
    .line 1057
    .line 1058
    move-result-object v0

    .line 1059
    new-instance v4, Lg1/t3;

    .line 1060
    .line 1061
    invoke-direct {v4, v1, v5}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 1062
    .line 1063
    .line 1064
    invoke-virtual {v0, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1065
    .line 1066
    .line 1067
    move-result-object v0

    .line 1068
    const/4 v3, 0x0

    .line 1069
    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1070
    .line 1071
    .line 1072
    move-result-object v0

    .line 1073
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 1074
    .line 1075
    .line 1076
    goto/16 :goto_10

    .line 1077
    .line 1078
    :cond_27
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 1079
    .line 1080
    invoke-virtual {v0, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1081
    .line 1082
    .line 1083
    move-result v0

    .line 1084
    if-eqz v0, :cond_2b

    .line 1085
    .line 1086
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1087
    .line 1088
    if-nez v0, :cond_28

    .line 1089
    .line 1090
    invoke-static {v1, v11, v1, v7, v4}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1091
    .line 1092
    .line 1093
    goto/16 :goto_10

    .line 1094
    .line 1095
    :cond_28
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->s()Z

    .line 1096
    .line 1097
    .line 1098
    move-result v0

    .line 1099
    if-nez v0, :cond_29

    .line 1100
    .line 1101
    goto/16 :goto_10

    .line 1102
    .line 1103
    :cond_29
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->P:Ljava/lang/String;

    .line 1104
    .line 1105
    invoke-static {v0}, Lg1/n;->k(Ljava/lang/String;)Lg1/o;

    .line 1106
    .line 1107
    .line 1108
    move-result-object v0

    .line 1109
    iget-object v4, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1110
    .line 1111
    array-length v4, v4

    .line 1112
    iget v0, v0, Lg1/o;->a:I

    .line 1113
    .line 1114
    if-eq v4, v0, :cond_2a

    .line 1115
    .line 1116
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1117
    .line 1118
    invoke-direct {v2, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1119
    .line 1120
    .line 1121
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1122
    .line 1123
    .line 1124
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1125
    .line 1126
    .line 1127
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1128
    .line 1129
    .line 1130
    move-result-object v0

    .line 1131
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 1132
    .line 1133
    .line 1134
    invoke-static {v1, v10, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v0

    .line 1138
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 1139
    .line 1140
    .line 1141
    goto/16 :goto_10

    .line 1142
    .line 1143
    :cond_2a
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 1144
    .line 1145
    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1146
    .line 1147
    .line 1148
    const-string v4, "Write 93XX Microwire?"

    .line 1149
    .line 1150
    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v0

    .line 1154
    const-string v4, "This writes the loaded BIN to the selected 93C EEPROM, then reads back to the HEX buffer. ORG jumper must match x8/x16."

    .line 1155
    .line 1156
    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v0

    .line 1160
    new-instance v4, Lg1/t3;

    .line 1161
    .line 1162
    invoke-direct {v4, v1, v6}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 1163
    .line 1164
    .line 1165
    invoke-virtual {v0, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v0

    .line 1169
    const/4 v3, 0x0

    .line 1170
    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1171
    .line 1172
    .line 1173
    move-result-object v0

    .line 1174
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 1175
    .line 1176
    .line 1177
    goto/16 :goto_10

    .line 1178
    .line 1179
    :cond_2b
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1180
    .line 1181
    const-string v2, "write "

    .line 1182
    .line 1183
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1184
    .line 1185
    .line 1186
    goto/16 :goto_f

    .line 1187
    .line 1188
    :cond_2c
    const v2, 0x7f0901cd

    .line 1189
    .line 1190
    .line 1191
    if-ne v0, v2, :cond_2f

    .line 1192
    .line 1193
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 1194
    .line 1195
    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1196
    .line 1197
    .line 1198
    move-result v0

    .line 1199
    if-eqz v0, :cond_2d

    .line 1200
    .line 1201
    const-string v0, "24Cxx EEPROM has no chip erase command. Load FF file and WRITE if needed."

    .line 1202
    .line 1203
    goto/16 :goto_b

    .line 1204
    .line 1205
    :cond_2d
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 1206
    .line 1207
    invoke-virtual {v0, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1208
    .line 1209
    .line 1210
    move-result v0

    .line 1211
    if-eqz v0, :cond_2e

    .line 1212
    .line 1213
    const-string v0, "93XX erase is not enabled. Load an FF BIN and WRITE if you need blank data."

    .line 1214
    .line 1215
    const-string v2, "Use FF BIN + WRITE"

    .line 1216
    .line 1217
    invoke-static {v1, v0, v1, v2, v5}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1218
    .line 1219
    .line 1220
    goto/16 :goto_10

    .line 1221
    .line 1222
    :cond_2e
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1223
    .line 1224
    const-string v2, "erase "

    .line 1225
    .line 1226
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1227
    .line 1228
    .line 1229
    goto/16 :goto_f

    .line 1230
    .line 1231
    :cond_2f
    const v2, 0x7f09043b

    .line 1232
    .line 1233
    .line 1234
    if-ne v0, v2, :cond_37

    .line 1235
    .line 1236
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 1237
    .line 1238
    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1239
    .line 1240
    .line 1241
    move-result v0

    .line 1242
    const-string v2, "Verifying "

    .line 1243
    .line 1244
    const-string v7, "Load/read file first"

    .line 1245
    .line 1246
    const-string v11, "Load/read file first before VERIFY."

    .line 1247
    .line 1248
    if-eqz v0, :cond_32

    .line 1249
    .line 1250
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1251
    .line 1252
    if-nez v0, :cond_30

    .line 1253
    .line 1254
    invoke-static {v1, v11, v1, v7, v4}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1255
    .line 1256
    .line 1257
    goto/16 :goto_10

    .line 1258
    .line 1259
    :cond_30
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->r()Z

    .line 1260
    .line 1261
    .line 1262
    move-result v0

    .line 1263
    if-nez v0, :cond_31

    .line 1264
    .line 1265
    goto/16 :goto_10

    .line 1266
    .line 1267
    :cond_31
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1268
    .line 1269
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1270
    .line 1271
    .line 1272
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->O:Ljava/lang/String;

    .line 1273
    .line 1274
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1275
    .line 1276
    .line 1277
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1278
    .line 1279
    .line 1280
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1281
    .line 1282
    .line 1283
    move-result-object v0

    .line 1284
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 1285
    .line 1286
    .line 1287
    invoke-virtual {v1, v5}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 1288
    .line 1289
    .line 1290
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1291
    .line 1292
    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    .line 1293
    .line 1294
    .line 1295
    move-result-object v0

    .line 1296
    check-cast v0, [B

    .line 1297
    .line 1298
    new-instance v2, Ljava/lang/Thread;

    .line 1299
    .line 1300
    new-instance v3, Lg1/w3;

    .line 1301
    .line 1302
    invoke-direct {v3, v1, v0, v6}, Lg1/w3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;[BI)V

    .line 1303
    .line 1304
    .line 1305
    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 1306
    .line 1307
    .line 1308
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 1309
    .line 1310
    .line 1311
    goto/16 :goto_10

    .line 1312
    .line 1313
    :cond_32
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 1314
    .line 1315
    invoke-virtual {v0, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1316
    .line 1317
    .line 1318
    move-result v0

    .line 1319
    if-eqz v0, :cond_36

    .line 1320
    .line 1321
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1322
    .line 1323
    if-nez v0, :cond_33

    .line 1324
    .line 1325
    invoke-static {v1, v11, v1, v7, v4}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 1326
    .line 1327
    .line 1328
    goto/16 :goto_10

    .line 1329
    .line 1330
    :cond_33
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->s()Z

    .line 1331
    .line 1332
    .line 1333
    move-result v0

    .line 1334
    if-nez v0, :cond_34

    .line 1335
    .line 1336
    goto :goto_10

    .line 1337
    :cond_34
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->P:Ljava/lang/String;

    .line 1338
    .line 1339
    invoke-static {v0}, Lg1/n;->k(Ljava/lang/String;)Lg1/o;

    .line 1340
    .line 1341
    .line 1342
    move-result-object v0

    .line 1343
    iget-object v4, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1344
    .line 1345
    array-length v4, v4

    .line 1346
    iget v0, v0, Lg1/o;->a:I

    .line 1347
    .line 1348
    if-eq v4, v0, :cond_35

    .line 1349
    .line 1350
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1351
    .line 1352
    invoke-direct {v2, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1353
    .line 1354
    .line 1355
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1356
    .line 1357
    .line 1358
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1359
    .line 1360
    .line 1361
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1362
    .line 1363
    .line 1364
    move-result-object v0

    .line 1365
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 1366
    .line 1367
    .line 1368
    invoke-static {v1, v10, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 1369
    .line 1370
    .line 1371
    move-result-object v0

    .line 1372
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 1373
    .line 1374
    .line 1375
    goto :goto_10

    .line 1376
    :cond_35
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1377
    .line 1378
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1379
    .line 1380
    .line 1381
    iget-object v2, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->P:Ljava/lang/String;

    .line 1382
    .line 1383
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1384
    .line 1385
    .line 1386
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1387
    .line 1388
    .line 1389
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1390
    .line 1391
    .line 1392
    move-result-object v0

    .line 1393
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 1394
    .line 1395
    .line 1396
    invoke-virtual {v1, v5}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 1397
    .line 1398
    .line 1399
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 1400
    .line 1401
    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    .line 1402
    .line 1403
    .line 1404
    move-result-object v0

    .line 1405
    check-cast v0, [B

    .line 1406
    .line 1407
    new-instance v2, Ljava/lang/Thread;

    .line 1408
    .line 1409
    new-instance v3, Lg1/w3;

    .line 1410
    .line 1411
    invoke-direct {v3, v1, v0, v5}, Lg1/w3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;[BI)V

    .line 1412
    .line 1413
    .line 1414
    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 1415
    .line 1416
    .line 1417
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 1418
    .line 1419
    .line 1420
    goto :goto_10

    .line 1421
    :cond_36
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1422
    .line 1423
    const-string v2, "verify "

    .line 1424
    .line 1425
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1426
    .line 1427
    .line 1428
    goto/16 :goto_f

    .line 1429
    .line 1430
    :cond_37
    const v2, 0x7f090142

    .line 1431
    .line 1432
    .line 1433
    if-ne v0, v2, :cond_38

    .line 1434
    .line 1435
    iget-object v0, v1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->D:Landroid/widget/TextView;

    .line 1436
    .line 1437
    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1438
    .line 1439
    .line 1440
    const-string v0, "Log cleared."

    .line 1441
    .line 1442
    goto/16 :goto_b

    .line 1443
    .line 1444
    :cond_38
    :goto_10
    return-void
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0037

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const-string p1, "usb"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/usb/UsbManager;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    const p1, 0x7f090151

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->B:Landroid/widget/TextView;

    const p1, 0x7f0901d7

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f090343

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->D:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->D:Landroid/widget/TextView;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    const p1, 0x7f090345

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f0903dd

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->F:Landroid/widget/ScrollView;

    const p1, 0x7f090150

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->G:Landroid/widget/Button;

    const/16 p1, 0x10

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    aget v2, v0, v1

    invoke-virtual {p0, v2}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/content/IntentFilter;

    const-string v0, "app.gkc.terminal.pro.CH341_USB_PERMISSION"

    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->W:Le/d0;

    invoke-static {p0, v0, p1}, Le2/m;->e1(Landroid/content/Context;Le/d0;Landroid/content/IntentFilter;)V

    const-string p1, "System ready."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    const-string p1, "Supported now: 25XX SPI, 24XX I2C, 93XX Microwire, file load/save."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f090150
        0x7f0903de
        0x7f090175
        0x7f090249
        0x7f0902b0
        0x7f090275
        0x7f090344
        0x7f090272
        0x7f090388
        0x7f09016d
        0x7f0902f0
        0x7f09034d
        0x7f090464
        0x7f0901cd
        0x7f09043b
        0x7f090142
    .end array-data
.end method

.method public final onDestroy()V
    .locals 1

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->q()V

    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->W:Le/d0;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->D:Landroid/widget/TextView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string p1, "\n"

    .line 14
    .line 15
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->D:Landroid/widget/TextView;

    .line 26
    .line 27
    new-instance v0, Lg1/u3;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-direct {v0, p0, v1}, Lg1/u3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 34
    .line 35
    .line 36
    :cond_0
    return-void
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final q()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->J:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->I:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    const/4 v0, 0x0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->B:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    const-string v1, "CH341A: Disconnected"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->G:Landroid/widget/Button;

    if-eqz v0, :cond_1

    const-string v1, "CONNECT"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    return-void
.end method

.method public final r()Z
    .locals 5

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->I:Lg1/n;

    .line 12
    .line 13
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x1

    .line 18
    if-eqz v2, :cond_1

    .line 19
    .line 20
    return v3

    .line 21
    :cond_1
    :try_start_0
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->J:Lg1/n;

    .line 22
    .line 23
    invoke-virtual {v2}, Lg1/n;->c()V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 27
    .line 28
    iget-object v4, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v4}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    .line 31
    .line 32
    .line 33
    const-string v0, "CH341A I2C mode ready."

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .line 37
    .line 38
    return v3

    .line 39
    :catch_0
    move-exception v0

    .line 40
    new-instance v2, Ljava/lang/StringBuilder;

    .line 41
    .line 42
    const-string v4, "I2C open failed: "

    .line 43
    .line 44
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const-string v4, " "

    .line 59
    .line 60
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const-string v0, "I2C open failed"

    .line 78
    .line 79
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 84
    .line 85
    .line 86
    return v1

    .line 87
    :cond_2
    :goto_0
    const-string v0, "Connect CH341A first."

    .line 88
    .line 89
    const-string v2, "Connect first"

    .line 90
    .line 91
    invoke-static {p0, v0, p0, v2, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 92
    .line 93
    .line 94
    return v1
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final s()Z
    .locals 5

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->J:Lg1/n;

    .line 12
    .line 13
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x1

    .line 18
    if-eqz v2, :cond_1

    .line 19
    .line 20
    return v3

    .line 21
    :cond_1
    :try_start_0
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->I:Lg1/n;

    .line 22
    .line 23
    invoke-virtual {v2}, Lg1/n;->c()V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 27
    .line 28
    iget-object v4, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v4}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    .line 31
    .line 32
    .line 33
    const-string v0, "CH341A Microwire mode ready."

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .line 37
    .line 38
    return v3

    .line 39
    :catch_0
    move-exception v0

    .line 40
    new-instance v2, Ljava/lang/StringBuilder;

    .line 41
    .line 42
    const-string v4, "Microwire open failed: "

    .line 43
    .line 44
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const-string v4, " "

    .line 59
    .line 60
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const-string v0, "Microwire open failed"

    .line 78
    .line 79
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 84
    .line 85
    .line 86
    return v1

    .line 87
    :cond_2
    :goto_0
    const-string v0, "Connect CH341A first."

    .line 88
    .line 89
    const-string v2, "Connect first"

    .line 90
    .line 91
    invoke-static {p0, v0, p0, v2, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 92
    .line 93
    .line 94
    return v1
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final t()Z
    .locals 5

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->J:Lg1/n;

    .line 12
    .line 13
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x1

    .line 18
    if-eqz v2, :cond_1

    .line 19
    .line 20
    return v3

    .line 21
    :cond_1
    :try_start_0
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->I:Lg1/n;

    .line 22
    .line 23
    invoke-virtual {v2}, Lg1/n;->c()V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 27
    .line 28
    iget-object v4, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v4}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, Lg1/n;->t()[B

    .line 34
    .line 35
    .line 36
    const-string v0, "CH341A SPI mode ready."

    .line 37
    .line 38
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 39
    .line 40
    .line 41
    return v3

    .line 42
    :catch_0
    move-exception v0

    .line 43
    new-instance v2, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string v4, "SPI open failed: "

    .line 46
    .line 47
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v4, " "

    .line 62
    .line 63
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    const-string v0, "SPI open failed"

    .line 81
    .line 82
    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 87
    .line 88
    .line 89
    return v1

    .line 90
    :cond_2
    :goto_0
    const-string v0, "Connect CH341A first."

    .line 91
    .line 92
    const-string v2, "Connect first"

    .line 93
    .line 94
    invoke-static {p0, v0, p0, v2, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 95
    .line 96
    .line 97
    return v1
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final u()Landroid/hardware/usb/UsbDevice;
    .locals 4

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->H:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v0}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/hardware/usb/UsbDevice;

    invoke-virtual {v1}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    move-result v2

    const/16 v3, 0x1a86

    if-ne v2, v3, :cond_0

    const-string v0, "CH341A adapter detected."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    return-object v1

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final v(Landroid/hardware/usb/UsbDevice;)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->q()V

    .line 3
    .line 4
    .line 5
    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 6
    .line 7
    iput-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->L:Landroid/hardware/usb/UsbDevice;

    .line 8
    .line 9
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->B:Landroid/widget/TextView;

    .line 10
    .line 11
    const-string v2, "CH341A: Connected"

    .line 12
    .line 13
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->G:Landroid/widget/Button;

    .line 17
    .line 18
    const-string v2, "DISCONNECT"

    .line 19
    .line 20
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->getProductId()I

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    const/16 v1, 0x5512

    .line 28
    .line 29
    if-ne p1, v1, :cond_0

    .line 30
    .line 31
    const-string p1, "CH341A adapter ready."

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const-string p1, "Compatible USB adapter ready."

    .line 35
    .line 36
    :goto_0
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const-string p1, "CH341A USB open OK."

    .line 40
    .line 41
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    const-string p1, "Programmer ready. Select SPI or I2C mode, then read/write/verify."

    .line 45
    .line 46
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    .line 48
    .line 49
    goto :goto_1

    .line 50
    :catch_0
    move-exception p1

    .line 51
    new-instance v1, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    const-string v2, "Open failed: "

    .line 54
    .line 55
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    const-string v2, " "

    .line 70
    .line 71
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->q()V

    .line 89
    .line 90
    .line 91
    const-string p1, "Open failed. See log."

    .line 92
    .line 93
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 98
    .line 99
    .line 100
    :goto_1
    return-void
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final w(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 2

    .line 1
    new-instance v0, Landroidx/emoji2/text/n;

    const/16 v1, 0x13

    invoke-direct {v0, p0, p1, p2, v1}, Landroidx/emoji2/text/n;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final x(ILjava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Landroidx/activity/m;

    const/4 v1, 0x7

    invoke-direct {v0, p1, v1, p0, p2}, Landroidx/activity/m;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final y(Ljava/lang/String;)V
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Selected action: "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->E:Landroid/widget/TextView;

    .line 19
    .line 20
    const-string v1, "0%"

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->M:Ljava/lang/String;

    .line 26
    .line 27
    const-string v1, "25XX_SPI"

    .line 28
    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    const/4 v1, 0x0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->N:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    const-string p1, "Select SPI chip first."

    .line 45
    .line 46
    const-string v0, "Select SPI chip first"

    .line 47
    .line 48
    :goto_0
    invoke-static {p0, p1, p0, v0, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    :cond_0
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->K:Z

    .line 53
    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    const-string p1, "Not sent: connect CH341A first."

    .line 57
    .line 58
    const-string v0, "Connect first"

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_1
    const-string v0, "read"

    .line 62
    .line 63
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    const/4 v2, 0x1

    .line 68
    if-eqz v0, :cond_3

    .line 69
    .line 70
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->t()Z

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-nez p1, :cond_2

    .line 75
    .line 76
    goto/16 :goto_1

    .line 77
    .line 78
    :cond_2
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->N:Ljava/lang/String;

    .line 79
    .line 80
    invoke-static {p1}, Lg1/n;->b(Ljava/lang/String;)I

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    new-instance v0, Ljava/lang/StringBuilder;

    .line 85
    .line 86
    const-string v1, "Reading "

    .line 87
    .line 88
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->N:Ljava/lang/String;

    .line 92
    .line 93
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    const-string v1, "..."

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 109
    .line 110
    .line 111
    new-instance v0, Ljava/lang/Thread;

    .line 112
    .line 113
    new-instance v1, Lg1/s3;

    .line 114
    .line 115
    invoke-direct {v1, p0, p1, v2}, Lg1/s3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;II)V

    .line 116
    .line 117
    .line 118
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 122
    .line 123
    .line 124
    goto/16 :goto_1

    .line 125
    .line 126
    :cond_3
    const-string v0, "write"

    .line 127
    .line 128
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    const/4 v3, 0x0

    .line 133
    const-string v4, "CANCEL"

    .line 134
    .line 135
    if-eqz v0, :cond_7

    .line 136
    .line 137
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 138
    .line 139
    if-nez p1, :cond_4

    .line 140
    .line 141
    const-string p1, "Load/read file first before WRITE."

    .line 142
    .line 143
    const-string v0, "Load file first"

    .line 144
    .line 145
    invoke-static {p0, p1, p0, v0, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 146
    .line 147
    .line 148
    goto/16 :goto_1

    .line 149
    .line 150
    :cond_4
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->t()Z

    .line 151
    .line 152
    .line 153
    move-result p1

    .line 154
    if-nez p1, :cond_5

    .line 155
    .line 156
    goto/16 :goto_1

    .line 157
    .line 158
    :cond_5
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->N:Ljava/lang/String;

    .line 159
    .line 160
    invoke-static {p1}, Lg1/n;->b(Ljava/lang/String;)I

    .line 161
    .line 162
    .line 163
    move-result p1

    .line 164
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 165
    .line 166
    array-length v0, v0

    .line 167
    if-eq v0, p1, :cond_6

    .line 168
    .line 169
    const-string p1, "File size mismatch. Select the correct chip or load the matching file."

    .line 170
    .line 171
    const-string v0, "File size mismatch"

    .line 172
    .line 173
    invoke-static {p0, p1, p0, v0, v2}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 174
    .line 175
    .line 176
    goto/16 :goto_1

    .line 177
    .line 178
    :cond_6
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 179
    .line 180
    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 181
    .line 182
    .line 183
    const-string v1, "Write 25XX SPI flash?"

    .line 184
    .line 185
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    const-string v1, "This reads the current chip, writes only the required SPI changes when safe, then verifies. Keep backup before writing."

    .line 190
    .line 191
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    new-instance v1, Lg1/v3;

    .line 196
    .line 197
    invoke-direct {v1, p0, p1}, Lg1/v3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 198
    .line 199
    .line 200
    const-string p1, "WRITE"

    .line 201
    .line 202
    invoke-virtual {v0, p1, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    invoke-virtual {p1, v4, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 211
    .line 212
    .line 213
    goto :goto_1

    .line 214
    :cond_7
    const-string v0, "erase"

    .line 215
    .line 216
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    if-eqz v0, :cond_9

    .line 221
    .line 222
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->t()Z

    .line 223
    .line 224
    .line 225
    move-result p1

    .line 226
    if-nez p1, :cond_8

    .line 227
    .line 228
    goto :goto_1

    .line 229
    :cond_8
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 230
    .line 231
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 232
    .line 233
    .line 234
    const-string v0, "Erase 25XX SPI flash?"

    .line 235
    .line 236
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    const-string v0, "This clears the connected SPI flash. Save backup first."

    .line 241
    .line 242
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    new-instance v0, Lg1/t3;

    .line 247
    .line 248
    const/4 v1, 0x5

    .line 249
    invoke-direct {v0, p0, v1}, Lg1/t3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;I)V

    .line 250
    .line 251
    .line 252
    const-string v1, "ERASE"

    .line 253
    .line 254
    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 255
    .line 256
    .line 257
    move-result-object p1

    .line 258
    invoke-virtual {p1, v4, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 259
    .line 260
    .line 261
    move-result-object p1

    .line 262
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 263
    .line 264
    .line 265
    goto :goto_1

    .line 266
    :cond_9
    const-string v0, "verify"

    .line 267
    .line 268
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    if-eqz p1, :cond_c

    .line 273
    .line 274
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 275
    .line 276
    if-nez p1, :cond_a

    .line 277
    .line 278
    const-string p1, "Load/read file first before VERIFY."

    .line 279
    .line 280
    const-string v0, "Load/read file first"

    .line 281
    .line 282
    invoke-static {p0, p1, p0, v0, v1}, Landroidx/fragment/app/e1;->m(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;Ljava/lang/String;I)V

    .line 283
    .line 284
    .line 285
    goto :goto_1

    .line 286
    :cond_a
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->t()Z

    .line 287
    .line 288
    .line 289
    move-result p1

    .line 290
    if-nez p1, :cond_b

    .line 291
    .line 292
    goto :goto_1

    .line 293
    :cond_b
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->Q:[B

    .line 294
    .line 295
    invoke-virtual {p1}, [B->clone()Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object p1

    .line 299
    check-cast p1, [B

    .line 300
    .line 301
    const-string v0, "Verifying 25XX SPI flash..."

    .line 302
    .line 303
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->A(Z)V

    .line 307
    .line 308
    .line 309
    new-instance v0, Ljava/lang/Thread;

    .line 310
    .line 311
    new-instance v2, Lg1/w3;

    .line 312
    .line 313
    invoke-direct {v2, p0, p1, v1}, Lg1/w3;-><init>(Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;[BI)V

    .line 314
    .line 315
    .line 316
    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 320
    .line 321
    .line 322
    :cond_c
    :goto_1
    return-void
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final z(Ljava/lang/String;[B)V
    .locals 3

    .line 1
    if-nez p2, :cond_0

    const-string p1, "Save failed: no buffer."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_0
    new-instance v0, Ljava/io/File;

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v2, "GKC_CH341A"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-nez v1, :cond_1

    const-string p1, "Save failed: app folder not created."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_1
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {p1, p2}, Ljava/io/FileOutputStream;->write([B)V

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Saved BIN: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;->p(Ljava/lang/String;)V

    const-string p1, "BIN saved in app folder"

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method
