.class public Lapp/gkc/terminal/Activity/HexBufferActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:[B

.field public F:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Le/m;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const v0, 0x7f090240

    if-ne p1, v0, :cond_0

    iget p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->F:I

    add-int/lit8 p1, p1, -0x1

    :goto_0
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HexBufferActivity;->p(I)V

    goto :goto_1

    :cond_0
    const v0, 0x7f09023e

    if-ne p1, v0, :cond_1

    iget p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->F:I

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    const v0, 0x7f090231

    if-ne p1, v0, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_2
    :goto_1
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0029

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f090241

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->B:Landroid/widget/TextView;

    const p1, 0x7f09023f

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f090230

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->D:Landroid/widget/TextView;

    const p1, 0x7f090240

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    const v0, 0x7f09023e

    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    const v1, 0x7f090231

    invoke-virtual {p0, v1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    sget-object p1, Lg1/b3;->f:[B

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    sget-object p1, Lg1/b3;->g:Ljava/lang/String;

    if-nez p1, :cond_0

    const-string p1, "Read Buffer"

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->B:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    const/4 v0, 0x0

    if-eqz p1, :cond_2

    array-length p1, p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/HexBufferActivity;->p(I)V

    return-void

    :cond_2
    :goto_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->D:Landroid/widget/TextView;

    const-string v1, "No buffer loaded."

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->C:Landroid/widget/TextView;

    const-string v1, "0 bytes"

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "No buffer loaded"

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(I)V
    .locals 9

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    .line 2
    .line 3
    array-length v0, v0

    .line 4
    add-int/lit8 v0, v0, -0x1

    .line 5
    .line 6
    div-int/lit16 v0, v0, 0x200

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    iput p1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->F:I

    .line 22
    .line 23
    mul-int/lit16 p1, p1, 0x200

    .line 24
    .line 25
    iget-object v1, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    .line 26
    .line 27
    array-length v1, v1

    .line 28
    add-int/lit16 v2, p1, 0x200

    .line 29
    .line 30
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    iget-object v2, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->C:Landroid/widget/TextView;

    .line 35
    .line 36
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 37
    .line 38
    iget v4, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->F:I

    .line 39
    .line 40
    add-int/lit8 v4, v4, 0x1

    .line 41
    .line 42
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    add-int/lit8 v0, v0, 0x1

    .line 47
    .line 48
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    add-int/lit8 v6, v1, -0x1

    .line 57
    .line 58
    invoke-static {p1, v6}, Ljava/lang/Math;->max(II)I

    .line 59
    .line 60
    .line 61
    move-result v6

    .line 62
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    filled-new-array {v4, v0, v5, v6}, [Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    const-string v4, "Page %d/%d   0x%06X - 0x%06X"

    .line 71
    .line 72
    invoke-static {v3, v4, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 77
    .line 78
    .line 79
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->D:Landroid/widget/TextView;

    .line 80
    .line 81
    new-instance v2, Ljava/lang/StringBuilder;

    .line 82
    .line 83
    const-string v3, "OFFSET    00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n--------------------------------------------------------\n"

    .line 84
    .line 85
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    :goto_0
    if-ge p1, v1, :cond_4

    .line 89
    .line 90
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 91
    .line 92
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    const-string v5, "%06X   "

    .line 101
    .line 102
    invoke-static {v3, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    add-int/lit8 v3, p1, 0x10

    .line 110
    .line 111
    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    move v5, p1

    .line 116
    :goto_1
    if-ge v5, v3, :cond_1

    .line 117
    .line 118
    if-ge v5, v4, :cond_0

    .line 119
    .line 120
    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 121
    .line 122
    iget-object v7, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    .line 123
    .line 124
    aget-byte v7, v7, v5

    .line 125
    .line 126
    and-int/lit16 v7, v7, 0xff

    .line 127
    .line 128
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v7

    .line 136
    const-string v8, "%02X "

    .line 137
    .line 138
    invoke-static {v6, v8, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    :goto_2
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    goto :goto_3

    .line 146
    :cond_0
    const-string v6, "   "

    .line 147
    .line 148
    goto :goto_2

    .line 149
    :goto_3
    add-int/lit8 v5, v5, 0x1

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_1
    const-string v5, "  "

    .line 153
    .line 154
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    :goto_4
    if-ge p1, v4, :cond_3

    .line 158
    .line 159
    iget-object v5, p0, Lapp/gkc/terminal/Activity/HexBufferActivity;->E:[B

    .line 160
    .line 161
    aget-byte v5, v5, p1

    .line 162
    .line 163
    and-int/lit16 v5, v5, 0xff

    .line 164
    .line 165
    const/16 v6, 0x20

    .line 166
    .line 167
    if-lt v5, v6, :cond_2

    .line 168
    .line 169
    const/16 v6, 0x7e

    .line 170
    .line 171
    if-gt v5, v6, :cond_2

    .line 172
    .line 173
    int-to-char v5, v5

    .line 174
    goto :goto_5

    .line 175
    :cond_2
    const/16 v5, 0x2e

    .line 176
    .line 177
    :goto_5
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    add-int/lit8 p1, p1, 0x1

    .line 181
    .line 182
    goto :goto_4

    .line 183
    :cond_3
    const/16 p1, 0xa

    .line 184
    .line 185
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    move p1, v3

    .line 189
    goto :goto_0

    .line 190
    :cond_4
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object p1

    .line 194
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 195
    .line 196
    .line 197
    return-void
    .line 198
.end method
