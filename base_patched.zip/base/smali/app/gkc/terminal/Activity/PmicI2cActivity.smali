.class public Lapp/gkc/terminal/Activity/PmicI2cActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final synthetic Z:I


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/ScrollView;

.field public G:Landroid/widget/Button;

.field public H:Landroid/widget/LinearLayout;

.field public I:Landroid/widget/LinearLayout;

.field public J:Landroid/widget/Button;

.field public K:Landroid/widget/Button;

.field public L:Landroid/widget/Button;

.field public M:Landroid/widget/Button;

.field public N:Ljava/io/File;

.field public O:Landroid/hardware/usb/UsbManager;

.field public final P:Lg1/n;

.field public Q:Z

.field public R:Lg1/p2;

.field public S:I

.field public T:I

.field public U:I

.field public V:I

.field public W:Z

.field public final X:Le/d0;

.field public Y:[Lg1/p2;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Lg1/n;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lg1/n;-><init>(I)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    const/4 v0, -0x1

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    new-instance v0, Le/d0;

    const/4 v1, 0x7

    invoke-direct {v0, v1, p0}, Le/d0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->X:Le/d0;

    return-void
.end method

.method public static J(Lg1/p2;)Z
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x1

    .line 6
    iget-object v2, p0, Lg1/p2;->h:Lg1/q2;

    .line 7
    .line 8
    if-eqz v2, :cond_1

    .line 9
    .line 10
    invoke-virtual {v2}, Lg1/q2;->a()Z

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    if-nez v3, :cond_4

    .line 15
    .line 16
    goto :goto_2

    .line 17
    :cond_1
    const-string v3, "-?\\d+(\\.\\d+)?V - -?\\d+(\\.\\d+)?V"

    .line 18
    .line 19
    iget-object v4, p0, Lg1/p2;->f:Ljava/lang/String;

    .line 20
    .line 21
    if-eqz v4, :cond_2

    .line 22
    .line 23
    invoke-virtual {v4, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    if-eqz v5, :cond_2

    .line 28
    .line 29
    move v5, v1

    .line 30
    goto :goto_0

    .line 31
    :cond_2
    move v5, v0

    .line 32
    :goto_0
    iget-object v6, p0, Lg1/p2;->g:Ljava/lang/String;

    .line 33
    .line 34
    if-eqz v5, :cond_3

    .line 35
    .line 36
    if-eqz v6, :cond_3

    .line 37
    .line 38
    invoke-virtual {v6, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_3

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_3
    const-string v3, "meter calibrated"

    .line 46
    .line 47
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v4

    .line 51
    if-eqz v4, :cond_8

    .line 52
    .line 53
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    if-eqz v3, :cond_8

    .line 58
    .line 59
    :cond_4
    :goto_1
    if-eqz v2, :cond_6

    .line 60
    .line 61
    iget p0, v2, Lg1/q2;->l:I

    .line 62
    .line 63
    if-eqz p0, :cond_5

    .line 64
    .line 65
    iget p0, v2, Lg1/q2;->d:I

    .line 66
    .line 67
    if-lez p0, :cond_5

    .line 68
    .line 69
    iget p0, v2, Lg1/q2;->f:I

    .line 70
    .line 71
    invoke-virtual {v2, p0}, Lg1/q2;->c(I)Z

    .line 72
    .line 73
    .line 74
    move-result p0

    .line 75
    if-eqz p0, :cond_5

    .line 76
    .line 77
    iget p0, v2, Lg1/q2;->g:I

    .line 78
    .line 79
    invoke-virtual {v2, p0}, Lg1/q2;->c(I)Z

    .line 80
    .line 81
    .line 82
    move-result p0

    .line 83
    if-eqz p0, :cond_5

    .line 84
    .line 85
    move v0, v1

    .line 86
    :cond_5
    return v0

    .line 87
    :cond_6
    invoke-static {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->L(Lg1/p2;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    if-nez v2, :cond_7

    .line 92
    .line 93
    const-string v2, "RT43"

    .line 94
    .line 95
    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result p0

    .line 101
    if-eqz p0, :cond_8

    .line 102
    .line 103
    :cond_7
    move v0, v1

    .line 104
    :cond_8
    :goto_2
    return v0
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public static L(Lg1/p2;)Z
    .locals 2

    .line 1
    iget-object v0, p0, Lg1/p2;->b:Ljava/lang/String;

    const-string v1, "SM4053"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "SW"

    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "RT23"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "TPS177"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "CM508"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static M(Lg1/p2;I)D
    .locals 4

    .line 1
    iget-object v0, p0, Lg1/p2;->h:Lg1/q2;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-boolean v1, v0, Lg1/q2;->m:Z

    .line 6
    .line 7
    if-nez v1, :cond_1

    .line 8
    .line 9
    iget p0, v0, Lg1/q2;->j:I

    .line 10
    .line 11
    sub-int/2addr p1, p0

    .line 12
    iget-object p0, v0, Lg1/q2;->n:[I

    .line 13
    .line 14
    invoke-static {p0, p1}, Lg1/q2;->b([II)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    aget p0, p0, p1

    .line 21
    .line 22
    int-to-double p0, p0

    .line 23
    const-wide/high16 v0, 0x4024000000000000L    # 10.0

    .line 24
    .line 25
    div-double/2addr p0, v0

    .line 26
    return-wide p0

    .line 27
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 28
    .line 29
    const-string p1, "PMIC code is outside the verified table."

    .line 30
    .line 31
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw p0

    .line 35
    :cond_1
    const-string v0, "CS703"

    .line 36
    .line 37
    iget-object v1, p0, Lg1/p2;->a:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_2

    .line 44
    .line 45
    and-int/lit16 p0, p1, 0xff

    .line 46
    .line 47
    int-to-double p0, p0

    .line 48
    const-wide/high16 v0, 0x4010000000000000L    # 4.0

    .line 49
    .line 50
    add-double/2addr p0, v0

    .line 51
    return-wide p0

    .line 52
    :cond_2
    const-string v0, "SM4053"

    .line 53
    .line 54
    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_4

    .line 61
    .line 62
    and-int/lit16 p0, p1, 0xff

    .line 63
    .line 64
    const/16 p1, 0xc

    .line 65
    .line 66
    if-lt p0, p1, :cond_3

    .line 67
    .line 68
    const-wide p0, 0x403d333333333333L    # 29.2

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    return-wide p0

    .line 74
    :cond_3
    const-wide v0, 0x403119999999999aL    # 17.1

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    int-to-double p0, p0

    .line 80
    add-double/2addr p0, v0

    .line 81
    return-wide p0

    .line 82
    :cond_4
    const-string v0, "RT6908"

    .line 83
    .line 84
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_5

    .line 89
    .line 90
    and-int/lit16 p0, p1, 0xff

    .line 91
    .line 92
    int-to-double p0, p0

    .line 93
    const-wide/high16 v0, 0x3fe0000000000000L    # 0.5

    .line 94
    .line 95
    mul-double/2addr p0, v0

    .line 96
    const-wide v0, 0x4038800000000000L    # 24.5

    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    add-double/2addr p0, v0

    .line 102
    return-wide p0

    .line 103
    :cond_5
    const-string v0, "RT6950"

    .line 104
    .line 105
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-eqz v1, :cond_7

    .line 110
    .line 111
    and-int/lit16 p0, p1, 0xff

    .line 112
    .line 113
    const/16 p1, 0x80

    .line 114
    .line 115
    if-lt p0, p1, :cond_6

    .line 116
    .line 117
    int-to-double p0, p0

    .line 118
    const-wide/high16 v0, 0x405f000000000000L    # 124.0

    .line 119
    .line 120
    sub-double/2addr p0, v0

    .line 121
    return-wide p0

    .line 122
    :cond_6
    int-to-double p0, p0

    .line 123
    const-wide/high16 v0, 0x404e000000000000L    # 60.0

    .line 124
    .line 125
    sub-double/2addr p0, v0

    .line 126
    return-wide p0

    .line 127
    :cond_7
    const-string v1, "RT23"

    .line 128
    .line 129
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    if-eqz v1, :cond_8

    .line 134
    .line 135
    const-wide v0, 0x4032800000000000L    # 18.5

    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    goto :goto_0

    .line 141
    :cond_8
    const-string v1, "RT43"

    .line 142
    .line 143
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-eqz v1, :cond_9

    .line 148
    .line 149
    const-wide/high16 v0, 0x4034000000000000L    # 20.0

    .line 150
    .line 151
    goto :goto_0

    .line 152
    :cond_9
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-eqz v0, :cond_a

    .line 157
    .line 158
    const-wide/high16 v0, 0x4036000000000000L    # 22.0

    .line 159
    .line 160
    goto :goto_0

    .line 161
    :cond_a
    const-string v0, "SM"

    .line 162
    .line 163
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result p0

    .line 167
    if-eqz p0, :cond_b

    .line 168
    .line 169
    const-wide/high16 v0, 0x4032000000000000L    # 18.0

    .line 170
    .line 171
    goto :goto_0

    .line 172
    :cond_b
    const-wide/high16 v0, 0x4031000000000000L    # 17.0

    .line 173
    .line 174
    :goto_0
    and-int/lit16 p0, p1, 0xff

    .line 175
    .line 176
    int-to-double p0, p0

    .line 177
    const-wide v2, 0x3fb999999999999aL    # 0.1

    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    mul-double/2addr p0, v2

    .line 183
    add-double/2addr p0, v0

    .line 184
    return-wide p0
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static N(Lg1/p2;I)D
    .locals 5

    .line 1
    iget-object v0, p0, Lg1/p2;->h:Lg1/q2;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object p0, v0, Lg1/q2;->o:[I

    .line 6
    .line 7
    invoke-static {p0, p1}, Lg1/q2;->b([II)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    aget p0, p0, p1

    .line 14
    .line 15
    int-to-double p0, p0

    .line 16
    const-wide/high16 v0, 0x4024000000000000L    # 10.0

    .line 17
    .line 18
    div-double/2addr p0, v0

    .line 19
    return-wide p0

    .line 20
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 21
    .line 22
    const-string p1, "PMIC code is outside the verified table."

    .line 23
    .line 24
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw p0

    .line 28
    :cond_1
    const-string v0, "CS703"

    .line 29
    .line 30
    iget-object v1, p0, Lg1/p2;->a:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    and-int/lit16 p0, p1, 0xff

    .line 39
    .line 40
    int-to-double p0, p0

    .line 41
    const-wide v0, 0x3fe1eb851eb851ecL    # 0.56

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    mul-double/2addr p0, v0

    .line 47
    const-wide v0, 0x404f39999999999aL    # 62.45

    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    sub-double/2addr p0, v0

    .line 53
    return-wide p0

    .line 54
    :cond_2
    const-string v0, "SM4053"

    .line 55
    .line 56
    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    .line 57
    .line 58
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    const-wide v1, -0x4003333333333333L    # -1.8

    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    const-wide v3, 0x3fb999999999999aL    # 0.1

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    :goto_0
    and-int/lit16 p0, p1, 0xff

    .line 75
    .line 76
    int-to-double p0, p0

    .line 77
    mul-double/2addr p0, v3

    .line 78
    sub-double/2addr v1, p0

    .line 79
    return-wide v1

    .line 80
    :cond_3
    const-string v0, "RT6908"

    .line 81
    .line 82
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_4

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_4
    const-string v0, "RT23"

    .line 90
    .line 91
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result p0

    .line 95
    if-eqz p0, :cond_5

    .line 96
    .line 97
    const-wide/high16 v0, -0x3fec000000000000L    # -5.0

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_5
    const-wide/high16 v0, -0x3fea000000000000L    # -5.5

    .line 101
    .line 102
    :goto_1
    and-int/lit16 p0, p1, 0xff

    .line 103
    .line 104
    int-to-double p0, p0

    .line 105
    mul-double/2addr p0, v3

    .line 106
    sub-double/2addr v0, p0

    .line 107
    return-wide v0
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static t(Lg1/p2;ZD)Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "SM4053"

    .line 2
    .line 3
    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_0

    .line 10
    .line 11
    if-nez p1, :cond_0

    .line 12
    .line 13
    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 14
    .line 15
    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    const-string p2, "%.2f V"

    .line 24
    .line 25
    invoke-static {p0, p2, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :cond_0
    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 31
    .line 32
    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    const-string p2, "%.1f V"

    .line 41
    .line 42
    invoke-static {p0, p2, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public static u(Lg1/p2;ZI)Z
    .locals 8

    .line 1
    iget-object v0, p0, Lg1/p2;->h:Lg1/q2;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    iget p0, v0, Lg1/q2;->j:I

    .line 8
    .line 9
    sub-int/2addr p2, p0

    .line 10
    iget-object p0, v0, Lg1/q2;->n:[I

    .line 11
    .line 12
    invoke-static {p0, p2}, Lg1/q2;->b([II)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    iget-object p0, v0, Lg1/q2;->o:[I

    .line 18
    .line 19
    invoke-static {p0, p2}, Lg1/q2;->b([II)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    :goto_0
    return p0

    .line 24
    :cond_1
    if-eqz p1, :cond_2

    .line 25
    .line 26
    invoke-static {p0, p2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->M(Lg1/p2;I)D

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    goto :goto_1

    .line 31
    :cond_2
    invoke-static {p0, p2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->N(Lg1/p2;I)D

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    :goto_1
    if-eqz p1, :cond_3

    .line 36
    .line 37
    iget-object v2, p0, Lg1/p2;->f:Ljava/lang/String;

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_3
    iget-object v2, p0, Lg1/p2;->g:Ljava/lang/String;

    .line 41
    .line 42
    :goto_2
    const/4 v3, 0x0

    .line 43
    const/4 v4, 0x1

    .line 44
    if-eqz v2, :cond_10

    .line 45
    .line 46
    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 47
    .line 48
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    const-string v7, "unknown"

    .line 53
    .line 54
    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result v6

    .line 58
    if-nez v6, :cond_10

    .line 59
    .line 60
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    const-string v5, "check"

    .line 65
    .line 66
    invoke-virtual {v2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-eqz v2, :cond_4

    .line 71
    .line 72
    goto/16 :goto_3

    .line 73
    .line 74
    :cond_4
    const-string v2, "SM4053"

    .line 75
    .line 76
    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    .line 77
    .line 78
    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    if-eqz v2, :cond_8

    .line 83
    .line 84
    if-eqz p1, :cond_6

    .line 85
    .line 86
    if-ltz p2, :cond_5

    .line 87
    .line 88
    const/16 p0, 0xf

    .line 89
    .line 90
    if-gt p2, p0, :cond_5

    .line 91
    .line 92
    move v3, v4

    .line 93
    :cond_5
    return v3

    .line 94
    :cond_6
    if-ltz p2, :cond_7

    .line 95
    .line 96
    const/16 p0, 0x3f

    .line 97
    .line 98
    if-gt p2, p0, :cond_7

    .line 99
    .line 100
    move v3, v4

    .line 101
    :cond_7
    return v3

    .line 102
    :cond_8
    const-string p2, "RT6908"

    .line 103
    .line 104
    invoke-virtual {p2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result p0

    .line 108
    if-eqz p0, :cond_c

    .line 109
    .line 110
    if-eqz p1, :cond_a

    .line 111
    .line 112
    const-wide p0, 0x4038800000000000L    # 24.5

    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    cmpl-double p0, v0, p0

    .line 118
    .line 119
    if-ltz p0, :cond_9

    .line 120
    .line 121
    const-wide/high16 p0, 0x4044000000000000L    # 40.0

    .line 122
    .line 123
    cmpg-double p0, v0, p0

    .line 124
    .line 125
    if-gtz p0, :cond_9

    .line 126
    .line 127
    move v3, v4

    .line 128
    :cond_9
    return v3

    .line 129
    :cond_a
    const-wide p0, -0x4003333333333333L    # -1.8

    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    cmpg-double p0, v0, p0

    .line 135
    .line 136
    if-gtz p0, :cond_b

    .line 137
    .line 138
    const-wide p0, -0x3fdfcccccccccccdL    # -8.1

    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    cmpl-double p0, v0, p0

    .line 144
    .line 145
    if-ltz p0, :cond_b

    .line 146
    .line 147
    move v3, v4

    .line 148
    :cond_b
    return v3

    .line 149
    :cond_c
    if-eqz p1, :cond_e

    .line 150
    .line 151
    const-wide/high16 p0, 0x4028000000000000L    # 12.0

    .line 152
    .line 153
    cmpl-double p0, v0, p0

    .line 154
    .line 155
    if-ltz p0, :cond_d

    .line 156
    .line 157
    const-wide/high16 p0, 0x4043000000000000L    # 38.0

    .line 158
    .line 159
    cmpg-double p0, v0, p0

    .line 160
    .line 161
    if-gtz p0, :cond_d

    .line 162
    .line 163
    move v3, v4

    .line 164
    :cond_d
    return v3

    .line 165
    :cond_e
    const-wide/high16 p0, -0x3ffc000000000000L    # -2.5

    .line 166
    .line 167
    cmpg-double p0, v0, p0

    .line 168
    .line 169
    if-gtz p0, :cond_f

    .line 170
    .line 171
    const-wide/high16 p0, -0x3fce000000000000L    # -18.0

    .line 172
    .line 173
    cmpl-double p0, v0, p0

    .line 174
    .line 175
    if-ltz p0, :cond_f

    .line 176
    .line 177
    move v3, v4

    .line 178
    :cond_f
    return v3

    .line 179
    :cond_10
    :goto_3
    if-ltz p2, :cond_11

    .line 180
    .line 181
    const/16 p0, 0xef

    .line 182
    .line 183
    if-gt p2, p0, :cond_11

    .line 184
    .line 185
    move v3, v4

    .line 186
    :cond_11
    return v3
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public static v(Lg1/p2;I)I
    .locals 1

    .line 1
    iget-object v0, p0, Lg1/p2;->h:Lg1/q2;

    if-eqz v0, :cond_0

    and-int/lit16 p0, p1, 0xff

    return p0

    :cond_0
    and-int/lit16 p1, p1, 0xff

    const-string v0, "SM4053"

    iget-object p0, p0, Lg1/p2;->b:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    const/16 p0, 0xe

    if-lt p1, p0, :cond_1

    const/16 p0, 0x20

    if-ge p1, p0, :cond_1

    add-int/lit8 p1, p1, 0x11

    :cond_1
    return p1
.end method

.method public static x(Ljava/lang/String;)I
    .locals 2

    .line 1
    const-string v0, "0x"

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "0X"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x10

    invoke-static {p0, v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final A()V
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 3
    .line 4
    iget-object v1, v1, Lg1/p2;->h:Lg1/q2;

    .line 5
    .line 6
    if-eqz v1, :cond_2

    .line 7
    .line 8
    iget v2, v1, Lg1/q2;->g:I

    .line 9
    .line 10
    iget v3, v1, Lg1/q2;->f:I

    .line 11
    .line 12
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->B(Lg1/q2;)[B

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    array-length v5, v4

    .line 17
    iget v6, v1, Lg1/q2;->d:I

    .line 18
    .line 19
    if-ne v5, v6, :cond_1

    .line 20
    .line 21
    invoke-virtual {v1, v3}, Lg1/q2;->c(I)Z

    .line 22
    .line 23
    .line 24
    move-result v5

    .line 25
    if-eqz v5, :cond_1

    .line 26
    .line 27
    invoke-virtual {v1, v2}, Lg1/q2;->c(I)Z

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    if-eqz v5, :cond_1

    .line 32
    .line 33
    aget-byte v3, v4, v3

    .line 34
    .line 35
    and-int/lit16 v3, v3, 0xff

    .line 36
    .line 37
    iput v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 38
    .line 39
    aget-byte v2, v4, v2

    .line 40
    .line 41
    and-int/lit16 v2, v2, 0xff

    .line 42
    .line 43
    iput v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 44
    .line 45
    iget v2, v1, Lg1/q2;->j:I

    .line 46
    .line 47
    sub-int/2addr v3, v2

    .line 48
    iget-object v2, v1, Lg1/q2;->n:[I

    .line 49
    .line 50
    invoke-static {v2, v3}, Lg1/q2;->b([II)Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_0

    .line 55
    .line 56
    iget v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 57
    .line 58
    iget-object v3, v1, Lg1/q2;->o:[I

    .line 59
    .line 60
    invoke-static {v3, v2}, Lg1/q2;->b([II)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_0

    .line 65
    .line 66
    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 67
    .line 68
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->z(Lg1/q2;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 72
    .line 73
    .line 74
    const-string v1, "Verified PMIC profile read successfully."

    .line 75
    .line 76
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_0
    new-instance v1, Ljava/io/IOException;

    .line 81
    .line 82
    const-string v2, "Read rail codes are outside the verified table."

    .line 83
    .line 84
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw v1

    .line 88
    :cond_1
    new-instance v1, Ljava/io/IOException;

    .line 89
    .line 90
    const-string v2, "Verified PMIC block is incomplete."

    .line 91
    .line 92
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw v1

    .line 96
    :cond_2
    new-instance v1, Ljava/io/IOException;

    .line 97
    .line 98
    const-string v2, "No verified PMIC profile selected."

    .line 99
    .line 100
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 104
    :catch_0
    const/4 v1, 0x0

    .line 105
    iput-boolean v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 106
    .line 107
    const/4 v1, -0x1

    .line 108
    iput v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 109
    .line 110
    iput v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 111
    .line 112
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 113
    .line 114
    .line 115
    const-string v1, "Verified PMIC read failed. Check selected IC, SDA, SCL, GND and power."

    .line 116
    .line 117
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    const-string v1, "Board read failed"

    .line 121
    .line 122
    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 127
    .line 128
    .line 129
    return-void
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final B(Lg1/q2;)[B
    .locals 5

    .line 1
    iget-object v0, p1, Lg1/q2;->k:Ljava/lang/Integer;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    iget v2, p1, Lg1/q2;->c:I

    if-eqz v0, :cond_0

    const/16 v3, 0xff

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v1, v2, v3, v0}, Lg1/n;->Q(III)V

    iget v0, p1, Lg1/q2;->e:I

    int-to-long v3, v0

    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    :cond_0
    const/4 v0, 0x0

    iget p1, p1, Lg1/q2;->d:I

    invoke-virtual {v1, v2, v0, p1}, Lg1/n;->x(III)[B

    move-result-object v0

    array-length v1, v0

    if-ne v1, p1, :cond_1

    return-object v0

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Incomplete PMIC block read."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final C(Lg1/q2;II)I
    .locals 6

    .line 1
    const/4 v0, -0x1

    const/4 v1, 0x1

    :goto_0
    const/4 v2, 0x3

    if-gt v1, v2, :cond_1

    const-wide/16 v2, 0x28

    int-to-long v4, v1

    mul-long/2addr v4, v2

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    invoke-virtual {p0, p1, p2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D(Lg1/q2;I)I

    move-result v0

    if-ne v0, p3, :cond_0

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v1, "Expected code "

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, ", read "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, " after profile apply trigger."

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final D(Lg1/q2;I)I
    .locals 6

    .line 1
    iget-object v0, p1, Lg1/q2;->k:Ljava/lang/Integer;

    const/16 v1, 0xff

    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    iget v3, p1, Lg1/q2;->c:I

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v2, v3, v1, v0}, Lg1/n;->Q(III)V

    iget p1, p1, Lg1/q2;->e:I

    int-to-long v4, p1

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    :cond_0
    invoke-virtual {v2, v3, p2}, Lg1/n;->w(II)B

    move-result p1

    and-int/2addr p1, v1

    return p1
.end method

.method public final E(III)[I
    .locals 5

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    iget-object v0, v0, Lg1/p2;->h:Lg1/q2;

    const/16 v1, 0xff

    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lg1/q2;->k:Ljava/lang/Integer;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v2, p1, v1, v0}, Lg1/n;->Q(III)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    iget-object v0, v0, Lg1/p2;->h:Lg1/q2;

    iget v0, v0, Lg1/q2;->e:I

    int-to-long v3, v0

    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    :cond_0
    invoke-virtual {v2, p1, p2}, Lg1/n;->w(II)B

    move-result v0

    and-int/2addr v0, v1

    invoke-virtual {v2, p1, p3}, Lg1/n;->w(II)B

    move-result v3

    and-int/2addr v3, v1

    invoke-virtual {v2, p1, p2}, Lg1/n;->w(II)B

    move-result p2

    and-int/2addr p2, v1

    invoke-virtual {v2, p1, p3}, Lg1/n;->w(II)B

    move-result p1

    and-int/2addr p1, v1

    if-ne v0, p2, :cond_1

    if-ne v3, p1, :cond_1

    filled-new-array {v0, v3}, [I

    move-result-object p1

    return-object p1

    :cond_1
    new-instance p1, Ljava/lang/Exception;

    const-string p2, "unstable I2C data"

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final F()V
    .locals 5

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->B:Landroid/widget/TextView;

    .line 2
    .line 3
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 4
    .line 5
    iget-object v1, v1, Lg1/p2;->a:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 11
    .line 12
    const-string v1, "RT23"

    .line 13
    .line 14
    iget-object v0, v0, Lg1/p2;->b:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 21
    .line 22
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 23
    .line 24
    const/4 v1, -0x1

    .line 25
    iput v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 26
    .line 27
    iput v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 28
    .line 29
    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 30
    .line 31
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 32
    .line 33
    iget-object v1, v1, Lg1/p2;->h:Lg1/q2;

    .line 34
    .line 35
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->H:Landroid/widget/LinearLayout;

    .line 36
    .line 37
    const/16 v3, 0x8

    .line 38
    .line 39
    if-eqz v1, :cond_0

    .line 40
    .line 41
    iget v4, v1, Lg1/q2;->h:I

    .line 42
    .line 43
    if-ltz v4, :cond_0

    .line 44
    .line 45
    move v4, v0

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    move v4, v3

    .line 48
    :goto_0
    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    .line 49
    .line 50
    .line 51
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->I:Landroid/widget/LinearLayout;

    .line 52
    .line 53
    if-eqz v1, :cond_1

    .line 54
    .line 55
    iget v4, v1, Lg1/q2;->i:I

    .line 56
    .line 57
    if-ltz v4, :cond_1

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_1
    move v0, v3

    .line 61
    :goto_1
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 62
    .line 63
    .line 64
    if-eqz v1, :cond_4

    .line 65
    .line 66
    iget v0, v1, Lg1/q2;->h:I

    .line 67
    .line 68
    if-ltz v0, :cond_2

    .line 69
    .line 70
    const-string v0, "Supported adjustments: VGH, VGL, VGL2"

    .line 71
    .line 72
    goto :goto_2

    .line 73
    :cond_2
    const-string v0, "Supported adjustments: VGH, VGL"

    .line 74
    .line 75
    :goto_2
    iget v1, v1, Lg1/q2;->i:I

    .line 76
    .line 77
    if-ltz v1, :cond_3

    .line 78
    .line 79
    const-string v1, ", VCOM"

    .line 80
    .line 81
    invoke-static {v0, v1}, Landroidx/fragment/app/e1;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    :cond_3
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->C:Landroid/widget/TextView;

    .line 86
    .line 87
    new-instance v2, Ljava/lang/StringBuilder;

    .line 88
    .line 89
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v0, "\nRead the board first. Save creates a backup and checks the result."

    .line 96
    .line 97
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    .line 106
    .line 107
    goto :goto_3

    .line 108
    :cond_4
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->C:Landroid/widget/TextView;

    .line 109
    .line 110
    const-string v1, "Read board to sync. Use VGH/VGL buttons for live test. WRITE BOARD saves current PMIC values."

    .line 111
    .line 112
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 113
    .line 114
    .line 115
    :goto_3
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 116
    .line 117
    .line 118
    return-void
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final G([B)V
    .locals 5

    .line 1
    const-string v0, "pmic-backups"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    if-nez v1, :cond_0

    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :cond_0
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Could not create the PMIC backup folder."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    iget-object v0, v0, Lg1/p2;->a:Ljava/lang/String;

    const-string v2, "[^A-Za-z0-9_-]"

    const-string v3, "_"

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyyMMdd_HHmmss_SSS"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v3, Ljava/util/Date;

    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    invoke-virtual {v2, v3}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "_before_aux_adjust_"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".bin"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v1, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    :try_start_0
    invoke-virtual {v0, p1}, Ljava/io/FileOutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object p1

    invoke-virtual {p1}, Ljava/io/FileDescriptor;->sync()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v0

    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    throw p1
.end method

.method public final H(Lg1/q2;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Y:[Lg1/p2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    iget-object v4, v3, Lg1/p2;->h:Lg1/q2;

    if-eq v4, p1, :cond_1

    iget-object v4, v3, Lg1/p2;->a:Ljava/lang/String;

    iget-object v5, p1, Lg1/q2;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iput-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->F()V

    :cond_2
    return-void
.end method

.method public final I(Z)V
    .locals 4

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J:Landroid/widget/Button;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    if-nez v0, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    iget-object v0, v0, Lg1/p2;->h:Lg1/q2;

    :goto_0
    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    iget-boolean v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    if-eqz v3, :cond_2

    if-eqz v0, :cond_2

    iget v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    invoke-virtual {v0, v3}, Lg1/q2;->e(I)Z

    move-result v3

    if-eqz v3, :cond_2

    move v3, v2

    goto :goto_1

    :cond_2
    move v3, v1

    :goto_1
    if-eqz p1, :cond_3

    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    if-eqz p1, :cond_3

    if-eqz v0, :cond_3

    iget p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    invoke-virtual {v0, p1}, Lg1/q2;->d(I)Z

    move-result p1

    if-eqz p1, :cond_3

    move v1, v2

    :cond_3
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J:Landroid/widget/Button;

    invoke-virtual {p1, v3}, Landroid/view/View;->setEnabled(Z)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K:Landroid/widget/Button;

    invoke-virtual {p1, v3}, Landroid/view/View;->setEnabled(Z)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->L:Landroid/widget/Button;

    invoke-virtual {p1, v1}, Landroid/view/View;->setEnabled(Z)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->M:Landroid/widget/Button;

    invoke-virtual {p1, v1}, Landroid/view/View;->setEnabled(Z)V

    return-void
.end method

.method public final K()V
    .locals 9

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D:Landroid/widget/TextView;

    .line 7
    .line 8
    const-string v2, "VGH: --\nVGL: --"

    .line 9
    .line 10
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->I(Z)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 18
    .line 19
    iget-object v0, v0, Lg1/p2;->h:Lg1/q2;

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    if-eqz v0, :cond_1

    .line 23
    .line 24
    iget-boolean v0, v0, Lg1/q2;->m:Z

    .line 25
    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    const-string v0, "VGH setting ready"

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 32
    .line 33
    const-string v3, "VGH: "

    .line 34
    .line 35
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 39
    .line 40
    iget v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 41
    .line 42
    invoke-static {v3, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->M(Lg1/p2;I)D

    .line 43
    .line 44
    .line 45
    move-result-wide v4

    .line 46
    invoke-static {v3, v2, v4, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->t(Lg1/p2;ZD)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 58
    .line 59
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v0, "\nVGL: "

    .line 66
    .line 67
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 71
    .line 72
    iget v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 73
    .line 74
    invoke-static {v0, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->N(Lg1/p2;I)D

    .line 75
    .line 76
    .line 77
    move-result-wide v4

    .line 78
    invoke-static {v0, v1, v4, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->t(Lg1/p2;ZD)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 90
    .line 91
    iget-object v1, v1, Lg1/p2;->h:Lg1/q2;

    .line 92
    .line 93
    if-eqz v1, :cond_4

    .line 94
    .line 95
    iget v3, v1, Lg1/q2;->h:I

    .line 96
    .line 97
    if-ltz v3, :cond_4

    .line 98
    .line 99
    new-instance v3, Ljava/lang/StringBuilder;

    .line 100
    .line 101
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    iget v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 108
    .line 109
    invoke-virtual {v1, v0}, Lg1/q2;->e(I)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_3

    .line 114
    .line 115
    new-instance v0, Ljava/lang/StringBuilder;

    .line 116
    .line 117
    const-string v4, "\nVGL2: "

    .line 118
    .line 119
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 123
    .line 124
    iget v5, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 125
    .line 126
    sub-int/2addr v5, v2

    .line 127
    iget-object v6, v1, Lg1/q2;->p:[I

    .line 128
    .line 129
    invoke-static {v6, v5}, Lg1/q2;->b([II)Z

    .line 130
    .line 131
    .line 132
    move-result v7

    .line 133
    if-eqz v7, :cond_2

    .line 134
    .line 135
    aget v5, v6, v5

    .line 136
    .line 137
    int-to-double v5, v5

    .line 138
    const-wide/high16 v7, 0x4024000000000000L    # 10.0

    .line 139
    .line 140
    div-double/2addr v5, v7

    .line 141
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v5

    .line 149
    const-string v6, "%.1f V"

    .line 150
    .line 151
    invoke-static {v4, v6, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v4

    .line 155
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    goto :goto_1

    .line 163
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 164
    .line 165
    const-string v1, "PMIC code is outside the verified table."

    .line 166
    .line 167
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    throw v0

    .line 171
    :cond_3
    const-string v0, "\nVGL2: adjustment unavailable"

    .line 172
    .line 173
    :goto_1
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    :cond_4
    if-eqz v1, :cond_6

    .line 181
    .line 182
    iget v3, v1, Lg1/q2;->i:I

    .line 183
    .line 184
    if-ltz v3, :cond_6

    .line 185
    .line 186
    new-instance v3, Ljava/lang/StringBuilder;

    .line 187
    .line 188
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    iget v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 195
    .line 196
    invoke-virtual {v1, v0}, Lg1/q2;->d(I)Z

    .line 197
    .line 198
    .line 199
    move-result v0

    .line 200
    if-eqz v0, :cond_5

    .line 201
    .line 202
    const-string v0, "\nVCOM: adjustment ready"

    .line 203
    .line 204
    goto :goto_2

    .line 205
    :cond_5
    const-string v0, "\nVCOM: adjustment unavailable"

    .line 206
    .line 207
    :goto_2
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 208
    .line 209
    .line 210
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    :cond_6
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->I(Z)V

    .line 215
    .line 216
    .line 217
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D:Landroid/widget/TextView;

    .line 218
    .line 219
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 220
    .line 221
    .line 222
    return-void
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final O(Lg1/q2;II)V
    .locals 9

    .line 1
    iget-object v0, p1, Lg1/q2;->k:Ljava/lang/Integer;

    .line 2
    .line 3
    const/16 v1, 0xff

    .line 4
    .line 5
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    .line 6
    .line 7
    iget v3, p1, Lg1/q2;->c:I

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-virtual {v2, v3, v1, v0}, Lg1/n;->Q(III)V

    .line 16
    .line 17
    .line 18
    iget v0, p1, Lg1/q2;->e:I

    .line 19
    .line 20
    int-to-long v4, v0

    .line 21
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-virtual {v2, v3, p2, p3}, Lg1/n;->Q(III)V

    .line 25
    .line 26
    .line 27
    iget p1, p1, Lg1/q2;->l:I

    .line 28
    .line 29
    invoke-static {p1}, Lo/h;->a(I)I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    const/4 p2, 0x2

    .line 34
    const/4 p3, 0x0

    .line 35
    if-eqz p1, :cond_4

    .line 36
    .line 37
    const/4 v0, 0x1

    .line 38
    const-wide/16 v4, 0x96

    .line 39
    .line 40
    const/16 v6, 0x80

    .line 41
    .line 42
    if-eq p1, v0, :cond_2

    .line 43
    .line 44
    const-wide/16 v7, 0x5

    .line 45
    .line 46
    if-eq p1, p2, :cond_3

    .line 47
    .line 48
    const/4 p2, 0x3

    .line 49
    if-eq p1, p2, :cond_1

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_1
    invoke-virtual {v2, v3, v1, v0}, Lg1/n;->Q(III)V

    .line 53
    .line 54
    .line 55
    :goto_0
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V

    .line 56
    .line 57
    .line 58
    :cond_2
    invoke-virtual {v2, v3, v1, v6}, Lg1/n;->Q(III)V

    .line 59
    .line 60
    .line 61
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 62
    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_3
    invoke-virtual {v2, v3, v1, p3}, Lg1/n;->Q(III)V

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_4
    const/16 p1, 0x8

    .line 70
    .line 71
    invoke-virtual {v2, v3, p3, p1}, Lg1/n;->Q(III)V

    .line 72
    .line 73
    .line 74
    const-wide/16 v0, 0xc8

    .line 75
    .line 76
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v2, v3, p3, p2}, Lg1/n;->Q(III)V

    .line 80
    .line 81
    .line 82
    const-wide/16 p1, 0x14

    .line 83
    .line 84
    invoke-static {p1, p2}, Ljava/lang/Thread;->sleep(J)V

    .line 85
    .line 86
    .line 87
    :goto_1
    return-void
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 4

    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/y;->onActivityResult(IILandroid/content/Intent;)V

    const/16 v0, 0x190c

    if-ne p1, v0, :cond_4

    const/4 p1, -0x1

    if-ne p2, p1, :cond_4

    if-eqz p3, :cond_4

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    if-nez p2, :cond_0

    goto :goto_5

    :cond_0
    const/4 p2, 0x1

    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->N:Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p3

    invoke-virtual {v1, p3}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz p3, :cond_2

    const/16 v1, 0x2000

    :try_start_2
    new-array v1, v1, [B

    :goto_0
    invoke-virtual {v0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    if-eq v2, p1, :cond_1

    const/4 v3, 0x0

    invoke-virtual {p3, v1, v3, v2}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    const-string p1, "Bilingual SOP PDF saved"

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    invoke-virtual {p3}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_5

    :catchall_1
    move-exception p1

    goto :goto_3

    :cond_2
    :try_start_5
    new-instance p1, Ljava/io/IOException;

    const-string v1, "Unable to write the selected document."

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :goto_1
    if-eqz p3, :cond_3

    :try_start_6
    invoke-virtual {p3}, Ljava/io/OutputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception p3

    :try_start_7
    invoke-virtual {p1, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_2
    throw p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_3
    :try_start_8
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception p3

    :try_start_9
    invoke-virtual {p1, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p1
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0

    :catch_0
    const-string p1, "Could not save the SOP PDF"

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_4
    :goto_5
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 12

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f090107

    .line 6
    .line 7
    .line 8
    const-string v1, "Connect first"

    .line 9
    .line 10
    const-string v2, "Connect CH341A first."

    .line 11
    .line 12
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    const/4 v5, 0x1

    .line 16
    if-ne p1, v0, :cond_2

    .line 17
    .line 18
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    .line 19
    .line 20
    if-eqz p1, :cond_1

    .line 21
    .line 22
    invoke-virtual {v3}, Lg1/n;->j()Z

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    if-nez p1, :cond_0

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const-string p1, "Auto detect started. Checking verified PMIC profiles only..."

    .line 30
    .line 31
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    new-instance p1, Ljava/lang/Thread;

    .line 35
    .line 36
    new-instance v0, Lg1/m2;

    .line 37
    .line 38
    invoke-direct {v0, p0, v5}, Lg1/m2;-><init>(Lapp/gkc/terminal/Activity/PmicI2cActivity;I)V

    .line 39
    .line 40
    .line 41
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 45
    .line 46
    .line 47
    goto/16 :goto_a

    .line 48
    .line 49
    :cond_1
    :goto_0
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    invoke-static {p0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 57
    .line 58
    .line 59
    goto/16 :goto_a

    .line 60
    .line 61
    :cond_2
    const v0, 0x7f09013c

    .line 62
    .line 63
    .line 64
    const/4 v6, -0x1

    .line 65
    if-ne p1, v0, :cond_5

    .line 66
    .line 67
    new-instance p1, Landroid/widget/LinearLayout;

    .line 68
    .line 69
    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p1, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0}, Le/m;->getResources()Landroid/content/res/Resources;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 84
    .line 85
    const/high16 v1, 0x41800000    # 16.0f

    .line 86
    .line 87
    mul-float/2addr v0, v1

    .line 88
    float-to-int v0, v0

    .line 89
    invoke-virtual {p1, v0, v0, v0, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 90
    .line 91
    .line 92
    new-instance v0, Landroid/widget/EditText;

    .line 93
    .line 94
    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 95
    .line 96
    .line 97
    const-string v1, "Type IC number"

    .line 98
    .line 99
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 103
    .line 104
    .line 105
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 106
    .line 107
    const/4 v2, -0x2

    .line 108
    invoke-direct {v1, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 112
    .line 113
    .line 114
    new-instance v1, Landroid/widget/ListView;

    .line 115
    .line 116
    invoke-direct {v1, p0}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    .line 117
    .line 118
    .line 119
    new-instance v2, Ljava/util/ArrayList;

    .line 120
    .line 121
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 122
    .line 123
    .line 124
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Y:[Lg1/p2;

    .line 125
    .line 126
    array-length v7, v3

    .line 127
    :goto_1
    if-ge v4, v7, :cond_4

    .line 128
    .line 129
    aget-object v8, v3, v4

    .line 130
    .line 131
    invoke-static {v8}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J(Lg1/p2;)Z

    .line 132
    .line 133
    .line 134
    move-result v9

    .line 135
    if-eqz v9, :cond_3

    .line 136
    .line 137
    iget-object v8, v8, Lg1/p2;->a:Ljava/lang/String;

    .line 138
    .line 139
    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    :cond_3
    add-int/lit8 v4, v4, 0x1

    .line 143
    .line 144
    goto :goto_1

    .line 145
    :cond_4
    new-instance v3, Landroid/widget/ArrayAdapter;

    .line 146
    .line 147
    const v4, 0x1090003

    .line 148
    .line 149
    .line 150
    invoke-direct {v3, p0, v4, v2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v1, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 154
    .line 155
    .line 156
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 157
    .line 158
    invoke-virtual {p0}, Le/m;->getResources()Landroid/content/res/Resources;

    .line 159
    .line 160
    .line 161
    move-result-object v4

    .line 162
    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    iget v4, v4, Landroid/util/DisplayMetrics;->density:F

    .line 167
    .line 168
    const/high16 v7, 0x43b40000    # 360.0f

    .line 169
    .line 170
    mul-float/2addr v4, v7

    .line 171
    float-to-int v4, v4

    .line 172
    invoke-direct {v2, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 176
    .line 177
    .line 178
    new-instance v2, Landroid/app/AlertDialog$Builder;

    .line 179
    .line 180
    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 181
    .line 182
    .line 183
    const-string v4, "Select Power Profile"

    .line 184
    .line 185
    invoke-virtual {v2, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    invoke-virtual {v2, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    new-instance v2, Lg1/j2;

    .line 198
    .line 199
    invoke-direct {v2, p0, p1, v5}, Lg1/j2;-><init>(Le/m;Landroid/app/AlertDialog;I)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v1, v2}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 203
    .line 204
    .line 205
    new-instance v1, Lg1/l2;

    .line 206
    .line 207
    invoke-direct {v1, v3, v5}, Lg1/l2;-><init>(Landroid/widget/ArrayAdapter;I)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 211
    .line 212
    .line 213
    new-instance v1, Lg1/o2;

    .line 214
    .line 215
    invoke-direct {v1, v0}, Lg1/o2;-><init>(Landroid/widget/EditText;)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {p1, v1}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    .line 222
    .line 223
    .line 224
    goto/16 :goto_a

    .line 225
    .line 226
    :cond_5
    const v0, 0x7f090333

    .line 227
    .line 228
    .line 229
    const/4 v7, 0x0

    .line 230
    if-ne p1, v0, :cond_6

    .line 231
    .line 232
    new-instance p1, Landroid/widget/ScrollView;

    .line 233
    .line 234
    invoke-direct {p1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 235
    .line 236
    .line 237
    new-instance v0, Landroid/widget/TextView;

    .line 238
    .line 239
    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 240
    .line 241
    .line 242
    const-string v1, "ENGLISH\nPMIC I2C SAFE-USE SOP\n\nSupported auxiliary controls\nVGL2: RT6950, SW50212, SM4085.\nVCOM: LP6281, SM4186 (two profile variants), LG SW50224, RT6925, NT50330P, NT50330S, SG2510, IML8940, NT50660S Option 2, HX2510 Option 2.\nVGH/VGL controls appear for profiles that support them. Auxiliary controls appear only for the listed profiles.\n\n1. Prepare safely\nUnplug the TV before attaching clips. Work only on the low-voltage board side. Identify the exact PMIC marking and select its matching profile. Keep the original board data and a backup.\n\n2. Connect CH341A\nConnect CH341A to the phone with a USB-OTG adapter, then attach GND to board GND, SCL to SCL, and SDA to SDA. Use only the board\'s correct logic voltage. Do not connect CH341A VCC when the board is already powered; never connect mains voltage to the adapter.\n\n3. Read the board\nPower the board using its normal, safe low-voltage supply if required. Tap CONNECT and approve the USB prompt, choose the exact PMIC profile, then tap READ BOARD. Stop if the read fails or the profile is uncertain.\n\n4. Adjust carefully\nUse one step at a time. VGH/VGL buttons adjust their rail setting. VGL2 and VCOM buttons adjust one profile-supported setting step. Check the real output with a suitable multimeter and confirm stable panel operation after each step. Do not guess a target value.\n\n5. Save and check\nWhen readings are correct, tap WRITE BOARD and confirm. The app saves a full register backup before the auxiliary live adjustment and another backup before permanent save. Confirm the save status, power-cycle the board, then read again and recheck with a multimeter. Keep the backup for recovery.\n\n6. Stop conditions\nStop immediately for an unknown PMIC, unstable readings, unexpected heating, a short, or incorrect panel behavior. Disconnect power before changing clips. Use this tool only on equipment you are authorized to repair.\n\n\u0939\u093f\u0928\u094d\u0926\u0940\nPMIC I2C \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0909\u092a\u092f\u094b\u0917 \u0928\u093f\u0930\u094d\u0926\u0947\u0936\n\n\u0938\u0939\u093e\u092f\u0915 \u0928\u093f\u092f\u0902\u0924\u094d\u0930\u0923 \u0935\u093e\u0932\u0947 IC\nVGL2: RT6950, SW50212, SM4085\u0964\nVCOM: LP6281, SM4186 \u0915\u0947 \u0926\u094b \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932, LG SW50224, RT6925, NT50330P, NT50330S, SG2510, IML8940, NT50660S Option 2, HX2510 Option 2\u0964\nVGH/VGL \u0928\u093f\u092f\u0902\u0924\u094d\u0930\u0923 \u0915\u0947\u0935\u0932 \u0938\u092e\u0930\u094d\u0925\u093f\u0924 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u092e\u0947\u0902 \u0926\u093f\u0916\u0947\u0902\u0917\u0947\u0964 VGL2/VCOM \u0928\u093f\u092f\u0902\u0924\u094d\u0930\u0923 \u0915\u0947\u0935\u0932 \u090a\u092a\u0930 \u0926\u093f\u090f \u0917\u090f IC \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u092e\u0947\u0902 \u0926\u093f\u0916\u0947\u0902\u0917\u0947\u0964\n\n1. \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0924\u0948\u092f\u093e\u0930\u0940\n\u0915\u094d\u0932\u093f\u092a \u0932\u0917\u093e\u0928\u0947 \u0938\u0947 \u092a\u0939\u0932\u0947 TV \u0915\u093e \u092a\u094d\u0932\u0917 \u0928\u093f\u0915\u093e\u0932\u0947\u0902\u0964 \u0915\u0947\u0935\u0932 \u0932\u094b-\u0935\u094b\u0932\u094d\u091f\u0947\u091c \u092c\u094b\u0930\u094d\u0921 \u092a\u0930 \u0915\u093e\u092e \u0915\u0930\u0947\u0902\u0964 PMIC \u0915\u0940 \u0938\u0939\u0940 \u092a\u0939\u091a\u093e\u0928 \u0915\u0930\u0915\u0947 \u0935\u0939\u0940 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u091a\u0941\u0928\u0947\u0902\u0964 \u092e\u0942\u0932 \u0921\u0947\u091f\u093e \u0914\u0930 \u092c\u0948\u0915\u0905\u092a \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0930\u0916\u0947\u0902\u0964\n\n2. CH341A \u0915\u0928\u0947\u0915\u094d\u0936\u0928\nCH341A \u0915\u094b USB-OTG \u0905\u0921\u0948\u092a\u094d\u091f\u0930 \u0938\u0947 \u092b\u094b\u0928 \u092e\u0947\u0902 \u0932\u0917\u093e\u090f\u0901\u0964 GND \u0915\u094b \u092c\u094b\u0930\u094d\u0921 GND, SCL \u0915\u094b SCL \u0914\u0930 SDA \u0915\u094b SDA \u0938\u0947 \u091c\u094b\u0921\u093c\u0947\u0902\u0964 \u0915\u0947\u0935\u0932 \u092c\u094b\u0930\u094d\u0921 \u0915\u0947 \u0938\u0939\u0940 \u0932\u0949\u091c\u093f\u0915 \u0935\u094b\u0932\u094d\u091f\u0947\u091c \u0915\u093e \u0909\u092a\u092f\u094b\u0917 \u0915\u0930\u0947\u0902\u0964 \u092c\u094b\u0930\u094d\u0921 \u092a\u0939\u0932\u0947 \u0938\u0947 powered \u0939\u094b \u0924\u094b CH341A \u0915\u093e VCC \u0928 \u091c\u094b\u0921\u093c\u0947\u0902\u0964 \u0905\u0921\u0948\u092a\u094d\u091f\u0930 \u0915\u094b \u0915\u092d\u0940 \u092d\u0940 \u092e\u0947\u0928\u094d\u0938 \u0935\u094b\u0932\u094d\u091f\u0947\u091c \u0938\u0947 \u0928 \u091c\u094b\u0921\u093c\u0947\u0902\u0964\n\n3. \u092c\u094b\u0930\u094d\u0921 \u092a\u0922\u093c\u0947\u0902\n\u091c\u0930\u0942\u0930\u0924 \u0939\u094b\u0928\u0947 \u092a\u0930 \u092c\u094b\u0930\u094d\u0921 \u0915\u094b \u0909\u0938\u0915\u0947 \u0938\u093e\u092e\u093e\u0928\u094d\u092f \u0914\u0930 \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0932\u094b-\u0935\u094b\u0932\u094d\u091f\u0947\u091c \u0938\u094d\u0930\u094b\u0924 \u0938\u0947 power \u0926\u0947\u0902\u0964 CONNECT \u0926\u092c\u093e\u0915\u0930 USB \u0905\u0928\u0941\u092e\u0924\u093f \u0926\u0947\u0902, \u0938\u0939\u0940 PMIC \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u091a\u0941\u0928\u0947\u0902 \u0914\u0930 READ BOARD \u0926\u092c\u093e\u090f\u0901\u0964 \u092a\u0922\u093c\u0928\u0947 \u092e\u0947\u0902 \u0935\u093f\u092b\u0932\u0924\u093e \u0939\u094b \u092f\u093e \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u092a\u0915\u094d\u0915\u0940 \u0928 \u0939\u094b \u0924\u094b \u0906\u0917\u0947 \u0928 \u092c\u0922\u093c\u0947\u0902\u0964\n\n4. \u0938\u093e\u0935\u0927\u093e\u0928\u0940 \u0938\u0947 \u0938\u092e\u093e\u092f\u094b\u091c\u0928\n\u090f\u0915 \u092c\u093e\u0930 \u092e\u0947\u0902 \u0915\u0947\u0935\u0932 \u090f\u0915 step \u092c\u0926\u0932\u0947\u0902\u0964 VGH/VGL \u092c\u091f\u0928 \u0938\u0902\u092c\u0902\u0927\u093f\u0924 rail setting \u092c\u0926\u0932\u0924\u0947 \u0939\u0948\u0902\u0964 VGL2/VCOM \u092c\u091f\u0928 \u0938\u092e\u0930\u094d\u0925\u093f\u0924 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u0915\u0940 setting \u0915\u094b \u090f\u0915 step \u092c\u0926\u0932\u0924\u0947 \u0939\u0948\u0902\u0964 \u0938\u0939\u0940 multimeter \u0938\u0947 \u0935\u093e\u0938\u094d\u0924\u0935\u093f\u0915 output \u091c\u093e\u0901\u091a\u0947\u0902 \u0914\u0930 \u0939\u0930 \u092c\u0926\u0932\u093e\u0935 \u0915\u0947 \u092c\u093e\u0926 panel \u0915\u093e \u0938\u094d\u0925\u093f\u0930 \u0938\u0902\u091a\u093e\u0932\u0928 \u0926\u0947\u0916\u0947\u0902\u0964 \u0932\u0915\u094d\u0937\u094d\u092f \u092e\u093e\u0928 \u0915\u093e \u0905\u0928\u0941\u092e\u093e\u0928 \u0928 \u0932\u0917\u093e\u090f\u0901\u0964\n\n5. \u0938\u094d\u0925\u093e\u092f\u0940 \u0938\u0947\u0935 \u0914\u0930 \u091c\u093e\u0901\u091a\n\u0930\u0940\u0921\u093f\u0902\u0917 \u0938\u0939\u0940 \u0939\u094b\u0928\u0947 \u092a\u0930 WRITE BOARD \u0926\u092c\u093e\u0915\u0930 \u092a\u0941\u0937\u094d\u091f\u093f \u0915\u0930\u0947\u0902\u0964 auxiliary live adjustment \u0938\u0947 \u092a\u0939\u0932\u0947 \u0914\u0930 permanent save \u0938\u0947 \u092a\u0939\u0932\u0947 \u0910\u092a \u092a\u0942\u0930\u093e register backup \u092c\u0928\u093e\u0924\u093e \u0939\u0948\u0964 \u0938\u0947\u0935 \u0938\u094d\u0925\u093f\u0924\u093f \u091c\u093e\u0901\u091a\u0947\u0902, \u092c\u094b\u0930\u094d\u0921 \u0915\u094b power-cycle \u0915\u0930\u0947\u0902, \u092b\u093f\u0930 \u0926\u094b\u092c\u093e\u0930\u093e \u092a\u0922\u093c\u0915\u0930 multimeter \u0938\u0947 \u091c\u093e\u0901\u091a\u0947\u0902\u0964 recovery \u0915\u0947 \u0932\u093f\u090f backup \u0930\u0916\u0947\u0902\u0964\n\n6. \u0915\u092c \u0930\u094b\u0915\u0947\u0902\n\u0905\u091c\u094d\u091e\u093e\u0924 PMIC, \u0905\u0938\u094d\u0925\u093f\u0930 \u0930\u0940\u0921\u093f\u0902\u0917, \u0905\u0938\u093e\u092e\u093e\u0928\u094d\u092f \u0917\u0930\u094d\u092e\u0940, short \u092f\u093e \u0917\u0932\u0924 panel \u0935\u094d\u092f\u0935\u0939\u093e\u0930 \u092a\u0930 \u0924\u0941\u0930\u0902\u0924 \u0930\u0941\u0915\u0947\u0902\u0964 \u0915\u094d\u0932\u093f\u092a \u092c\u0926\u0932\u0928\u0947 \u0938\u0947 \u092a\u0939\u0932\u0947 power disconnect \u0915\u0930\u0947\u0902\u0964 \u092f\u0939 \u091f\u0942\u0932 \u0915\u0947\u0935\u0932 \u0905\u0927\u093f\u0915\u0943\u0924 repair \u0915\u093e\u092e \u092e\u0947\u0902 \u0909\u092a\u092f\u094b\u0917 \u0915\u0930\u0947\u0902\u0964"

    .line 243
    .line 244
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 245
    .line 246
    .line 247
    const v1, -0xdfdedc

    .line 248
    .line 249
    .line 250
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 251
    .line 252
    .line 253
    const/high16 v1, 0x41700000    # 15.0f

    .line 254
    .line 255
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 256
    .line 257
    .line 258
    const/high16 v1, 0x40a00000    # 5.0f

    .line 259
    .line 260
    const/high16 v2, 0x3f800000    # 1.0f

    .line 261
    .line 262
    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {p0}, Le/m;->getResources()Landroid/content/res/Resources;

    .line 266
    .line 267
    .line 268
    move-result-object v1

    .line 269
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 270
    .line 271
    .line 272
    move-result-object v1

    .line 273
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 274
    .line 275
    const/high16 v2, 0x41900000    # 18.0f

    .line 276
    .line 277
    mul-float/2addr v1, v2

    .line 278
    float-to-int v1, v1

    .line 279
    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {p1, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 283
    .line 284
    .line 285
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 286
    .line 287
    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 288
    .line 289
    .line 290
    const-string v1, "PMIC Safe-Use Guide | \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0909\u092a\u092f\u094b\u0917"

    .line 291
    .line 292
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 297
    .line 298
    .line 299
    move-result-object p1

    .line 300
    const-string v0, "Close"

    .line 301
    .line 302
    invoke-virtual {p1, v0, v7}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    new-instance v0, Lg1/n2;

    .line 307
    .line 308
    invoke-direct {v0, p0, v5}, Lg1/n2;-><init>(Lapp/gkc/terminal/Activity/PmicI2cActivity;I)V

    .line 309
    .line 310
    .line 311
    const-string v1, "Save PDF"

    .line 312
    .line 313
    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 314
    .line 315
    .line 316
    move-result-object p1

    .line 317
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 318
    .line 319
    .line 320
    goto/16 :goto_a

    .line 321
    .line 322
    :cond_6
    const v0, 0x7f09032f

    .line 323
    .line 324
    .line 325
    if-ne p1, v0, :cond_c

    .line 326
    .line 327
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    .line 328
    .line 329
    if-eqz p1, :cond_7

    .line 330
    .line 331
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->s()V

    .line 332
    .line 333
    .line 334
    goto/16 :goto_a

    .line 335
    .line 336
    :cond_7
    :try_start_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O:Landroid/hardware/usb/UsbManager;

    .line 337
    .line 338
    invoke-virtual {p1}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    .line 339
    .line 340
    .line 341
    move-result-object p1

    .line 342
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 343
    .line 344
    .line 345
    move-result-object p1

    .line 346
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 347
    .line 348
    .line 349
    move-result-object p1

    .line 350
    :cond_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 351
    .line 352
    .line 353
    move-result v0

    .line 354
    if-eqz v0, :cond_9

    .line 355
    .line 356
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 357
    .line 358
    .line 359
    move-result-object v0

    .line 360
    check-cast v0, Landroid/hardware/usb/UsbDevice;

    .line 361
    .line 362
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    .line 363
    .line 364
    .line 365
    move-result v1

    .line 366
    const/16 v2, 0x1a86

    .line 367
    .line 368
    if-ne v1, v2, :cond_8

    .line 369
    .line 370
    const-string p1, "CH341A adapter detected."

    .line 371
    .line 372
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    move-object v7, v0

    .line 376
    :cond_9
    if-nez v7, :cond_a

    .line 377
    .line 378
    const-string p1, "CH341A not found."

    .line 379
    .line 380
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 381
    .line 382
    .line 383
    const-string p1, "CH341A not found"

    .line 384
    .line 385
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 386
    .line 387
    .line 388
    move-result-object p1

    .line 389
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 390
    .line 391
    .line 392
    goto/16 :goto_a

    .line 393
    .line 394
    :cond_a
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O:Landroid/hardware/usb/UsbManager;

    .line 395
    .line 396
    invoke-virtual {p1, v7}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 397
    .line 398
    .line 399
    move-result p1

    .line 400
    if-nez p1, :cond_b

    .line 401
    .line 402
    const-string p1, "Requesting USB permission..."

    .line 403
    .line 404
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 405
    .line 406
    .line 407
    new-instance p1, Landroid/content/Intent;

    .line 408
    .line 409
    const-string v0, "app.gkc.terminal.pro.PMIC_I2C_USB_PERMISSION"

    .line 410
    .line 411
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 412
    .line 413
    .line 414
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 419
    .line 420
    .line 421
    const/high16 v0, 0xa000000

    .line 422
    .line 423
    invoke-static {p0, v4, p1, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 424
    .line 425
    .line 426
    move-result-object p1

    .line 427
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O:Landroid/hardware/usb/UsbManager;

    .line 428
    .line 429
    invoke-virtual {v0, v7, p1}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 430
    .line 431
    .line 432
    goto/16 :goto_a

    .line 433
    .line 434
    :cond_b
    invoke-virtual {p0, v7}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->w(Landroid/hardware/usb/UsbDevice;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 435
    .line 436
    .line 437
    goto/16 :goto_a

    .line 438
    .line 439
    :catch_0
    const-string p1, "Could not connect to CH341A. Check the OTG connection and try again."

    .line 440
    .line 441
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 442
    .line 443
    .line 444
    goto/16 :goto_a

    .line 445
    .line 446
    :cond_c
    const v0, 0x7f09034e

    .line 447
    .line 448
    .line 449
    if-ne p1, v0, :cond_f

    .line 450
    .line 451
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    .line 452
    .line 453
    if-eqz p1, :cond_e

    .line 454
    .line 455
    invoke-virtual {v3}, Lg1/n;->j()Z

    .line 456
    .line 457
    .line 458
    move-result p1

    .line 459
    if-nez p1, :cond_d

    .line 460
    .line 461
    goto :goto_2

    .line 462
    :cond_d
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->A()V

    .line 463
    .line 464
    .line 465
    goto/16 :goto_a

    .line 466
    .line 467
    :cond_e
    :goto_2
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    invoke-static {p0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 471
    .line 472
    .line 473
    move-result-object p1

    .line 474
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 475
    .line 476
    .line 477
    goto/16 :goto_a

    .line 478
    .line 479
    :cond_f
    const v0, 0x7f090465

    .line 480
    .line 481
    .line 482
    const-string v8, ""

    .line 483
    .line 484
    if-ne p1, v0, :cond_1e

    .line 485
    .line 486
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    .line 487
    .line 488
    if-eqz p1, :cond_1d

    .line 489
    .line 490
    invoke-virtual {v3}, Lg1/n;->j()Z

    .line 491
    .line 492
    .line 493
    move-result p1

    .line 494
    if-nez p1, :cond_10

    .line 495
    .line 496
    goto/16 :goto_9

    .line 497
    .line 498
    :cond_10
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 499
    .line 500
    if-nez p1, :cond_11

    .line 501
    .line 502
    const-string p1, "Read board first. PMIC not synced."

    .line 503
    .line 504
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 505
    .line 506
    .line 507
    const-string p1, "Read board first"

    .line 508
    .line 509
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 510
    .line 511
    .line 512
    move-result-object p1

    .line 513
    :goto_3
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 514
    .line 515
    .line 516
    goto/16 :goto_a

    .line 517
    .line 518
    :cond_11
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 519
    .line 520
    invoke-static {p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J(Lg1/p2;)Z

    .line 521
    .line 522
    .line 523
    move-result p1

    .line 524
    if-nez p1, :cond_12

    .line 525
    .line 526
    const-string p1, "Writing is unavailable for the selected profile."

    .line 527
    .line 528
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 529
    .line 530
    .line 531
    const-string p1, "Profile is read-only"

    .line 532
    .line 533
    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    goto :goto_3

    .line 538
    :cond_12
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 539
    .line 540
    iget-object v0, p1, Lg1/p2;->h:Lg1/q2;

    .line 541
    .line 542
    if-eqz v0, :cond_19

    .line 543
    .line 544
    iget-boolean p1, v0, Lg1/q2;->m:Z

    .line 545
    .line 546
    const-string v1, "PMIC code is outside the verified table."

    .line 547
    .line 548
    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    .line 549
    .line 550
    if-eqz p1, :cond_13

    .line 551
    .line 552
    const-string p1, "VGH setting ready"

    .line 553
    .line 554
    goto :goto_4

    .line 555
    :cond_13
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 556
    .line 557
    iget v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 558
    .line 559
    iget v6, v0, Lg1/q2;->j:I

    .line 560
    .line 561
    sub-int/2addr v4, v6

    .line 562
    iget-object v6, v0, Lg1/q2;->n:[I

    .line 563
    .line 564
    invoke-static {v6, v4}, Lg1/q2;->b([II)Z

    .line 565
    .line 566
    .line 567
    move-result v9

    .line 568
    if-eqz v9, :cond_18

    .line 569
    .line 570
    aget v4, v6, v4

    .line 571
    .line 572
    int-to-double v9, v4

    .line 573
    div-double/2addr v9, v2

    .line 574
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 575
    .line 576
    .line 577
    move-result-object v4

    .line 578
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v4

    .line 582
    const-string v6, "VGH %.1f V"

    .line 583
    .line 584
    invoke-static {p1, v6, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object p1

    .line 588
    :goto_4
    new-instance v4, Ljava/lang/StringBuilder;

    .line 589
    .line 590
    const-string v6, "Save "

    .line 591
    .line 592
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 593
    .line 594
    .line 595
    iget-object v6, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 596
    .line 597
    iget-object v6, v6, Lg1/p2;->a:Ljava/lang/String;

    .line 598
    .line 599
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 600
    .line 601
    .line 602
    const-string v6, " permanently?\n"

    .line 603
    .line 604
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 605
    .line 606
    .line 607
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 608
    .line 609
    .line 610
    const-string p1, "\nVGL "

    .line 611
    .line 612
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 613
    .line 614
    .line 615
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 616
    .line 617
    iget v6, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 618
    .line 619
    iget-object v9, v0, Lg1/q2;->o:[I

    .line 620
    .line 621
    invoke-static {v9, v6}, Lg1/q2;->b([II)Z

    .line 622
    .line 623
    .line 624
    move-result v10

    .line 625
    if-eqz v10, :cond_17

    .line 626
    .line 627
    aget v6, v9, v6

    .line 628
    .line 629
    int-to-double v9, v6

    .line 630
    div-double/2addr v9, v2

    .line 631
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 632
    .line 633
    .line 634
    move-result-object v6

    .line 635
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 636
    .line 637
    .line 638
    move-result-object v6

    .line 639
    const-string v9, "%.1f V"

    .line 640
    .line 641
    invoke-static {p1, v9, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 642
    .line 643
    .line 644
    move-result-object v6

    .line 645
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 646
    .line 647
    .line 648
    iget v6, v0, Lg1/q2;->h:I

    .line 649
    .line 650
    if-ltz v6, :cond_15

    .line 651
    .line 652
    iget v6, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 653
    .line 654
    invoke-virtual {v0, v6}, Lg1/q2;->e(I)Z

    .line 655
    .line 656
    .line 657
    move-result v6

    .line 658
    if-eqz v6, :cond_15

    .line 659
    .line 660
    new-instance v6, Ljava/lang/StringBuilder;

    .line 661
    .line 662
    const-string v10, "\nVGL2 "

    .line 663
    .line 664
    invoke-direct {v6, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 665
    .line 666
    .line 667
    iget v10, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 668
    .line 669
    sub-int/2addr v10, v5

    .line 670
    iget-object v5, v0, Lg1/q2;->p:[I

    .line 671
    .line 672
    invoke-static {v5, v10}, Lg1/q2;->b([II)Z

    .line 673
    .line 674
    .line 675
    move-result v11

    .line 676
    if-eqz v11, :cond_14

    .line 677
    .line 678
    aget v1, v5, v10

    .line 679
    .line 680
    int-to-double v10, v1

    .line 681
    div-double/2addr v10, v2

    .line 682
    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 687
    .line 688
    .line 689
    move-result-object v1

    .line 690
    invoke-static {p1, v9, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 691
    .line 692
    .line 693
    move-result-object p1

    .line 694
    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 695
    .line 696
    .line 697
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 698
    .line 699
    .line 700
    move-result-object p1

    .line 701
    goto :goto_5

    .line 702
    :cond_14
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 703
    .line 704
    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 705
    .line 706
    .line 707
    throw p1

    .line 708
    :cond_15
    move-object p1, v8

    .line 709
    :goto_5
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 710
    .line 711
    .line 712
    iget p1, v0, Lg1/q2;->i:I

    .line 713
    .line 714
    if-ltz p1, :cond_16

    .line 715
    .line 716
    iget p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 717
    .line 718
    invoke-virtual {v0, p1}, Lg1/q2;->d(I)Z

    .line 719
    .line 720
    .line 721
    move-result p1

    .line 722
    if-eqz p1, :cond_16

    .line 723
    .line 724
    const-string v8, "\nVCOM setting ready"

    .line 725
    .line 726
    :cond_16
    const-string p1, "\nA full register backup will be saved before writing. Confirm the exact IC and board."

    .line 727
    .line 728
    invoke-static {v4, v8, p1}, Landroidx/fragment/app/e1;->g(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 729
    .line 730
    .line 731
    move-result-object p1

    .line 732
    new-instance v1, Landroid/app/AlertDialog$Builder;

    .line 733
    .line 734
    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 735
    .line 736
    .line 737
    const-string v2, "Write PMIC"

    .line 738
    .line 739
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 740
    .line 741
    .line 742
    move-result-object v1

    .line 743
    invoke-virtual {v1, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 744
    .line 745
    .line 746
    move-result-object p1

    .line 747
    const-string v1, "Cancel"

    .line 748
    .line 749
    invoke-virtual {p1, v1, v7}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 750
    .line 751
    .line 752
    move-result-object p1

    .line 753
    new-instance v1, Lg1/z1;

    .line 754
    .line 755
    const/4 v2, 0x2

    .line 756
    invoke-direct {v1, p0, v0, v2}, Lg1/z1;-><init>(Le/m;Ljava/lang/Object;I)V

    .line 757
    .line 758
    .line 759
    const-string v0, "Back up and write"

    .line 760
    .line 761
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 762
    .line 763
    .line 764
    move-result-object p1

    .line 765
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 766
    .line 767
    .line 768
    goto/16 :goto_a

    .line 769
    .line 770
    :cond_17
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 771
    .line 772
    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 773
    .line 774
    .line 775
    throw p1

    .line 776
    :cond_18
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 777
    .line 778
    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 779
    .line 780
    .line 781
    throw p1

    .line 782
    :cond_19
    :try_start_1
    iget-object p1, p1, Lg1/p2;->c:Ljava/lang/String;

    .line 783
    .line 784
    invoke-static {p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 785
    .line 786
    .line 787
    move-result p1

    .line 788
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 789
    .line 790
    iget-object v0, v0, Lg1/p2;->d:Ljava/lang/String;

    .line 791
    .line 792
    invoke-static {v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 793
    .line 794
    .line 795
    move-result v0

    .line 796
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 797
    .line 798
    iget-object v1, v1, Lg1/p2;->e:Ljava/lang/String;

    .line 799
    .line 800
    invoke-static {v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 801
    .line 802
    .line 803
    move-result v1

    .line 804
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 805
    .line 806
    invoke-static {v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->L(Lg1/p2;)Z

    .line 807
    .line 808
    .line 809
    move-result v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 810
    const-string v6, "Permanent VGH/VGL saved"

    .line 811
    .line 812
    const-string v7, "Permanent save completed."

    .line 813
    .line 814
    const/16 v8, 0xff

    .line 815
    .line 816
    if-eqz v2, :cond_1a

    .line 817
    .line 818
    const/16 v2, 0xd

    .line 819
    .line 820
    :try_start_2
    invoke-virtual {v3, p1, v4, v2}, Lg1/n;->x(III)[B

    .line 821
    .line 822
    .line 823
    move-result-object v2

    .line 824
    iget v9, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 825
    .line 826
    and-int/2addr v9, v8

    .line 827
    int-to-byte v9, v9

    .line 828
    aput-byte v9, v2, v0

    .line 829
    .line 830
    iget v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 831
    .line 832
    and-int/2addr v0, v8

    .line 833
    int-to-byte v0, v0

    .line 834
    aput-byte v0, v2, v1

    .line 835
    .line 836
    const-string v0, "Saving current PMIC values..."

    .line 837
    .line 838
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 839
    .line 840
    .line 841
    invoke-virtual {v3, p1, v4, v2}, Lg1/n;->R(II[B)V

    .line 842
    .line 843
    .line 844
    const/16 v0, 0x80

    .line 845
    .line 846
    invoke-virtual {v3, p1, v8, v0}, Lg1/n;->Q(III)V

    .line 847
    .line 848
    .line 849
    const-wide/16 v0, 0x50

    .line 850
    .line 851
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    .line 852
    .line 853
    .line 854
    invoke-virtual {p0, v7}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 855
    .line 856
    .line 857
    :goto_6
    invoke-static {p0, v6, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 858
    .line 859
    .line 860
    move-result-object p1

    .line 861
    :goto_7
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 862
    .line 863
    .line 864
    goto/16 :goto_a

    .line 865
    .line 866
    :cond_1a
    const-string v2, "RT43"

    .line 867
    .line 868
    iget-object v9, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 869
    .line 870
    iget-object v9, v9, Lg1/p2;->b:Ljava/lang/String;

    .line 871
    .line 872
    invoke-virtual {v2, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 873
    .line 874
    .line 875
    move-result v2

    .line 876
    if-eqz v2, :cond_1c

    .line 877
    .line 878
    const/16 v2, 0x70

    .line 879
    .line 880
    invoke-virtual {v3, p1, v4, v2}, Lg1/n;->x(III)[B

    .line 881
    .line 882
    .line 883
    move-result-object v2

    .line 884
    if-ltz v0, :cond_1b

    .line 885
    .line 886
    array-length v9, v2

    .line 887
    if-ge v0, v9, :cond_1b

    .line 888
    .line 889
    if-ltz v1, :cond_1b

    .line 890
    .line 891
    array-length v9, v2

    .line 892
    if-ge v1, v9, :cond_1b

    .line 893
    .line 894
    iget v9, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 895
    .line 896
    and-int/2addr v9, v8

    .line 897
    int-to-byte v9, v9

    .line 898
    aput-byte v9, v2, v0

    .line 899
    .line 900
    iget v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 901
    .line 902
    and-int/2addr v0, v8

    .line 903
    int-to-byte v0, v0

    .line 904
    aput-byte v0, v2, v1

    .line 905
    .line 906
    const-string v0, "Saving RT43 current values..."

    .line 907
    .line 908
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 909
    .line 910
    .line 911
    invoke-virtual {v3, p1, v8, v5}, Lg1/n;->Q(III)V

    .line 912
    .line 913
    .line 914
    invoke-virtual {v3, p1, v4, v2}, Lg1/n;->R(II[B)V

    .line 915
    .line 916
    .line 917
    const/16 v0, 0x8

    .line 918
    .line 919
    invoke-virtual {v3, p1, v4, v0}, Lg1/n;->Q(III)V

    .line 920
    .line 921
    .line 922
    invoke-virtual {p0, v7}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 923
    .line 924
    .line 925
    goto :goto_6

    .line 926
    :cond_1b
    new-instance p1, Ljava/lang/Exception;

    .line 927
    .line 928
    const-string v0, "RT43 VGH/VGL register outside block"

    .line 929
    .line 930
    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 931
    .line 932
    .line 933
    throw p1

    .line 934
    :cond_1c
    const-string p1, "Permanent save not enabled for this profile."

    .line 935
    .line 936
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 937
    .line 938
    .line 939
    const-string p1, "Permanent save not enabled for this PMIC"

    .line 940
    .line 941
    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 942
    .line 943
    .line 944
    move-result-object p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 945
    goto :goto_7

    .line 946
    :catch_1
    const-string p1, "Permanent save failed. Check the connection and selected profile."

    .line 947
    .line 948
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 949
    .line 950
    .line 951
    const-string p1, "Permanent save failed"

    .line 952
    .line 953
    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 954
    .line 955
    .line 956
    move-result-object p1

    .line 957
    :goto_8
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 958
    .line 959
    .line 960
    goto :goto_a

    .line 961
    :cond_1d
    :goto_9
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 962
    .line 963
    .line 964
    invoke-static {p0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 965
    .line 966
    .line 967
    move-result-object p1

    .line 968
    goto :goto_8

    .line 969
    :cond_1e
    const v0, 0x7f090441

    .line 970
    .line 971
    .line 972
    if-ne p1, v0, :cond_1f

    .line 973
    .line 974
    invoke-virtual {p0, v5, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->q(IZ)V

    .line 975
    .line 976
    .line 977
    goto :goto_a

    .line 978
    :cond_1f
    const v0, 0x7f09043f

    .line 979
    .line 980
    .line 981
    if-ne p1, v0, :cond_20

    .line 982
    .line 983
    invoke-virtual {p0, v6, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->q(IZ)V

    .line 984
    .line 985
    .line 986
    goto :goto_a

    .line 987
    :cond_20
    const v0, 0x7f090449

    .line 988
    .line 989
    .line 990
    if-ne p1, v0, :cond_21

    .line 991
    .line 992
    invoke-virtual {p0, v5, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->q(IZ)V

    .line 993
    .line 994
    .line 995
    goto :goto_a

    .line 996
    :cond_21
    const v0, 0x7f090447

    .line 997
    .line 998
    .line 999
    if-ne p1, v0, :cond_22

    .line 1000
    .line 1001
    invoke-virtual {p0, v6, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->q(IZ)V

    .line 1002
    .line 1003
    .line 1004
    goto :goto_a

    .line 1005
    :cond_22
    const v0, 0x7f090445

    .line 1006
    .line 1007
    .line 1008
    if-ne p1, v0, :cond_23

    .line 1009
    .line 1010
    invoke-virtual {p0, v5, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->p(IZ)V

    .line 1011
    .line 1012
    .line 1013
    goto :goto_a

    .line 1014
    :cond_23
    const v0, 0x7f090444

    .line 1015
    .line 1016
    .line 1017
    if-ne p1, v0, :cond_24

    .line 1018
    .line 1019
    invoke-virtual {p0, v6, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->p(IZ)V

    .line 1020
    .line 1021
    .line 1022
    goto :goto_a

    .line 1023
    :cond_24
    const v0, 0x7f09043a

    .line 1024
    .line 1025
    .line 1026
    if-ne p1, v0, :cond_25

    .line 1027
    .line 1028
    invoke-virtual {p0, v5, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->p(IZ)V

    .line 1029
    .line 1030
    .line 1031
    goto :goto_a

    .line 1032
    :cond_25
    const v0, 0x7f090439

    .line 1033
    .line 1034
    .line 1035
    if-ne p1, v0, :cond_26

    .line 1036
    .line 1037
    invoke-virtual {p0, v6, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->p(IZ)V

    .line 1038
    .line 1039
    .line 1040
    goto :goto_a

    .line 1041
    :cond_26
    const v0, 0x7f090141

    .line 1042
    .line 1043
    .line 1044
    if-ne p1, v0, :cond_27

    .line 1045
    .line 1046
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E:Landroid/widget/TextView;

    .line 1047
    .line 1048
    invoke-virtual {p1, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1049
    .line 1050
    .line 1051
    const-string p1, "Log cleared."

    .line 1052
    .line 1053
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 1054
    .line 1055
    .line 1056
    :cond_27
    :goto_a
    return-void
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    const p1, 0x7f0c002f

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    .line 8
    .line 9
    .line 10
    const-string p1, "usb"

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Landroid/hardware/usb/UsbManager;

    .line 17
    .line 18
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O:Landroid/hardware/usb/UsbManager;

    .line 19
    .line 20
    sget-object p1, Lg1/r2;->b:Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    new-array v0, v0, [Lg1/p2;

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    move v2, v1

    .line 34
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    if-ge v2, v3, :cond_0

    .line 39
    .line 40
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    check-cast v3, Lg1/q2;

    .line 45
    .line 46
    new-instance v4, Lg1/p2;

    .line 47
    .line 48
    iget-object v5, v3, Lg1/q2;->a:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v3, v3, Lg1/q2;->b:Ljava/lang/String;

    .line 51
    .line 52
    invoke-direct {v4, v5, v3}, Lg1/p2;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    aput-object v4, v0, v2

    .line 56
    .line 57
    add-int/lit8 v2, v2, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Y:[Lg1/p2;

    .line 61
    .line 62
    const p1, 0x7f0903a3

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    check-cast p1, Landroid/widget/TextView;

    .line 70
    .line 71
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->B:Landroid/widget/TextView;

    .line 72
    .line 73
    const p1, 0x7f090330

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    check-cast p1, Landroid/widget/TextView;

    .line 81
    .line 82
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->C:Landroid/widget/TextView;

    .line 83
    .line 84
    const p1, 0x7f090334

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    check-cast p1, Landroid/widget/TextView;

    .line 92
    .line 93
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D:Landroid/widget/TextView;

    .line 94
    .line 95
    const p1, 0x7f090332

    .line 96
    .line 97
    .line 98
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    check-cast p1, Landroid/widget/TextView;

    .line 103
    .line 104
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E:Landroid/widget/TextView;

    .line 105
    .line 106
    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    .line 111
    .line 112
    .line 113
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E:Landroid/widget/TextView;

    .line 114
    .line 115
    const/4 v0, 0x1

    .line 116
    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    .line 117
    .line 118
    .line 119
    const p1, 0x7f090331

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    check-cast p1, Landroid/widget/ScrollView;

    .line 127
    .line 128
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->F:Landroid/widget/ScrollView;

    .line 129
    .line 130
    const p1, 0x7f09032f

    .line 131
    .line 132
    .line 133
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    check-cast v0, Landroid/widget/Button;

    .line 138
    .line 139
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->G:Landroid/widget/Button;

    .line 140
    .line 141
    const v0, 0x7f090443

    .line 142
    .line 143
    .line 144
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Landroid/widget/LinearLayout;

    .line 149
    .line 150
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->H:Landroid/widget/LinearLayout;

    .line 151
    .line 152
    const v0, 0x7f090438

    .line 153
    .line 154
    .line 155
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    check-cast v0, Landroid/widget/LinearLayout;

    .line 160
    .line 161
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->I:Landroid/widget/LinearLayout;

    .line 162
    .line 163
    const v0, 0x7f090444

    .line 164
    .line 165
    .line 166
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    check-cast v0, Landroid/widget/Button;

    .line 171
    .line 172
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J:Landroid/widget/Button;

    .line 173
    .line 174
    const v0, 0x7f090445

    .line 175
    .line 176
    .line 177
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    check-cast v0, Landroid/widget/Button;

    .line 182
    .line 183
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K:Landroid/widget/Button;

    .line 184
    .line 185
    const v0, 0x7f090439

    .line 186
    .line 187
    .line 188
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    check-cast v0, Landroid/widget/Button;

    .line 193
    .line 194
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->L:Landroid/widget/Button;

    .line 195
    .line 196
    const v0, 0x7f09043a

    .line 197
    .line 198
    .line 199
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    check-cast v0, Landroid/widget/Button;

    .line 204
    .line 205
    iput-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->M:Landroid/widget/Button;

    .line 206
    .line 207
    const v0, 0x7f09013c

    .line 208
    .line 209
    .line 210
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 215
    .line 216
    .line 217
    const v0, 0x7f090107

    .line 218
    .line 219
    .line 220
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 225
    .line 226
    .line 227
    const v0, 0x7f090333

    .line 228
    .line 229
    .line 230
    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    .line 236
    .line 237
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 238
    .line 239
    .line 240
    move-result-object p1

    .line 241
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 242
    .line 243
    .line 244
    const p1, 0x7f09034e

    .line 245
    .line 246
    .line 247
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 252
    .line 253
    .line 254
    const p1, 0x7f090465

    .line 255
    .line 256
    .line 257
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 258
    .line 259
    .line 260
    move-result-object p1

    .line 261
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 262
    .line 263
    .line 264
    const p1, 0x7f09043f

    .line 265
    .line 266
    .line 267
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 272
    .line 273
    .line 274
    const p1, 0x7f090441

    .line 275
    .line 276
    .line 277
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 278
    .line 279
    .line 280
    move-result-object p1

    .line 281
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 282
    .line 283
    .line 284
    const p1, 0x7f090447

    .line 285
    .line 286
    .line 287
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 288
    .line 289
    .line 290
    move-result-object p1

    .line 291
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 292
    .line 293
    .line 294
    const p1, 0x7f090449

    .line 295
    .line 296
    .line 297
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 298
    .line 299
    .line 300
    move-result-object p1

    .line 301
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 302
    .line 303
    .line 304
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J:Landroid/widget/Button;

    .line 305
    .line 306
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 307
    .line 308
    .line 309
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K:Landroid/widget/Button;

    .line 310
    .line 311
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 312
    .line 313
    .line 314
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->L:Landroid/widget/Button;

    .line 315
    .line 316
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 317
    .line 318
    .line 319
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->M:Landroid/widget/Button;

    .line 320
    .line 321
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 322
    .line 323
    .line 324
    const p1, 0x7f090141

    .line 325
    .line 326
    .line 327
    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    .line 328
    .line 329
    .line 330
    move-result-object p1

    .line 331
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 332
    .line 333
    .line 334
    new-instance p1, Landroid/content/IntentFilter;

    .line 335
    .line 336
    const-string v0, "app.gkc.terminal.pro.PMIC_I2C_USB_PERMISSION"

    .line 337
    .line 338
    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->X:Le/d0;

    .line 342
    .line 343
    invoke-static {p0, v0, p1}, Le2/m;->e1(Landroid/content/Context;Le/d0;Landroid/content/IntentFilter;)V

    .line 344
    .line 345
    .line 346
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Y:[Lg1/p2;

    .line 347
    .line 348
    aget-object p1, p1, v1

    .line 349
    .line 350
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 351
    .line 352
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->F()V

    .line 353
    .line 354
    .line 355
    const-string p1, "System ready. Select PMIC, connect CH341A, then adjust."

    .line 356
    .line 357
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 358
    .line 359
    .line 360
    return-void
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onDestroy()V
    .locals 1

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->s()V

    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->X:Le/d0;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(IZ)V
    .locals 11

    .line 1
    const-string v0, " setting adjusted. A pre-adjustment backup was saved on this device."

    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    iget-object v1, v1, Lg1/p2;->h:Lg1/q2;

    :goto_0
    iget-boolean v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_10

    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    invoke-virtual {v2}, Lg1/n;->j()Z

    move-result v4

    if-eqz v4, :cond_10

    iget-boolean v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    if-eqz v4, :cond_10

    if-nez v1, :cond_1

    goto/16 :goto_9

    :cond_1
    if-eqz p2, :cond_2

    iget v4, v1, Lg1/q2;->h:I

    goto :goto_1

    :cond_2
    iget v4, v1, Lg1/q2;->i:I

    :goto_1
    if-eqz p2, :cond_3

    iget v5, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    goto :goto_2

    :cond_3
    iget v5, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    :goto_2
    if-eqz p2, :cond_4

    invoke-virtual {v1, v5}, Lg1/q2;->e(I)Z

    move-result v6

    goto :goto_3

    :cond_4
    invoke-virtual {v1, v5}, Lg1/q2;->d(I)Z

    move-result v6

    :goto_3
    const-string v7, "VCOM"

    const-string v8, "VGL2"

    if-ltz v4, :cond_e

    if-nez v6, :cond_5

    goto/16 :goto_8

    :cond_5
    add-int/2addr v5, p1

    if-eqz p2, :cond_6

    invoke-virtual {v1, v5}, Lg1/q2;->e(I)Z

    move-result p1

    goto :goto_4

    :cond_6
    invoke-virtual {v1, v5}, Lg1/q2;->d(I)Z

    move-result p1

    :goto_4
    if-nez p1, :cond_8

    if-eqz p2, :cond_7

    move-object v7, v8

    :cond_7
    const-string p1, " table limit reached."

    invoke-virtual {v7, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    const-string p1, "Profile table limit reached"

    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_8
    :try_start_0
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->B(Lg1/q2;)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->G([B)V

    iget-object p1, v1, Lg1/q2;->k:Ljava/lang/Integer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    iget v6, v1, Lg1/q2;->c:I

    if-eqz p1, :cond_9

    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/16 v9, 0xff

    invoke-virtual {v2, v6, v9, p1}, Lg1/n;->Q(III)V

    iget p1, v1, Lg1/q2;->e:I

    int-to-long v9, p1

    invoke-static {v9, v10}, Ljava/lang/Thread;->sleep(J)V

    :cond_9
    invoke-virtual {v2, v6, v4, v5}, Lg1/n;->Q(III)V

    invoke-virtual {p0, v1, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D(Lg1/q2;I)I

    move-result p1

    if-ne p1, v5, :cond_c

    if-eqz p2, :cond_a

    iput p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    goto :goto_5

    :cond_a
    iput p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    :goto_5
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    if-eqz p2, :cond_b

    move-object p1, v8

    goto :goto_6

    :cond_b
    move-object p1, v7

    :goto_6
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    goto :goto_7

    :cond_c
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Auxiliary register read-back did not match."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    iput-boolean v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    if-eqz p2, :cond_d

    move-object v7, v8

    :cond_d
    const-string p1, " adjustment failed. The pre-adjustment backup was kept."

    invoke-virtual {v7, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    const-string p1, "Auxiliary write failed; keep the backup"

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_7
    return-void

    :cond_e
    :goto_8
    if-eqz p2, :cond_f

    move-object v7, v8

    :cond_f
    const-string p1, " adjustment is unavailable for this profile setting."

    invoke-virtual {v7, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    return-void

    :cond_10
    :goto_9
    const-string p1, "Connect and read a supported PMIC profile first."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    const-string p1, "Read a supported profile first"

    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public final q(IZ)V
    .locals 12

    .line 1
    const-string v0, " adjusted."

    .line 2
    .line 3
    const-string v1, " limit reached."

    .line 4
    .line 5
    iget-boolean v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v2, :cond_13

    .line 9
    .line 10
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    .line 11
    .line 12
    invoke-virtual {v2}, Lg1/n;->j()Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    if-nez v4, :cond_0

    .line 17
    .line 18
    goto/16 :goto_d

    .line 19
    .line 20
    :cond_0
    iget-boolean v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 21
    .line 22
    if-nez v4, :cond_1

    .line 23
    .line 24
    const-string p1, "Read board first. PMIC not synced."

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    const-string p1, "Read board first"

    .line 30
    .line 31
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    iget-object v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 40
    .line 41
    invoke-static {v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->J(Lg1/p2;)Z

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    const/4 v5, 0x1

    .line 46
    if-nez v4, :cond_2

    .line 47
    .line 48
    const-string p1, "Adjustment is unavailable for the selected profile."

    .line 49
    .line 50
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const-string p1, "Profile is read-only"

    .line 54
    .line 55
    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_2
    const-string v4, "VGL"

    .line 64
    .line 65
    const-string v6, "VGH"

    .line 66
    .line 67
    :try_start_0
    iget-object v7, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 68
    .line 69
    iget-object v7, v7, Lg1/p2;->c:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static {v7}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v7

    .line 75
    if-eqz p2, :cond_3

    .line 76
    .line 77
    iget-object v8, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 78
    .line 79
    iget-object v8, v8, Lg1/p2;->d:Ljava/lang/String;

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :catch_0
    move-exception p1

    .line 83
    goto/16 :goto_b

    .line 84
    .line 85
    :cond_3
    iget-object v8, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 86
    .line 87
    iget-object v8, v8, Lg1/p2;->e:Ljava/lang/String;

    .line 88
    .line 89
    :goto_0
    invoke-static {v8}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v8

    .line 93
    if-eqz p2, :cond_4

    .line 94
    .line 95
    iget v9, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 96
    .line 97
    goto :goto_1

    .line 98
    :cond_4
    iget v9, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 99
    .line 100
    :goto_1
    iget-object v10, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 101
    .line 102
    iget-object v11, v10, Lg1/p2;->h:Lg1/q2;

    .line 103
    .line 104
    if-eqz v11, :cond_5

    .line 105
    .line 106
    if-nez p2, :cond_5

    .line 107
    .line 108
    :goto_2
    neg-int p1, p1

    .line 109
    goto :goto_3

    .line 110
    :cond_5
    const-string v11, "SM4053"

    .line 111
    .line 112
    iget-object v10, v10, Lg1/p2;->b:Ljava/lang/String;

    .line 113
    .line 114
    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v10

    .line 118
    if-eqz v10, :cond_6

    .line 119
    .line 120
    if-nez p2, :cond_6

    .line 121
    .line 122
    goto :goto_2

    .line 123
    :cond_6
    :goto_3
    add-int/2addr v9, p1

    .line 124
    const/16 p1, 0xff

    .line 125
    .line 126
    invoke-static {p1, v9}, Ljava/lang/Math;->min(II)I

    .line 127
    .line 128
    .line 129
    move-result v9

    .line 130
    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    .line 131
    .line 132
    .line 133
    move-result v9

    .line 134
    iget-object v10, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 135
    .line 136
    invoke-static {v10, p2, v9}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->u(Lg1/p2;ZI)Z

    .line 137
    .line 138
    .line 139
    move-result v10

    .line 140
    if-nez v10, :cond_8

    .line 141
    .line 142
    if-eqz p2, :cond_7

    .line 143
    .line 144
    move-object p1, v6

    .line 145
    goto :goto_4

    .line 146
    :cond_7
    move-object p1, v4

    .line 147
    :goto_4
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    const-string p1, "Voltage limit reached"

    .line 155
    .line 156
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 161
    .line 162
    .line 163
    goto/16 :goto_c

    .line 164
    .line 165
    :cond_8
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 166
    .line 167
    iget-object v10, v1, Lg1/p2;->h:Lg1/q2;

    .line 168
    .line 169
    if-eqz v10, :cond_c

    .line 170
    .line 171
    invoke-virtual {p0, v10, v8, v9}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O(Lg1/q2;II)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p0, v10, v8, v9}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->C(Lg1/q2;II)I

    .line 175
    .line 176
    .line 177
    move-result p1

    .line 178
    if-eqz p2, :cond_9

    .line 179
    .line 180
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 181
    .line 182
    iget-object v1, v1, Lg1/p2;->e:Ljava/lang/String;

    .line 183
    .line 184
    goto :goto_5

    .line 185
    :cond_9
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 186
    .line 187
    iget-object v1, v1, Lg1/p2;->d:Ljava/lang/String;

    .line 188
    .line 189
    :goto_5
    invoke-static {v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    invoke-virtual {p0, v10, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D(Lg1/q2;I)I

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    if-eqz p2, :cond_a

    .line 198
    .line 199
    move v2, p1

    .line 200
    goto :goto_6

    .line 201
    :cond_a
    move v2, v1

    .line 202
    :goto_6
    iput v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 203
    .line 204
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 205
    .line 206
    if-eqz p2, :cond_b

    .line 207
    .line 208
    move p1, v1

    .line 209
    :cond_b
    invoke-static {v2, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->v(Lg1/p2;I)I

    .line 210
    .line 211
    .line 212
    move-result p1

    .line 213
    iput p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 214
    .line 215
    goto :goto_9

    .line 216
    :cond_c
    const-string v10, "RT6950"

    .line 217
    .line 218
    iget-object v1, v1, Lg1/p2;->b:Ljava/lang/String;

    .line 219
    .line 220
    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 221
    .line 222
    .line 223
    move-result v1

    .line 224
    if-eqz v1, :cond_e

    .line 225
    .line 226
    const/16 v1, 0x13

    .line 227
    .line 228
    invoke-virtual {v2, v7, v3, v1}, Lg1/n;->x(III)[B

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    if-ltz v8, :cond_d

    .line 233
    .line 234
    array-length v10, v1

    .line 235
    if-ge v8, v10, :cond_d

    .line 236
    .line 237
    and-int/lit16 v10, v9, 0xff

    .line 238
    .line 239
    int-to-byte v10, v10

    .line 240
    aput-byte v10, v1, v8

    .line 241
    .line 242
    invoke-virtual {v2, v7, p1, v3}, Lg1/n;->Q(III)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v2, v7, v3, v1}, Lg1/n;->R(II[B)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v2, v7, p1, v3}, Lg1/n;->Q(III)V

    .line 249
    .line 250
    .line 251
    const/16 v1, 0x80

    .line 252
    .line 253
    invoke-virtual {v2, v7, p1, v1}, Lg1/n;->Q(III)V

    .line 254
    .line 255
    .line 256
    goto :goto_7

    .line 257
    :cond_d
    new-instance p1, Ljava/lang/Exception;

    .line 258
    .line 259
    const-string v0, "RT6950 VGH/VGL register outside block"

    .line 260
    .line 261
    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    throw p1

    .line 265
    :cond_e
    invoke-virtual {v2, v7, v8, v9}, Lg1/n;->Q(III)V

    .line 266
    .line 267
    .line 268
    :goto_7
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 269
    .line 270
    iget-object p1, p1, Lg1/p2;->d:Ljava/lang/String;

    .line 271
    .line 272
    invoke-static {p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 273
    .line 274
    .line 275
    move-result p1

    .line 276
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 277
    .line 278
    iget-object v1, v1, Lg1/p2;->e:Ljava/lang/String;

    .line 279
    .line 280
    invoke-static {v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    invoke-virtual {p0, v7, p1, v1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E(III)[I

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    if-eqz p2, :cond_f

    .line 289
    .line 290
    aget v1, p1, v3

    .line 291
    .line 292
    goto :goto_8

    .line 293
    :cond_f
    aget v1, p1, v5

    .line 294
    .line 295
    :goto_8
    if-ne v1, v9, :cond_11

    .line 296
    .line 297
    aget v1, p1, v3

    .line 298
    .line 299
    iput v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 300
    .line 301
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 302
    .line 303
    aget p1, p1, v5

    .line 304
    .line 305
    invoke-static {v1, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->v(Lg1/p2;I)I

    .line 306
    .line 307
    .line 308
    move-result p1

    .line 309
    iput p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 310
    .line 311
    :goto_9
    iput-boolean v5, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 312
    .line 313
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 314
    .line 315
    .line 316
    if-eqz p2, :cond_10

    .line 317
    .line 318
    move-object p1, v6

    .line 319
    goto :goto_a

    .line 320
    :cond_10
    move-object p1, v4

    .line 321
    :goto_a
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object p1

    .line 325
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    goto :goto_c

    .line 329
    :cond_11
    new-instance p1, Ljava/lang/Exception;

    .line 330
    .line 331
    const-string v0, "Read-back did not match the requested rail code."

    .line 332
    .line 333
    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 337
    :goto_b
    iput-boolean v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 338
    .line 339
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 340
    .line 341
    .line 342
    new-instance v0, Ljava/lang/StringBuilder;

    .line 343
    .line 344
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 345
    .line 346
    .line 347
    if-eqz p2, :cond_12

    .line 348
    .line 349
    move-object v4, v6

    .line 350
    :cond_12
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 351
    .line 352
    .line 353
    const-string p2, " adjustment failed: "

    .line 354
    .line 355
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object p1

    .line 362
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 363
    .line 364
    .line 365
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object p1

    .line 369
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    const-string p1, "Read board again before another adjustment. Keep the original backup."

    .line 373
    .line 374
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    const-string p1, "Board write failed"

    .line 378
    .line 379
    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 380
    .line 381
    .line 382
    move-result-object p1

    .line 383
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 384
    .line 385
    .line 386
    :goto_c
    return-void

    .line 387
    :cond_13
    :goto_d
    const-string p1, "Connect CH341A first."

    .line 388
    .line 389
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    const-string p1, "Connect first"

    .line 393
    .line 394
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 395
    .line 396
    .line 397
    move-result-object p1

    .line 398
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 399
    .line 400
    .line 401
    return-void
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public final r(Ljava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E:Landroid/widget/TextView;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    .line 7
    .line 8
    const-string v2, "(?i)0x[0-9a-f]+"

    .line 9
    .line 10
    const-string v3, "device"

    .line 11
    .line 12
    invoke-virtual {p1, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string p1, "\n"

    .line 20
    .line 21
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E:Landroid/widget/TextView;

    .line 32
    .line 33
    new-instance v0, Lg1/m2;

    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    invoke-direct {v0, p0, v1}, Lg1/m2;-><init>(Lapp/gkc/terminal/Activity/PmicI2cActivity;I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 40
    .line 41
    .line 42
    return-void
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final s()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->G:Landroid/widget/Button;

    if-eqz v0, :cond_0

    const-string v1, "CONNECT"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const-string v0, "Disconnected."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    return-void
.end method

.method public final w(Landroid/hardware/usb/UsbDevice;)V
    .locals 2

    .line 1
    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->P:Lg1/n;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->O:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v0, v1, p1}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->Q:Z

    iget-object p1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->G:Landroid/widget/Button;

    const-string v0, "DISCONNECT"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "CH341A board link ready."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->y()V

    const-string p1, "CH341A connected"

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->s()V

    const-string p1, "CH341A could not be opened. Reconnect the adapter and try again."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method public final y()V
    .locals 8

    .line 1
    const/4 v0, -0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    :try_start_0
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 4
    .line 5
    iget-object v2, v2, Lg1/p2;->c:Ljava/lang/String;

    .line 6
    .line 7
    invoke-static {v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 12
    .line 13
    iget-object v3, v3, Lg1/p2;->d:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v3}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    iget-object v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 20
    .line 21
    iget-object v4, v4, Lg1/p2;->e:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->x(Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    invoke-virtual {p0, v2, v3, v4}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->E(III)[I

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    aget v3, v2, v1

    .line 32
    .line 33
    iput v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 34
    .line 35
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 36
    .line 37
    const/4 v4, 0x1

    .line 38
    aget v2, v2, v4

    .line 39
    .line 40
    invoke-static {v3, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->v(Lg1/p2;I)I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    iput v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->T:I

    .line 45
    .line 46
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 47
    .line 48
    iget v5, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->S:I

    .line 49
    .line 50
    iget-object v6, v3, Lg1/p2;->h:Lg1/q2;

    .line 51
    .line 52
    if-eqz v6, :cond_0

    .line 53
    .line 54
    iget v7, v6, Lg1/q2;->j:I

    .line 55
    .line 56
    sub-int/2addr v5, v7

    .line 57
    iget-object v6, v6, Lg1/q2;->n:[I

    .line 58
    .line 59
    invoke-static {v6, v5}, Lg1/q2;->b([II)Z

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    if-eqz v5, :cond_2

    .line 64
    .line 65
    iget-object v3, v3, Lg1/p2;->h:Lg1/q2;

    .line 66
    .line 67
    iget-object v3, v3, Lg1/q2;->o:[I

    .line 68
    .line 69
    invoke-static {v3, v2}, Lg1/q2;->b([II)Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    if-eqz v2, :cond_2

    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_0
    and-int/lit16 v6, v5, 0xff

    .line 77
    .line 78
    const/16 v7, 0xf0

    .line 79
    .line 80
    if-ge v6, v7, :cond_2

    .line 81
    .line 82
    and-int/lit16 v6, v2, 0xff

    .line 83
    .line 84
    if-lt v6, v7, :cond_1

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_1
    invoke-static {v3, v4, v5}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->u(Lg1/p2;ZI)Z

    .line 88
    .line 89
    .line 90
    move-result v5

    .line 91
    if-eqz v5, :cond_2

    .line 92
    .line 93
    invoke-static {v3, v1, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->u(Lg1/p2;ZI)Z

    .line 94
    .line 95
    .line 96
    move-result v2

    .line 97
    if-eqz v2, :cond_2

    .line 98
    .line 99
    :goto_0
    iput-boolean v4, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 100
    .line 101
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->R:Lg1/p2;

    .line 102
    .line 103
    iget-object v2, v2, Lg1/p2;->h:Lg1/q2;

    .line 104
    .line 105
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->z(Lg1/q2;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 109
    .line 110
    .line 111
    const-string v2, "Selected PMIC synced."

    .line 112
    .line 113
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_2
    :goto_1
    iput-boolean v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 118
    .line 119
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 120
    .line 121
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 122
    .line 123
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 124
    .line 125
    .line 126
    const-string v2, "PMIC not detected."

    .line 127
    .line 128
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :catch_0
    iput-boolean v1, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->W:Z

    .line 133
    .line 134
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    .line 135
    .line 136
    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    .line 137
    .line 138
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->K()V

    .line 139
    .line 140
    .line 141
    const-string v0, "PMIC read failed. Read the board before editing."

    .line 142
    .line 143
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    :goto_2
    return-void
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final z(Lg1/q2;)V
    .locals 2

    .line 1
    const/4 v0, -0x1

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    if-nez p1, :cond_0

    return-void

    :cond_0
    :try_start_0
    iget v0, p1, Lg1/q2;->h:I

    if-ltz v0, :cond_2

    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D(Lg1/q2;I)I

    move-result v0

    invoke-virtual {p1, v0}, Lg1/q2;->e(I)Z

    move-result v1

    if-eqz v1, :cond_1

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->U:I

    goto :goto_0

    :cond_1
    const-string v0, "VGL2 adjustment unavailable for the current setting."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    :cond_2
    :goto_0
    iget v0, p1, Lg1/q2;->i:I

    if-ltz v0, :cond_4

    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->D(Lg1/q2;I)I

    move-result v0

    invoke-virtual {p1, v0}, Lg1/q2;->d(I)Z

    move-result p1

    if-eqz p1, :cond_3

    iput v0, p0, Lapp/gkc/terminal/Activity/PmicI2cActivity;->V:I

    goto :goto_1

    :cond_3
    const-string p1, "VCOM adjustment unavailable for the current setting."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string p1, "Could not read the auxiliary setting. Its controls are disabled until READ BOARD succeeds."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PmicI2cActivity;->r(Ljava/lang/String;)V

    :cond_4
    :goto_1
    return-void
.end method
