.class public final Ll2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:[B


# direct methods
.method public static a(Ljava/io/InputStream;)Ll2/c;
    .locals 7

    .line 1
    new-instance v0, Ll2/c;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/16 v1, 0x18

    .line 7
    .line 8
    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    sget-object v3, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 13
    .line 14
    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    const/4 v3, 0x0

    .line 19
    move v4, v3

    .line 20
    :cond_0
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    rsub-int/lit8 v6, v4, 0x18

    .line 25
    .line 26
    invoke-virtual {p0, v5, v4, v6}, Ljava/io/InputStream;->read([BII)I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    const-string v6, "Stream closed"

    .line 31
    .line 32
    if-ltz v5, :cond_4

    .line 33
    .line 34
    add-int/2addr v4, v5

    .line 35
    if-lt v4, v1, :cond_0

    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    iput v1, v0, Ll2/c;->a:I

    .line 42
    .line 43
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    iput v1, v0, Ll2/c;->b:I

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    iput v1, v0, Ll2/c;->c:I

    .line 54
    .line 55
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    iput v1, v0, Ll2/c;->d:I

    .line 60
    .line 61
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    iput v1, v0, Ll2/c;->e:I

    .line 66
    .line 67
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    iput v1, v0, Ll2/c;->f:I

    .line 72
    .line 73
    iget v1, v0, Ll2/c;->d:I

    .line 74
    .line 75
    if-eqz v1, :cond_3

    .line 76
    .line 77
    new-array v1, v1, [B

    .line 78
    .line 79
    iput-object v1, v0, Ll2/c;->g:[B

    .line 80
    .line 81
    :cond_1
    iget-object v1, v0, Ll2/c;->g:[B

    .line 82
    .line 83
    iget v2, v0, Ll2/c;->d:I

    .line 84
    .line 85
    sub-int/2addr v2, v3

    .line 86
    invoke-virtual {p0, v1, v3, v2}, Ljava/io/InputStream;->read([BII)I

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    if-ltz v1, :cond_2

    .line 91
    .line 92
    add-int/2addr v3, v1

    .line 93
    iget v1, v0, Ll2/c;->d:I

    .line 94
    .line 95
    if-lt v3, v1, :cond_1

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_2
    new-instance p0, Ljava/io/IOException;

    .line 99
    .line 100
    invoke-direct {p0, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw p0

    .line 104
    :cond_3
    :goto_0
    return-object v0

    .line 105
    :cond_4
    new-instance p0, Ljava/io/IOException;

    .line 106
    .line 107
    invoke-direct {p0, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    throw p0
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method
