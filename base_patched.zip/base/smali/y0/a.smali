.class public abstract Ly0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Ly0/a;->a:[I

    return-void

    :array_0
    .array-data 4
        0x10100c4
        0x10100eb
        0x10100f1
        0x7f040204
        0x7f040205
        0x7f040206
        0x7f040207
        0x7f040208
        0x7f0402b1
        0x7f0403f3
        0x7f040438
        0x7f040443
    .end array-data
.end method
