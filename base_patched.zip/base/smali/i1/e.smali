.class public final Li1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public static d(J)V
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p0, p1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Thread;->interrupt()V

    :goto_0
    return-void
.end method

.method public static e(Ljava/io/ByteArrayOutputStream;I)V
    .locals 1

    .line 1
    and-int/lit16 v0, p1, 0xff

    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    shr-int/lit8 v0, p1, 0x8

    and-int/lit16 v0, v0, 0xff

    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    shr-int/lit8 v0, p1, 0x10

    and-int/lit16 v0, v0, 0xff

    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    shr-int/lit8 p1, p1, 0x18

    and-int/lit16 p1, p1, 0xff

    invoke-virtual {p0, p1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    return-void
.end method


# virtual methods
.method public final a(III[B)[B
    .locals 18

    .line 1
    move/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p4

    .line 4
    .line 5
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    .line 6
    .line 7
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 8
    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    invoke-virtual {v2, v3}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v2, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 15
    .line 16
    .line 17
    array-length v4, v1

    .line 18
    and-int/lit16 v5, v4, 0xff

    .line 19
    .line 20
    invoke-virtual {v2, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 21
    .line 22
    .line 23
    const/16 v5, 0x8

    .line 24
    .line 25
    shr-int/2addr v4, v5

    .line 26
    and-int/lit16 v4, v4, 0xff

    .line 27
    .line 28
    invoke-virtual {v2, v4}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 29
    .line 30
    .line 31
    move/from16 v4, p2

    .line 32
    .line 33
    invoke-static {v2, v4}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, v1}, Ljava/io/OutputStream;->write([B)V

    .line 37
    .line 38
    .line 39
    move-object/from16 v1, p0

    .line 40
    .line 41
    iget-object v4, v1, Li1/e;->a:Ljava/lang/Object;

    .line 42
    .line 43
    move-object v6, v4

    .line 44
    check-cast v6, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    .line 45
    .line 46
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    new-instance v7, Ljava/io/ByteArrayOutputStream;

    .line 51
    .line 52
    invoke-direct {v7}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 53
    .line 54
    .line 55
    const/16 v8, 0xc0

    .line 56
    .line 57
    invoke-virtual {v7, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 58
    .line 59
    .line 60
    array-length v9, v2

    .line 61
    move v10, v3

    .line 62
    :goto_0
    const/16 v11, 0xdd

    .line 63
    .line 64
    const/16 v12, 0xdc

    .line 65
    .line 66
    const/16 v13, 0xdb

    .line 67
    .line 68
    if-ge v10, v9, :cond_2

    .line 69
    .line 70
    aget-byte v14, v2, v10

    .line 71
    .line 72
    and-int/lit16 v14, v14, 0xff

    .line 73
    .line 74
    if-ne v14, v8, :cond_0

    .line 75
    .line 76
    invoke-virtual {v7, v13}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v7, v12}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :cond_0
    if-ne v14, v13, :cond_1

    .line 84
    .line 85
    invoke-virtual {v7, v13}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v7, v11}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 89
    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_1
    invoke-virtual {v7, v14}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 93
    .line 94
    .line 95
    :goto_1
    add-int/lit8 v10, v10, 0x1

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_2
    invoke-virtual {v7, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v7}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    const/16 v7, 0xbb8

    .line 106
    .line 107
    invoke-interface {v6, v2, v7}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->write([BI)V

    .line 108
    .line 109
    .line 110
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 111
    .line 112
    .line 113
    move-result-wide v6

    .line 114
    move/from16 v2, p3

    .line 115
    .line 116
    int-to-long v9, v2

    .line 117
    add-long/2addr v6, v9

    .line 118
    :goto_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 119
    .line 120
    .line 121
    move-result-wide v9

    .line 122
    cmp-long v2, v9, v6

    .line 123
    .line 124
    const/4 v9, 0x1

    .line 125
    if-gez v2, :cond_d

    .line 126
    .line 127
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 128
    .line 129
    .line 130
    move-result-wide v14

    .line 131
    sub-long v14, v6, v14

    .line 132
    .line 133
    long-to-int v2, v14

    .line 134
    const/16 v10, 0x64

    .line 135
    .line 136
    invoke-static {v10, v2}, Ljava/lang/Math;->max(II)I

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 141
    .line 142
    .line 143
    move-result-wide v14

    .line 144
    move-wide/from16 p2, v6

    .line 145
    .line 146
    int-to-long v5, v2

    .line 147
    add-long/2addr v14, v5

    .line 148
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    .line 149
    .line 150
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 151
    .line 152
    .line 153
    const/16 v5, 0x100

    .line 154
    .line 155
    new-array v5, v5, [B

    .line 156
    .line 157
    move v6, v3

    .line 158
    :goto_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 159
    .line 160
    .line 161
    move-result-wide v16

    .line 162
    cmp-long v7, v16, v14

    .line 163
    .line 164
    if-gez v7, :cond_c

    .line 165
    .line 166
    move-object v7, v4

    .line 167
    check-cast v7, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    .line 168
    .line 169
    const/16 v3, 0x12c

    .line 170
    .line 171
    invoke-interface {v7, v5, v3}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->read([BI)I

    .line 172
    .line 173
    .line 174
    move-result v3

    .line 175
    const/4 v7, 0x0

    .line 176
    :goto_4
    if-ge v7, v3, :cond_b

    .line 177
    .line 178
    aget-byte v10, v5, v7

    .line 179
    .line 180
    and-int/lit16 v10, v10, 0xff

    .line 181
    .line 182
    if-ne v10, v8, :cond_9

    .line 183
    .line 184
    if-eqz v6, :cond_8

    .line 185
    .line 186
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    .line 187
    .line 188
    .line 189
    move-result v6

    .line 190
    if-lez v6, :cond_8

    .line 191
    .line 192
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 193
    .line 194
    .line 195
    move-result-object v2

    .line 196
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    .line 197
    .line 198
    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 199
    .line 200
    .line 201
    const/4 v5, 0x0

    .line 202
    :goto_5
    array-length v6, v2

    .line 203
    if-ge v5, v6, :cond_6

    .line 204
    .line 205
    aget-byte v6, v2, v5

    .line 206
    .line 207
    and-int/lit16 v6, v6, 0xff

    .line 208
    .line 209
    if-ne v6, v13, :cond_5

    .line 210
    .line 211
    add-int/lit8 v7, v5, 0x1

    .line 212
    .line 213
    array-length v10, v2

    .line 214
    if-ge v7, v10, :cond_5

    .line 215
    .line 216
    aget-byte v5, v2, v7

    .line 217
    .line 218
    and-int/lit16 v5, v5, 0xff

    .line 219
    .line 220
    if-ne v5, v12, :cond_3

    .line 221
    .line 222
    invoke-virtual {v3, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 223
    .line 224
    .line 225
    goto :goto_6

    .line 226
    :cond_3
    if-ne v5, v11, :cond_4

    .line 227
    .line 228
    invoke-virtual {v3, v13}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 229
    .line 230
    .line 231
    goto :goto_6

    .line 232
    :cond_4
    invoke-virtual {v3, v5}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 233
    .line 234
    .line 235
    :goto_6
    move v5, v7

    .line 236
    goto :goto_7

    .line 237
    :cond_5
    invoke-virtual {v3, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 238
    .line 239
    .line 240
    :goto_7
    add-int/2addr v5, v9

    .line 241
    goto :goto_5

    .line 242
    :cond_6
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    array-length v3, v2

    .line 247
    const/16 v6, 0x8

    .line 248
    .line 249
    if-lt v3, v6, :cond_7

    .line 250
    .line 251
    aget-byte v3, v2, v9

    .line 252
    .line 253
    and-int/lit16 v3, v3, 0xff

    .line 254
    .line 255
    if-ne v3, v0, :cond_7

    .line 256
    .line 257
    goto :goto_9

    .line 258
    :cond_7
    move v5, v6

    .line 259
    const/4 v3, 0x0

    .line 260
    move-wide/from16 v6, p2

    .line 261
    .line 262
    goto/16 :goto_2

    .line 263
    .line 264
    :cond_8
    const/16 v6, 0x8

    .line 265
    .line 266
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->reset()V

    .line 267
    .line 268
    .line 269
    move/from16 v17, v6

    .line 270
    .line 271
    move v6, v9

    .line 272
    goto :goto_8

    .line 273
    :cond_9
    const/16 v17, 0x8

    .line 274
    .line 275
    if-eqz v6, :cond_a

    .line 276
    .line 277
    invoke-virtual {v2, v10}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 278
    .line 279
    .line 280
    :cond_a
    :goto_8
    add-int/lit8 v7, v7, 0x1

    .line 281
    .line 282
    goto :goto_4

    .line 283
    :cond_b
    const/4 v3, 0x0

    .line 284
    goto :goto_3

    .line 285
    :cond_c
    new-instance v0, Ljava/io/IOException;

    .line 286
    .line 287
    const-string v2, "ESP32 response timeout"

    .line 288
    .line 289
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    throw v0

    .line 293
    :cond_d
    const/4 v2, 0x0

    .line 294
    :goto_9
    if-eqz v2, :cond_10

    .line 295
    .line 296
    array-length v0, v2

    .line 297
    const/16 v3, 0xa

    .line 298
    .line 299
    if-lt v0, v3, :cond_f

    .line 300
    .line 301
    array-length v0, v2

    .line 302
    add-int/lit8 v0, v0, -0x2

    .line 303
    .line 304
    aget-byte v0, v2, v0

    .line 305
    .line 306
    and-int/lit16 v0, v0, 0xff

    .line 307
    .line 308
    array-length v3, v2

    .line 309
    sub-int/2addr v3, v9

    .line 310
    aget-byte v3, v2, v3

    .line 311
    .line 312
    and-int/lit16 v3, v3, 0xff

    .line 313
    .line 314
    if-nez v0, :cond_e

    .line 315
    .line 316
    goto :goto_a

    .line 317
    :cond_e
    new-instance v0, Ljava/io/IOException;

    .line 318
    .line 319
    const-string v2, "ESP32 ROM error "

    .line 320
    .line 321
    invoke-static {v2, v3}, Landroidx/fragment/app/e1;->d(Ljava/lang/String;I)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v2

    .line 325
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    throw v0

    .line 329
    :cond_f
    :goto_a
    return-object v2

    .line 330
    :cond_10
    new-instance v0, Ljava/io/IOException;

    .line 331
    .line 332
    const-string v2, "No matching ESP32 response"

    .line 333
    .line 334
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    throw v0
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
.end method

.method public final b()V
    .locals 5

    .line 1
    const/16 v0, 0x100

    new-array v0, v0, [B

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0xfa

    add-long/2addr v1, v3

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    cmp-long v3, v3, v1

    if-gez v3, :cond_1

    :try_start_0
    iget-object v3, p0, Li1/e;->a:Ljava/lang/Object;

    check-cast v3, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    const/16 v4, 0x14

    invoke-interface {v3, v0, v4}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->read([BI)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-gtz v3, :cond_0

    :catch_0
    :cond_1
    return-void
.end method

.method public final c([BIZ)V
    .locals 18

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    .line 1
    iget-object v4, v0, Le/n0;->c:Ljava/lang/Object;

    check-cast v4, Lapp/gkc/terminal/USB/Esp32FlashActivity;

    .line 2
    new-instance v5, Lz/n;

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v5, v6, v7, v0}, Lz/n;-><init>(IILjava/lang/Object;)V

    invoke-virtual {v4, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v4, "Opening ESP32 bootloader..."

    .line 3
    invoke-virtual {v0, v4}, Le/n0;->A(Ljava/lang/String;)V

    iget-object v4, v1, Li1/e;->a:Ljava/lang/Object;

    const/4 v5, 0x1

    if-eqz p3, :cond_0

    :try_start_0
    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    .line 4
    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setDTR(Z)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v5}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    const-wide/16 v8, 0x78

    invoke-static {v8, v9}, Li1/e;->d(J)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v5}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setDTR(Z)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    invoke-static {v8, v9}, Li1/e;->d(J)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setDTR(Z)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    const-wide/16 v8, 0x15e

    invoke-static {v8, v9}, Li1/e;->d(J)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v8, "Auto boot lines not supported. Use BOOT button manually."

    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v8, "Manual mode: hold BOOT, tap EN/RESET, then release BOOT."

    .line 5
    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    const-wide/16 v8, 0x5dc

    invoke-static {v8, v9}, Li1/e;->d(J)V

    :goto_0
    invoke-virtual/range {p0 .. p0}, Li1/e;->b()V

    const/16 v8, 0x24

    new-array v9, v8, [B

    const/4 v0, 0x7

    aput-byte v0, v9, v6

    aput-byte v0, v9, v5

    const/16 v0, 0x12

    aput-byte v0, v9, v7

    const/4 v10, 0x3

    const/16 v11, 0x20

    aput-byte v11, v9, v10

    const/4 v0, 0x4

    const/16 v12, 0x55

    .line 6
    invoke-static {v9, v0, v8, v12}, Ljava/util/Arrays;->fill([BIIB)V

    const/4 v0, 0x0

    move v12, v6

    :goto_1
    const/16 v13, 0x8

    if-ge v12, v13, :cond_9

    move v14, v6

    const/16 v15, 0xef

    :goto_2
    const-wide/16 v16, 0xfa

    if-ge v14, v8, :cond_1

    .line 7
    :try_start_1
    aget-byte v0, v9, v14

    and-int/lit16 v0, v0, 0xff

    xor-int/2addr v15, v0

    add-int/lit8 v14, v14, 0x1

    goto :goto_2

    :cond_1
    const/16 v0, 0x4b0

    .line 8
    invoke-virtual {v1, v13, v15, v0, v9}, Li1/e;->a(III[B)[B

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v14, "ESP32 connected."

    invoke-virtual {v0, v14}, Le/n0;->A(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_6

    .line 9
    invoke-virtual/range {p0 .. p0}, Li1/e;->b()V

    const-string v0, "Changed baud rate to "

    .line 10
    new-instance v8, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v8}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const v9, 0x70800

    invoke-static {v8, v9}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v8, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const-wide/16 v14, 0x64

    :try_start_2
    invoke-virtual {v8}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v8

    const/16 v12, 0xbb8

    const/16 v11, 0xf

    invoke-virtual {v1, v11, v6, v12, v8}, Li1/e;->a(III[B)[B

    move-object v8, v4

    check-cast v8, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v8, v9, v13, v5, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setParameters(IIII)V

    iget-object v8, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v8, Le/n0;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "."

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Le/n0;->A(Ljava/lang/String;)V

    invoke-static {v14, v15}, Li1/e;->d(J)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_3

    :catch_1
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v8, "High baud failed, continuing at 115200."

    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    :try_start_3
    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    const v8, 0x1c200

    invoke-interface {v0, v8, v13, v5, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setParameters(IIII)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 11
    :catch_2
    :goto_3
    invoke-virtual/range {p0 .. p0}, Li1/e;->b()V

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Writing "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    array-length v9, v2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " bytes at 0x"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v8, "Adjusting flash..."

    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    .line 12
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {v0, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v0, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v8, 0x1388

    :try_start_4
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/16 v9, 0xd

    invoke-virtual {v1, v9, v6, v8, v0}, Li1/e;->a(III[B)[B
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    goto :goto_4

    :catch_3
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v9, "SPI_ATTACH timeout, continuing..."

    invoke-virtual {v0, v9}, Le/n0;->A(Ljava/lang/String;)V

    .line 13
    :goto_4
    array-length v0, v2

    add-int/2addr v0, v3

    add-int/lit16 v0, v0, 0xfff

    and-int/lit16 v0, v0, -0x1000

    const/high16 v9, 0x400000

    invoke-static {v9, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 14
    new-instance v9, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v9}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {v9, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v9, v0}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const/high16 v0, 0x10000

    invoke-static {v9, v0}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v11, 0x1000

    invoke-static {v9, v11}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v11, 0x100

    invoke-static {v9, v11}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    const v11, 0xffff

    invoke-static {v9, v11}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    :try_start_5
    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v9

    const/16 v12, 0xb

    invoke-virtual {v1, v12, v6, v8, v9}, Li1/e;->a(III[B)[B
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    goto :goto_5

    :catch_4
    iget-object v9, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v9, Le/n0;

    const-string v12, "SPI parameters timeout, continuing..."

    invoke-virtual {v9, v12}, Le/n0;->A(Ljava/lang/String;)V

    :goto_5
    iget-object v9, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v9, Le/n0;

    const-string v12, "Erasing flash region..."

    .line 15
    invoke-virtual {v9, v12}, Le/n0;->A(Ljava/lang/String;)V

    array-length v9, v2

    add-int/lit16 v12, v9, 0x3ff

    const/16 v5, 0x400

    .line 16
    div-int/2addr v12, v5

    new-instance v13, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v13}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {v13, v9}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v13, v12}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v13, v5}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v13, v3}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    add-int/2addr v9, v11

    div-int/2addr v9, v0

    mul-int/2addr v9, v8

    const/16 v0, 0x4e20

    invoke-static {v0, v9}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {v13}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v8

    invoke-virtual {v1, v7, v6, v0, v8}, Li1/e;->a(III[B)[B

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v8, "Writing firmware..."

    .line 17
    invoke-virtual {v0, v8}, Le/n0;->A(Ljava/lang/String;)V

    .line 18
    array-length v0, v2

    add-int/lit16 v0, v0, 0x3ff

    div-int/2addr v0, v5

    move v8, v6

    :goto_6
    if-ge v8, v0, :cond_5

    mul-int/lit16 v9, v8, 0x400

    array-length v11, v2

    sub-int/2addr v11, v9

    invoke-static {v5, v11}, Ljava/lang/Math;->min(II)I

    move-result v11

    new-array v12, v5, [B

    const/4 v13, -0x1

    invoke-static {v12, v13}, Ljava/util/Arrays;->fill([BB)V

    invoke-static {v2, v9, v12, v6, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance v9, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v9}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {v9, v5}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v9, v8}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v9, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v9, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-virtual {v9, v12}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v9

    move v11, v6

    const/16 v13, 0xef

    :goto_7
    if-ge v11, v5, :cond_2

    .line 19
    aget-byte v5, v12, v11

    and-int/lit16 v5, v5, 0xff

    xor-int/2addr v13, v5

    add-int/lit8 v11, v11, 0x1

    const/16 v5, 0x400

    goto :goto_7

    :cond_2
    const/16 v5, 0x1b58

    .line 20
    invoke-virtual {v1, v10, v13, v5, v9}, Li1/e;->a(III[B)[B

    add-int/lit8 v5, v8, 0x1

    int-to-long v11, v5

    mul-long/2addr v11, v14

    int-to-long v14, v0

    div-long/2addr v11, v14

    long-to-int v9, v11

    iget-object v11, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v11, Le/n0;

    .line 21
    iget-object v12, v11, Le/n0;->c:Ljava/lang/Object;

    check-cast v12, Lapp/gkc/terminal/USB/Esp32FlashActivity;

    .line 22
    new-instance v13, Lz/n;

    invoke-direct {v13, v9, v7, v11}, Lz/n;-><init>(IILjava/lang/Object;)V

    invoke-virtual {v12, v13}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    if-eqz v8, :cond_3

    add-int/lit8 v11, v0, -0x1

    if-eq v8, v11, :cond_3

    .line 23
    rem-int/lit8 v8, v8, 0x10

    if-nez v8, :cond_4

    :cond_3
    iget-object v8, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v8, Le/n0;

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "Flash "

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "%"

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Le/n0;->A(Ljava/lang/String;)V

    :cond_4
    move v8, v5

    const/16 v5, 0x400

    const-wide/16 v14, 0x64

    goto :goto_6

    :cond_5
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v5, "Verifying flash MD5..."

    .line 24
    invoke-virtual {v0, v5}, Le/n0;->A(Ljava/lang/String;)V

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {v0, v3}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    array-length v3, v2

    invoke-static {v0, v3}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v0, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-static {v0, v6}, Li1/e;->e(Ljava/io/ByteArrayOutputStream;I)V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/16 v3, 0x7530

    const/16 v5, 0x13

    invoke-virtual {v1, v5, v6, v3, v0}, Li1/e;->a(III[B)[B

    move-result-object v0

    array-length v3, v0

    const/16 v5, 0x28

    if-lt v3, v5, :cond_8

    new-instance v3, Ljava/lang/String;

    sget-object v5, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    const/16 v8, 0x8

    const/16 v11, 0x20

    invoke-direct {v3, v0, v8, v11, v5}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v0, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "MD5"

    invoke-static {v3}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v2

    .line 25
    new-instance v3, Ljava/lang/StringBuilder;

    array-length v5, v2

    mul-int/2addr v5, v7

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v5, v2

    move v8, v6

    :goto_8
    if-ge v8, v5, :cond_6

    aget-byte v9, v2, v8

    sget-object v10, Ljava/util/Locale;->US:Ljava/util/Locale;

    and-int/lit16 v9, v9, 0xff

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v9}, [Ljava/lang/Object;

    move-result-object v9

    const-string v11, "%02x"

    invoke-static {v10, v11, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v8, v8, 0x1

    goto :goto_8

    :cond_6
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 26
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v2, "Flash MD5 verified."

    invoke-virtual {v0, v2}, Le/n0;->A(Ljava/lang/String;)V

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    .line 27
    iget-object v2, v0, Le/n0;->c:Ljava/lang/Object;

    check-cast v2, Lapp/gkc/terminal/USB/Esp32FlashActivity;

    .line 28
    new-instance v3, Lz/n;

    const/16 v5, 0x64

    invoke-direct {v3, v5, v7, v0}, Lz/n;-><init>(IILjava/lang/Object;)V

    invoke-virtual {v2, v3}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v2, "Flash completed and verified. Resetting ESP32..."

    .line 29
    invoke-virtual {v0, v2}, Le/n0;->A(Ljava/lang/String;)V

    :try_start_6
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v2, "Releasing BOOT and pulsing EN..."

    .line 30
    invoke-virtual {v0, v2}, Le/n0;->A(Ljava/lang/String;)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setDTR(Z)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    const/4 v5, 0x1

    invoke-interface {v0, v5}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    invoke-static/range {v16 .. v17}, Li1/e;->d(J)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    const-wide/16 v2, 0x1c2

    invoke-static {v2, v3}, Li1/e;->d(J)V

    move-object v0, v4

    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v0, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setDTR(Z)V

    check-cast v4, Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    invoke-interface {v4, v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setRTS(Z)V

    const-wide/16 v2, 0x4b0

    invoke-static {v2, v3}, Li1/e;->d(J)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_5

    :catch_5
    iget-object v0, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v0, Le/n0;

    const-string v2, "Done. If Wi-Fi is not visible in 10 seconds, press EN/RESET once."

    .line 31
    invoke-virtual {v0, v2}, Le/n0;->A(Ljava/lang/String;)V

    return-void

    .line 32
    :cond_7
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Flash MD5 verification failed"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    new-instance v0, Ljava/io/IOException;

    const-string v2, "ESP32 returned an invalid MD5 response"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_6
    move-exception v0

    iget-object v13, v1, Li1/e;->b:Ljava/lang/Object;

    check-cast v13, Le/n0;

    .line 33
    new-instance v14, Ljava/lang/StringBuilder;

    const-string v15, "Sync retry "

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Le/n0;->A(Ljava/lang/String;)V

    invoke-static/range {v16 .. v17}, Li1/e;->d(J)V

    goto/16 :goto_1

    :cond_9
    new-instance v2, Ljava/io/IOException;

    const-string v3, "ESP32 bootloader sync failed. Hold BOOT and try again."

    invoke-direct {v2, v3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
.end method
