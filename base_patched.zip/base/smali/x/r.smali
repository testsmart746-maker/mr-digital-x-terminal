.class public interface abstract Lx/r;
.super Ljava/lang/Object;
.source "SourceFile"
