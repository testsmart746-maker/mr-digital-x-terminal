.class public final Ld3/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Ly2/a;


# instance fields
.field public final synthetic g:Ld3/e;


# direct methods
.method public constructor <init>(Le3/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld3/h;->g:Ld3/e;

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 1

    .line 1
    iget-object v0, p0, Ld3/h;->g:Ld3/e;

    invoke-interface {v0}, Ld3/e;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method
