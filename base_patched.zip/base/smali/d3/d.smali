.class public final Ld3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld3/e;


# instance fields
.field public final a:Lw2/a;

.field public final b:Lw2/l;


# direct methods
.method public constructor <init>(Ll0/d;)V
    .locals 1

    .line 1
    sget-object v0, Lb/g;->g:Lb/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ld3/d;->a:Lw2/a;

    iput-object p1, p0, Ld3/d;->b:Lw2/l;

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 1

    .line 1
    new-instance v0, Ld3/c;

    invoke-direct {v0, p0}, Ld3/c;-><init>(Ld3/d;)V

    return-object v0
.end method
