.class public abstract Lr2/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Li/u2;

.field public static b:Li/u2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Li/u2;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1}, Li/u2;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    sput-object v0, Lr2/f;->a:Li/u2;

    return-void
.end method
