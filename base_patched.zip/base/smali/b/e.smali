.class public final Lb/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lb/c;

.field public final b:Le2/m;


# direct methods
.method public constructor <init>(Lb/c;Le2/m;)V
    .locals 1

    .line 1
    const-string v0, "callback"

    invoke-static {p1, v0}, Le2/m;->y(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "contract"

    invoke-static {p2, v0}, Le2/m;->y(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb/e;->a:Lb/c;

    iput-object p2, p0, Lb/e;->b:Le2/m;

    return-void
.end method
